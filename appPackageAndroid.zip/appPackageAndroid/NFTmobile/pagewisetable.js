function loadPerformance(ClickName)
{
//alert(ClickName)
	$.getJSON("Result.json", function(json) 
{
//window.alert(ClickName);

  var ul = document.getElementById(ClickName);

if(ul!=undefined)
$("#"+ClickName+ClickName).remove();

    var mainObj=json;

   for(var i=0;i<json.length;i++)
            {       
                        //var usecasename=usecasenamedtl;
                       var eachobj=mainObj[i];
                        var eachobjkeys=Object.keys(eachobj);
                        eachobjkeys.forEach(function (key)
                         {
                        if(eachobj.hasOwnProperty(usecasenamedtl))
                        {                          
                       var eachusecase=eachobj[eachobjkeys];    

                     for(var j=0;j<eachusecase.length;j++)
                     	{
                        var eachpage=eachusecase[j];
                        var eachpagekeys=Object.keys(eachpage);
                        
                     if(eachpagekeys==ClickName)
                     {
                    // 	alert(eachpagekeys)

                        var pagewisedetails=eachpage[eachpagekeys];
                               
                        var row=document.createElement('div');
                        row.setAttribute("class","row");
                        row.setAttribute("id",ClickName+ClickName);


                        var gridWidth=document.createElement('div');
                        gridWidth.setAttribute("class","col-lg-12");

                        var panelRoot=document.createElement('div');
                        panelRoot.setAttribute("class","panel panel-default");

                        var panelHeading=document.createElement('div');
                        panelHeading.setAttribute("class","panel-heading");

                        var heading3=document.createElement('h3');
                        heading3.setAttribute("class","panel-title");

                        var icon=document.createElement('i');
                        icon.setAttribute("class","fa fa-long-arrow-right fa-fw");

                        heading3.appendChild(icon);
                        heading3.innerHTML=eachpagekeys;

                        var panelBody=document.createElement('div');
                        panelBody.setAttribute("class","panel-body");
                        panelBody.setAttribute("class","table-responsive");

                        var heading5=document.createElement('h5');
                        heading5.innerHTML="Network calls count for this page is  ";

                       			var table = document.createElement('table');
                                table.setAttribute("class","table table-bordered table-hover table-striped");
                                table.setAttribute("id","table");

                                var tablebody=document.createElement('tbody');
                                tablebody.setAttribute("id",eachpagekeys);

                                var tableheader=document.createElement('thead');
                                var tableheadrow=document.createElement('tr');
                                  var tableheader0=document.createElement('th');
                                  var tableheader1=document.createElement('th');                    
                                  var tableheader2=document.createElement('th');
                                  var tableheader3=document.createElement('th');
                                  var tableheader4=document.createElement('th');
                                  var tableheader5=document.createElement('th');
                                  var tableheader6=document.createElement('th');

                                  tableheader0.innerHTML="SLA Met";
                                  tableheader1.innerHTML="URL";
                                  tableheader2.innerHTML="STATUS";
                                  tableheader3.innerHTML="Request Size(Bytes)";
                                  tableheader4.innerHTML="Response Size(Bytes)";
                                  tableheader5.innerHTML="Response Time(ms)";
                                  tableheader6.innerHTML="API";

                                  tableheadrow.appendChild(tableheader0);
                                  tableheadrow.appendChild(tableheader1);
                                  tableheadrow.appendChild(tableheader2);
                                  tableheadrow.appendChild(tableheader3);
                                  tableheadrow.appendChild(tableheader4);
                                  tableheadrow.appendChild(tableheader5);
                                  tableheadrow.appendChild(tableheader6);
                                  tableheader.appendChild(tableheadrow)

                                  var networkdetails;
                           		var netcalls=pagewisedetails.NetworkDetails.length;      
                    
                        

                    for(k=0;k<netcalls;k++)
                    {

                        networkdetails=pagewisedetails.NetworkDetails[k];
                       
                      //  alert("networkdetails"+JSON.stringify(networkdetails));
                    var tablerow=document.createElement('tr');                        
                    var tablecolum0=document.createElement('td');

                    var tablecolum1=document.createElement('td');   
                    var tablecolum2=document.createElement('td');                   
                    var tablecolum3=document.createElement('td');
                    var tablecolum4=document.createElement('td');
                    var tablecolum5=document.createElement('td');
                    var tablecolum6=document.createElement('td');           

                    //tablecolum1.innerHTML=json[i].URL;
                    
                    //window.alert(overalljanks/(Object.keys(janks).length));
                    var status=networkdetails.STATUS;
                  //  alert("status"+status)
                    var reqsize=(networkdetails.RequestSize);
                    reqsizarray.push(reqsize);
                    var ressize=(networkdetails.ResponseSize);
                    respsizearray.push(ressize);
                    totalrequestsize=totalrequestsize+reqsize;
                    totalreceivedsize=totalreceivedsize+ressize;
                    var latency=networkdetails.ResponseTime;
                    if(latency===null||latency==="")
						{
   							 tablecolum6.innerHTML="Null";
                         
						}            
					else
						{
     						tablecolum6.innerHTML=latency;  
						}    
var RequestedPage=networkdetails.RequestedPage;

                    if(RequestedPage===null||RequestedPage==="")
{
    tablecolum2.innerHTML="Null";
                         
}            
else{
     tablecolum2.innerHTML=RequestedPage;  

} 

    //alert(status+reqsize+ressize+latency)
                    tablecolum1.innerHTML=networkdetails.Domain;
                  //  tablecolum2.innerHTML=networkdetails.RequestedPage;
                    //tablecolum1.innerHTML=json[i]["request"].header.firstLine;
                    tablecolum3.innerHTML=status;
                    tablecolum4.innerHTML=reqsize;
                    tablecolum5.innerHTML=ressize;
                    //var node=tablecolum6.innerHTML;
                   
                    //tablecolum6.innerHTML=latency;
                    tablerow.appendChild(tablecolum0); 
                    tablerow.appendChild(tablecolum1);                   
                    tablerow.appendChild(tablecolum3);
                    tablerow.appendChild(tablecolum4);
                    tablerow.appendChild(tablecolum5);
                    tablerow.appendChild(tablecolum6)
                    tablerow.appendChild(tablecolum2).setAttribute("style", "word-break: break-All;");
     

                      tablebody.appendChild(tablerow);
                     
                   if((reqsize>(1.5*1024))||(ressize>(10*1024))||(latency>400)||(status!=200))
                         {  
                         netslacount++;   

                        tablecolum0.className = 'sla-fail';
                        
                        tablerow.addEventListener("click",clickCell_Fail,false);
                        }
                        else
                        {
                        tablecolum0.className = 'sla-pass';
              
                        tablerow.addEventListener("click",clickCell_Pass,false);
                        } 
                    
              }
            
               var networkcalls=document.createElement('span');
                    if(netcalls<=10)
                    {
                    networkcalls.style.color = "green";
                    }
                    else if((netcalls>10)&&(netcalls<50))
                    {
                        networkcalls.style.color = "blue";   
                    }
                    else
                    {
                          networkcalls.style.color = "red";
                    }
              		  networkcalls.innerHTML=netcalls;        
                	  heading5.appendChild(networkcalls); 
               		  table.appendChild(tableheader);
               		  table.appendChild(tablebody);
               		  panelHeading.appendChild(heading3);

        			panelRoot.appendChild(panelHeading);
       				panelRoot.appendChild(panelBody);
        			panelBody.appendChild(table);
         		
        			panelRoot.appendChild(heading5);
       				gridWidth.appendChild(panelRoot);
       			
        			row.appendChild(gridWidth);
        			document.getElementById(eachpagekeys).appendChild(row);       
   					 } 
  			      }
  			      }                     
              });
 	       }          

        // SLA Checking                 
             function clickCell_Pass()
 {

var table = document.getElementById("Networktable");
//var tbody = table.getElementById("tbody")[0];
  //alert("sdsdg"+JSON.stringify(table))
table.onclick = function (e) {
    e = e || window.event;
    var target = e.srcElement || e.target;
    while (target && target.nodeName !== "TR") {
        target = target.parentNode;
    }
    if (target) {
        var tablerow=document.createElement('tr'); 
        var cells = target.getElementsByTagName("td");
        for (var i = 0; i < cells.length; i++) {
        var cell=document.createElement('td');
        cell.innerHTML="";
            tablerow.appendChild(cell);
        }
    }  
/*   var oldnode=document.getElementById("SLA_Pass_table");
            $("#myModals").modal('show');
document.getElementById("SLA_Pass_table").replaceChild(tablerow,oldnode.childNodes[0]);*/
};
/*$("#myModals").modal('show'); */
}


 function clickCell_Fail()
 {

var table = document.getElementById("Networktable");
   
table.onclick = function (e) {
    //alert("sdsdg"+JSON.stringify(table))
    e = e || window.event;

    var target = e.srcElement || e.target;

    while (target && target.nodeName !== "TR") 
    {
       // alert("sdsdg"+JSON.stringify(table))
        target = target.parentNode;
    }
   
    {
      
        var tablerow=document.createElement('tr'); 
        var cells = target.getElementsByTagName("td");
        //for (var i = 2; i < (cells.length-1); i++)
        //{
        var cell=document.createElement('td');
         var reqsize=cells[3].innerHTML;
         var respsize=cells[4].innerHTML;
         var latency=cells[5].innerHTML;
         var status=cells[6].innerHTML;
         if(((reqsize>(1.5*1024))||(respsize>(10*1024))||(latency>400)||(status!=200)))
         {
        
            if((reqsize>(1.5*1024)))
            {

                if((respsize>(10*1024))&&(status!=200)&&(latency>400))
                    { 
                        cell.innerHTML="Request size and Response size and Status and Latency";
                   }
                else if((respsize>(10*1024))&&(latency>400))
                     {
                     	
                         cell.innerHTML="Response size and Latency";
                     }
                        else if((respsize>(10*1024))&&(status!=200))
                     {
                         cell.innerHTML="Response size and Status";
                     }
                          else if((latency>400)&&(status!=200))
                     {
                         cell.innerHTML="Latency size and Status";
                     }

                     else
                     {
                        cell.innerHTML="Request size"; 
                     }

            }
            else if((respsize>(10*1024)))
            {
                if((reqsize>(1.5*1024))&&(latency>400))
                   {
                         cell.innerHTML="Response size and Latency";
                     }
                     else
                     {
                     cell.innerHTML="Response size";
                     }
                
            }
            else if((latency>400))
            {
                cell.innerHTML="Latency"
              

            }
               else if((status!=200))
            {
                cell.innerHTML="Status Code";
            }
         }
         else
         {
           cell.innerHTML="Request size, Latency and Response size and Status"; 
         }
       // alert("cells inner html"+eachval)
        tablerow.appendChild(cell);
      //  }
    }
    var oldnode=document.getElementById("SLA_Fail_table");
    $("#myModalf").modal('show');
    document.getElementById("SLA_Fail_table").replaceChild(tablerow,oldnode.childNodes[0]);
    };
   }  

});

}