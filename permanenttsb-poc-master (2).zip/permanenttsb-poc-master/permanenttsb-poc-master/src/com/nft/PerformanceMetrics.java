package com.nft;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;
import org.json.JSONException;
/*import org.influxdb.dto.Point;*/
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.charles.NetworkRecommend;

import net.lightbody.bmp.BrowserMobProxy;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.core.har.Har;

public class PerformanceMetrics {

	// public PerformanceUtils perf;
	// public PerformanceMetrics pm;
	public JavascriptExecutor js;
	public WebDriverWait wait;
	public boolean dtEnabled;
	public String CUSTOMERID;
	public String USERID;
	public String PASSWORD;
	public boolean timersEnabled;
	public FileWriter timerlog;
	public boolean acceptNextAlert = true;
	public SimpleDateFormat dtFmt;
	public Date date;
	public Date dateTime;
	public long lastLoadTime;
	public DateFormat requiredFormat;
	public String DATE;
	public String TESTAGENT;
	public String timerName;
	public static long start = 0;
	public static long stop = 0;
	public static long finish = 0;
	public boolean dynaTrace = false;
	public boolean browserTimers = true;
	public String PROFILE = "Tino";
	public String URL = "";

	public static void main(String[] args)
			throws FileNotFoundException, InterruptedException, IOException, ParseException {

		CreateWaterfallJson();
	}

	public String SiteNavigation1(WebDriver driver, String browser, String ENV, String URL, String BUILD,
			String PROJECT) throws IOException {

		String browserVersion = "";

		dtEnabled = dynaTrace;

		/*
		 * System.setProperty("webdriver.chrome.driver",
		 * "C:\\Users\\Administrator\\Downloads\\chromedriver_win32\\chromedriver.exe"
		 * ); driver = new ChromeDriver();
		 */

		dtFmt = new SimpleDateFormat("yyMMdd");
		date = new Date();
		// System.out.println("Im here");
		Capabilities browser1 = ((ChromeDriver) driver).getCapabilities();
		browserVersion = browser1.getVersion();

		browser = browser + browserVersion;
		System.out.println("Browser: " + browser);

		js = (JavascriptExecutor) driver;
		wait = new WebDriverWait(driver, 30);

		AgentData11(ENV, URL);

		// URL = ad.getURL();
		// URL = "https://authvchnform.cognizant.com/vpn/tmindex.html";
		System.out.println("BROWSER==" + browser);
		System.out.println("ENV==" + ENV);
		System.out.println("BUILD==" + BUILD);
		System.out.println("TESTURL==" + URL);
		// System.out.println("TESTAGENT=="+TESTAGENT);

		PerformanceUtils1(js, ENV, browser, BUILD, PROJECT, URL, dynaTrace, browserTimers);
		// System.out.println("perf=="+perf);
		// System.out.println("perfff"+perf.toString());

		if (dtEnabled) {
			startRecording(getProfile(), PROJECT, driver, browser, ENV, BUILD);
		}
		return browser;
	}

	public String SiteNavigationwithCache(WebDriver driver, String browser, String ENV, String URL, String BUILD,
			String PROJECT) throws IOException {

		String browserVersion = "";

		dtEnabled = dynaTrace;

		/*
		 * System.setProperty("webdriver.chrome.driver",
		 * "C:\\Users\\Administrator\\Downloads\\chromedriver_win32\\chromedriver.exe"
		 * ); driver = new ChromeDriver();
		 */

		dtFmt = new SimpleDateFormat("yyMMdd");
		date = new Date();
		// System.out.println("Im here");
		Capabilities browser1 = ((ChromeDriver) driver).getCapabilities();
		browserVersion = browser1.getVersion();

		browser = browser + browserVersion;
		System.out.println("Browser: " + browser);

		js = (JavascriptExecutor) driver;
		wait = new WebDriverWait(driver, 30);

		AgentData11(ENV, URL);

		// URL = ad.getURL();
		// URL = "https://authvchnform.cognizant.com/vpn/tmindex.html";
		System.out.println("BROWSER==" + browser);
		System.out.println("ENV==" + ENV);
		System.out.println("BUILD==" + BUILD);
		System.out.println("TESTURL==" + URL);
		// System.out.println("TESTAGENT=="+TESTAGENT);

		PerformanceUtils1withCache(js, ENV, browser, BUILD, PROJECT, URL, dynaTrace, browserTimers);
		// System.out.println("perf=="+perf);
		// System.out.println("perfff"+perf.toString());

		if (dtEnabled) {
			startRecording(getProfile(), PROJECT, driver, browser, ENV, BUILD);
		}
		return browser;
	}

	public void startRecording(String Profile, String Scenario, WebDriver driver, String browser, String ENV,
			String BUILD) throws IOException {

		String sessionName;
		SimpleDateFormat dtFmt = new SimpleDateFormat("yyMMdd");
		Date date = new Date();
		Profile.replace(" ", "%20");

		driver.get("http://admin:admin@wajxpnasv01:8020/rest/html/management/profiles/" + Profile + "/configurations");

		// Find the dT Profile being used
		int i;
		String dtProfile = "";
		for (i = 1; i < 10; i++) {
			if (driver.findElement(By.xpath("(//ul[@class='switches']//li)[" + i + "]")).getAttribute("class")
					.equals("active")) {
				dtProfile = driver.findElement(By.xpath("(//ul[@class='list']/li)[" + i + "]")).getText()
						.replace(" » active", "");
				i = 10;
			}
		}

		// dynamically build the session name
		sessionName = dtFmt.format(date).toString() + "_Dotcom_" + ENV + "_" + browser + "_" + Scenario + "_"
				+ getBuild(BUILD) + "_" + dtProfile;

		System.out.println("Session Name: " + sessionName);

		Profile.replace("%20", " ");

		driver.findElement(By.linkText(Profile)).click();

		sleep(1500);
		WebElement testName = driver.findElement(By.xpath(".//*[@id='presentableName']"));
		testName.clear();
		testName.sendKeys(sessionName);
		driver.findElement(By.id("isSessionLocked")).click();

		driver.findElement(By.id("but_startrecording")).click();

		driver.quit();
	}

	public void landing(WebDriver driver, String ENV, String URL) throws IOException {

		startTimer("Landing Page");
		if (ENV.toUpperCase().contains("QA12")) {
			driver.get(URL);
		} else if (ENV.equals("Jordan")) {
			driver.get(URL + "webapp/wcs/stores/servlet/sahome?storeId=10101");
		} else {
			driver.get(URL);
		}
		stopTimer();

		/////////////////////////////////////////////////////////////////////////////////
		// Accept Certificate for PERF //
		////////////////////////////////////////////////////////////////////////////////
		try {
			if (driver.getTitle().matches("Certificate Error: Navigation Blocked")) {
				driver.get("javascript:document.getElementById('overridelink').click();");
				sleep(500);
				Alert alert = driver.switchTo().alert();

				try {
					alert.accept();
				} catch (Exception e) {
					System.out.println("Certificate Alert not present.");
				}
			}
		} catch (Exception e) {
		}
	}

	public void setAppServer(WebDriver driver, String ENV) throws IOException {

		if (ENV == "QP2" || ENV == "PRF") {
			String CookieValue = driver.manage().getCookieNamed("OSAJSESSIONID").getValue();
			// System.out.println("ORIGINAL COOKIE VALUE: "+CookieValue);
			driver.manage().deleteCookieNamed("OSAJSESSIONID");
			CookieValue = CookieValue.substring(0, CookieValue.length() - 5).concat("21QP1");
			js.executeScript("document.cookie='OSAJSESSIONID=" + CookieValue + "';");
		} else if (ENV == "QP1") {
			String CookieValue = driver.manage().getCookieNamed("OSAJSESSIONID").getValue();
			// System.out.println("ORIGINAL COOKIE VALUE: "+CookieValue);
			driver.manage().deleteCookieNamed("OSAJSESSIONID");
			CookieValue = CookieValue.substring(0, CookieValue.length() - 5).concat("01QP1");
			js.executeScript("document.cookie='OSAJSESSIONID=" + CookieValue + "';");
		}
	}

	public void newBrowser(WebDriver driver) {
		driver.close();

		killProc();

		driver = new ChromeDriver();

		js = (JavascriptExecutor) driver;
		wait = new WebDriverWait(driver, 30);
		System.out.println("JS----------------" + js);
		setJSX(js);
		System.out.println("completed");
	}

	public void loadURL(String url, String pageName, WebDriver driver, String browser, String TESTURL, String BUILD,
			String ENV) throws IOException, JSONException {
		driver.get(url);
		// pageTimer(pageName, browser, TESTURL, BUILD, ENV);
	}

	public void clearCache() {

		try {
			Runtime.getRuntime().exec("RunDll32.exe InetCpl.cpl,ClearMyTracksByProcess 8");
			sleep(5000);
			System.out.println("Clearcavh complete");
			// Process clearCache =
			// Runtime.getRuntime().exec("C:\\selenium-java-2.43.0\\ClearCacheLite.bat");
			// clearCache.waitFor();
		} catch (Exception e) {
			System.out.println("Failed to clear cache");
		}
	}

	public void findToProceed(String cssPath, WebDriver driver) {
		WebDriverWait wait = new WebDriverWait(driver, 20);

		try {
			sleep(2000);
			// wait.until((ExpectedConditions.presenceOfElementLocated(By.cssSelector(cssPath))));
			sleep(2500);

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("CSS element " + cssPath + " not found on page!");
		}
	}

	public void clearCache(WebDriver driver) {
		try {
			Runtime.getRuntime().exec("RunDll32.exe InetCpl.cpl,ClearMyTracksByProcess 255");
			driver.manage().deleteAllCookies();

			// Runtime.getRuntime().exec("RunDll32.exe
			// InetCpl.cpl,ClearMyTracksByProcess 4351");

			// Process clearCache =
			// Runtime.getRuntime().exec("C:\\selenium-java-2.43.0\\ClearCacheFull.bat");
			// clearCache.waitFor();
			sleep(8000);
		} catch (Exception e) {
			System.out.println("Failed to clear cache");
		}
	}

	public void sleep(int sleepMS) {
		try {
			Thread.sleep(sleepMS);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void killProc() {
		// Kill any existing driver server processes
		try {
			Process killProc = Runtime.getRuntime()
					.exec("C:\\AutomationScripts_Selenium\\IEDriverServer_x64_3.6.0\\kill_IEDriverServer.exe");
			killProc.waitFor();
			killProc = Runtime.getRuntime()
					.exec("C:\\AutomationScripts_Selenium\\chromedriver_win32\\kill_chromedriver.exe");
			killProc.waitFor();
		} catch (IOException e2) {
			System.out.println("Failed to kill the running driver processes");
		} catch (InterruptedException e) {
			System.out.println("Failed to wait for killProc to terminate");
		} catch (NullPointerException e3) {
			System.out.println("Failed to wait for killProc to terminate");
		}
	}

	public void stopRecording(String Profile, WebDriver driver) {

		WebDriverWait wait = new WebDriverWait(driver, 120);

		Profile.replace(" ", "%20");

		driver.get("http://admin:admin@wajxpnasv01:8020/rest/html/management/profiles/" + Profile);

		driver.findElement(By.id("but_stoprecording")).click();

		// wait.until(ExpectedConditions.textToBePresentInElement(By.cssSelector("div#innercontent"),
		// "Recording was stopped."));

		driver.quit();

	}

	public void close(WebDriver driver, String ENV, String URL) throws IOException {
		pageTimerEnd();
		driver.close();
		// Thread.sleep(1000);
		// sleep(600);

		if (dtEnabled) {
			AgentData11(ENV, URL);
			stopRecording(getProfile(), driver);
		}
		driver.quit();

	}

	public String PerformanceUtils1(JavascriptExecutor jsx, String ENV, String browser, String BUILD, String PROJECT,
			String TESTURL, boolean dynaTrace, boolean browserTimers) throws IOException {

		dtEnabled = dynaTrace;
		timersEnabled = browserTimers;

		String TestTURL = TESTURL.replace("http:", "").replace("https:", "").replaceAll("/", "");

		if (!PROJECT.isEmpty()) {
			String Project = PROJECT + "_";
		}

		pageTimerInit(ENV, browser, PROJECT, BUILD);
		return TestTURL;
	}

	public String PerformanceUtils1withCache(JavascriptExecutor jsx, String ENV, String browser, String BUILD,
			String PROJECT, String TESTURL, boolean dynaTrace, boolean browserTimers) throws IOException {

		dtEnabled = dynaTrace;
		timersEnabled = browserTimers;

		String TestTURL = TESTURL.replace("http:", "").replace("https:", "").replaceAll("/", "");

		if (!PROJECT.isEmpty()) {
			String Project = PROJECT + "_";
		}

		pageTimerInitWithCache(ENV, browser, PROJECT, BUILD);
		return TestTURL;
	}

	public FileWriter pageTimerInit(String ENV, String browser, String PROJECT, String BUILD) throws IOException {

		if (timersEnabled == false) {
			return timerlog;
		}

		SimpleDateFormat dtFmt = new SimpleDateFormat("yyMMdd");
		dateTime = new Date();

		requiredFormat = new SimpleDateFormat("MM/dd/yy HH:mm:ss.SSS");
		requiredFormat.setTimeZone(TimeZone.getTimeZone("US/Eastern"));

		// String filename = "test";
		DATE = dtFmt.format(dateTime).toString();
		String filename = DATE + "_DOTCOM" + ENV + "_" + browser + "_" + PROJECT + BUILD;
		String filen = "sample";
		System.out.println("filename" + filename);
		// Get system name
		TESTAGENT = System.getenv().get("COMPUTERNAME").toString();
		System.out.println("TESTAGENT" + TESTAGENT);

		try {
			if (System.getProperty("user.name").equals("amazooji")) {
				timerlog = new FileWriter("C:\\Performance\\PageTimerLogs\\" + filename + ".log");
			} else {
				timerlog = new FileWriter("C:\\Log\\" + filename + ".log");
				System.out.println("timerlog" + timerlog.getEncoding());
			}

			timerlog.append("\n\n-------------" + filename + "-------------\n\n");

			// Print Column Header Info
			timerlog.append(
					"Date/Time\tBrowser\tEnvironment\tBuild\tPageName\tTimeToFirstByte\tFirstImpression\tonLoadTime\tTotalLoadTime\tRedirectTime\t"
							+ "CacheLookup\tDNSLookup\tTCPConnect\tRequestSubmit\tServerTime\tResponseTransmitTime\tDOMLoadingtoInteractive\t"
							+ "DOMLoadingtoLoaded\tDOMLoadingtoComplete\tonLoadExecuteTime\tunLoadTime\tTestURL\tTestAgent\tConnectTime\t"
							+ "TotalServerTime\tClientonLoadTime\tClientTotalTime\tInitialConnection\tDomComplete\tDownloadTime\n");

			timerlog.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Failed to write performance metrics to file.");
		}

		return timerlog;
	}

	public void pageTimerEnd() {
		if (timersEnabled == false) {
			return;
		}
		try {
			timerlog.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Failed to close Page Timer File.");
		}
	}

	public FileWriter pageTimerInitWithCache(String ENV, String browser, String PROJECT, String BUILD)
			throws IOException {

		if (timersEnabled == false) {
			return timerlog;
		}

		SimpleDateFormat dtFmt = new SimpleDateFormat("yyMMdd");
		dateTime = new Date();

		requiredFormat = new SimpleDateFormat("MM/dd/yy HH:mm:ss.SSS");
		requiredFormat.setTimeZone(TimeZone.getTimeZone("US/Eastern"));

		// String filename = "test";
		DATE = dtFmt.format(dateTime).toString();
		String filename = DATE + "_DOTCOM" + ENV + "_" + browser + "_" + PROJECT + BUILD;
		String filen = "sample";
		System.out.println("filename" + filename);
		// Get system name
		TESTAGENT = System.getenv().get("COMPUTERNAME").toString();
		System.out.println("TESTAGENT" + TESTAGENT);

		try {
			if (System.getProperty("user.name").equals("amazooji")) {
				timerlog = new FileWriter("C:\\Performance\\PageTimerLogs\\" + filename + ".log");
			} else {
				timerlog = new FileWriter("C:\\CI_CD\\Log\\" + filename + ".log");
				System.out.println("timerlog" + timerlog.getEncoding());
			}

			timerlog.append("\n\n-------------" + filename + "-------------\n\n");

			// Print Column Header Info
			timerlog.append(
					"Date/Time\tBrowser\tEnvironment\tBuild\tPageName\tTimeToFirstByte\tFirstImpression\tonLoadTime\tTotalLoadTime\tRedirectTime\t"
							+ "CacheLookup\tDNSLookup\tTCPConnect\tRequestSubmit\tServerTime\tResponseTransmitTime\tDOMLoadingtoInteractive\t"
							+ "DOMLoadingtoLoaded\tDOMLoadingtoComplete\tonLoadExecuteTime\tunLoadTime\tTestURL\tTestAgent\tConnectTime\t"
							+ "TotalServerTime\tClientonLoadTime\tClientTotalTime\tInitialConnection\tDomComplete\tDownloadTime\n");

			timerlog.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Failed to write performance metrics to file.");
		}

		return timerlog;
	}

	/*
	 * public void pageTimerEnd() { if (timersEnabled==false) { return; } try {
	 * timerlog.close(); } catch (IOException e) { // TODO Auto-generated catch
	 * block e.printStackTrace();
	 * System.out.println("Failed to close Page Timer File."); } }
	 */

	public JSONObject pageTimer(String PageName, String browser, String TESTURL, String BUILD, String ENV)
			throws IOException, JSONException {
		int temp = 0;
		int script = 0;
		int link = 0;
		int img = 0;
		int video = 0;
		int css = 0;
		int textxml = 0, iframe = 0, other = 0;
		JSONObject browserdata = new JSONObject();
		/*
		 * if (browser.equals("IE8")) { System.out.println("\t"+PageName +
		 * " Loading"); return; }
		 */

		System.out.println(" Page Name ****** " + PageName);

		// System.out.println("I am In ");

		long navigationStart = -1;
		long redirectStart = -1;
		long redirectEnd = -1;
		long unloadEventStart = -1;
		long unloadEventEnd = -1;
		long loadEventEnd = -1;
		long fetchStart = -1;
		long connectEnd = -1;
		long connectStart = -1;
		long domainLookupEnd = -1;
		long domainLookupStart = -1;
		long requestStart = -1;
		long responseStart = -1;
		long domInteractive = -1;
		long domLoading = -1;
		long msFirstPaint = -1;
		long responseEnd = -1;
		long domContentLoadedEventStart = -1;
		long domComplete = -1;
		long domContentLoadedEventEnd = -1;
		long loadEventStart = -1;
		String resourceAPI;
		boolean loading = true;
		String Time = null;

		// System.out.println("I am In1 ");

		// Get the current time in Eastern
		TimeZone timeZone1 = TimeZone.getTimeZone("America/New_York");
		Calendar calendar = new GregorianCalendar();
		calendar.setTimeZone(timeZone1);
		String Hour = String.valueOf(calendar.get(Calendar.HOUR_OF_DAY));
		String Min = String.valueOf(calendar.get(Calendar.MINUTE));

		Date dateTime = new Date();
		// System.out.println("Test date/Time:
		// "+requiredFormat.format(dateTime));

		if (Min.length() == 1) {
			Time = Hour + ":0" + Min;
		} else {
			Time = Hour + ":" + Min;
		}

		// System.out.println("I am In2 ");
		while (loading) {
			try {
				// System.out.println("I am In3 ");
				Thread.sleep(3500);
				// System.out.println("I am In2=4 ");
				System.out.println("BROWSER==" + browser);
				System.out.println("ENV==" + ENV);
				System.out.println("BUILD==" + BUILD);
				System.out.println("TESTURL==" + TESTURL);
				System.out.println("TESTAGENT==" + TESTAGENT);
				System.out.println("loading...loadEventEnd: " + loadEventEnd);
				loadEventEnd = (long) Double
						.valueOf(js.executeScript("return window.performance.timing.loadEventEnd;").toString())
						.doubleValue();
				Thread.sleep(1500);
				System.out.println("I am In 4 ");

				if (loadEventEnd != lastLoadTime && loadEventEnd > 0) {
					loading = false;
					lastLoadTime = loadEventEnd;
				} else {
					System.out.println(
							"loading... lastLoadTime: " + lastLoadTime + "\n           loadEventEnd: " + loadEventEnd);
				}
			} catch (Exception e) {
				// e.printStackTrace();
			}
		}

		// System.out.println("I am I5 ");

		try {
			navigationStart = (long) Double
					.valueOf(js.executeScript("return window.performance.timing.navigationStart;").toString())
					.doubleValue();
		} catch (Exception e) {
			navigationStart = (long) Double
					.valueOf(js.executeScript("return window.performance.timing.fetchStart;").toString()).doubleValue();
		}
		// System.out.println(" navigationStart: "+navigationStart);

		try {
			redirectStart = (long) Double
					.valueOf(js.executeScript("return window.performance.timing.redirectStart;").toString())
					.doubleValue();
			// System.out.println(" redirectStart: "+redirectStart);
		} catch (Exception e) {
			redirectStart = -1;
		}

		try {
			redirectEnd = (long) Double
					.valueOf(js.executeScript("return window.performance.timing.redirectEnd;").toString())
					.doubleValue();
			// System.out.println(" redirectEnd: "+redirectEnd);
		} catch (Exception e) {
			redirectEnd = -1;
		}

		try {
			unloadEventStart = (long) Double
					.valueOf(js.executeScript("return window.performance.timing.unloadEventStart;").toString())
					.doubleValue();
			// System.out.println(" unloadEventStart: "+unloadEventStart);
		} catch (Exception e) {
			unloadEventStart = -1;
		}

		try {
			unloadEventEnd = (long) Double
					.valueOf(js.executeScript("return window.performance.timing.unloadEventEnd;").toString())
					.doubleValue();
			// System.out.println(" unloadEventEnd: "+unloadEventEnd);
		} catch (Exception e) {
			unloadEventEnd = -1;
		}

		try {
			fetchStart = (long) Double
					.valueOf(js.executeScript("return window.performance.timing.fetchStart;").toString()).doubleValue();
			// System.out.println(" fetchStart: "+fetchStart);
			if (navigationStart <= 0) {
				navigationStart = fetchStart;
			}
		} catch (Exception e) {
			fetchStart = -1;
		}

		try {
			connectEnd = (long) Double
					.valueOf(js.executeScript("return window.performance.timing.connectEnd;").toString()).doubleValue();
			// System.out.println(" connectEnd: "+connectEnd);
		} catch (Exception e) {
			connectEnd = -1;
		}

		try {
			connectStart = (long) Double
					.valueOf(js.executeScript("return window.performance.timing.connectStart;").toString())
					.doubleValue();
			// System.out.println(" connectStart: "+connectStart);
		} catch (Exception e) {
			connectStart = -1;
		}

		try {
			domainLookupEnd = (long) Double
					.valueOf(js.executeScript("return window.performance.timing.domainLookupEnd;").toString())
					.doubleValue();
			// System.out.println(" domainLookupEnd: "+domainLookupEnd);
		} catch (Exception e) {
			domainLookupEnd = -1;
		}

		try {
			domainLookupStart = (long) Double
					.valueOf(js.executeScript("return window.performance.timing.domainLookupStart;").toString())
					.doubleValue();
			// System.out.println(" domainLookupStart: "+domainLookupStart);
		} catch (Exception e) {
			domainLookupStart = -1;
		}

		try {
			requestStart = (long) Double
					.valueOf(js.executeScript("return window.performance.timing.requestStart;").toString())
					.doubleValue();
			// System.out.println(" requestStart: "+requestStart);
		} catch (Exception e) {
			requestStart = -1;
		}
		try {
			responseStart = (long) Double
					.valueOf(js.executeScript("return window.performance.timing.responseStart;").toString())
					.doubleValue();
			// System.out.println(" responseStart: "+responseStart);
		} catch (Exception e) {
			responseStart = -1;
		}
		try {
			domInteractive = (long) Double
					.valueOf(js.executeScript("return window.performance.timing.domInteractive;").toString())
					.doubleValue();
			// System.out.println(" domInteractive: "+domInteractive);
		} catch (Exception e) {
			domInteractive = -1;
		}

		try {
			domLoading = (long) Double
					.valueOf(js.executeScript("return window.performance.timing.domLoading;").toString()).doubleValue();
			// System.out.println(" domLoading: "+domLoading);
		} catch (Exception e) {
			domLoading = -1;
		}

		try {
			msFirstPaint = (long) Double
					.valueOf(js.executeScript("return window.performance.timing.msFirstPaint;").toString())
					.doubleValue();
			// System.out.println(" msFirstPaint: "+msFirstPaint);
		} catch (Exception e) {
			msFirstPaint = -1;
		}

		try {
			responseEnd = (long) Double
					.valueOf(js.executeScript("return window.performance.timing.responseEnd;").toString())
					.doubleValue();
			// System.out.println(" responseEnd: "+responseEnd);
		} catch (Exception e) {
			responseEnd = -1;
		}

		try {
			domContentLoadedEventStart = (long) Double
					.valueOf(
							js.executeScript("return window.performance.timing.domContentLoadedEventStart;").toString())
					.doubleValue();
			// System.out.println(" domContentLoadedEventStart:
			// "+domContentLoadedEventStart);
		} catch (Exception e) {
			domContentLoadedEventStart = -1;
		}

		try {
			domComplete = (long) Double
					.valueOf(js.executeScript("return window.performance.timing.domComplete;").toString())
					.doubleValue();
			// System.out.println(" domComplete: "+domComplete);
		} catch (Exception e) {
			domComplete = -1;
		}

		try {
			domContentLoadedEventEnd = (long) Double
					.valueOf(js.executeScript("return window.performance.timing.domContentLoadedEventEnd;").toString())
					.doubleValue();
			// System.out.println(" domContentLoadedEventEnd:
			// "+domContentLoadedEventEnd);
		} catch (Exception e) {
			domContentLoadedEventEnd = -1;
		}

		try {
			loadEventStart = (long) Double
					.valueOf(js.executeScript("return window.performance.timing.loadEventStart;").toString())
					.doubleValue();
			System.out.println("   loadEventStart: " + loadEventStart);
		} catch (Exception e) {
			loadEventStart = -1;
		}

		try {
			resourceAPI = (String) js.executeScript("return JSON.stringify(performance.getEntriesByType('resource'))");
			System.out.println("   resourceAPI: "
					+ js.executeScript("return JSON.stringify(performance.getEntriesByType('resource'))"));
		} catch (Exception e) {
			resourceAPI = (String) js.executeScript("return JSON.stringify(performance.getEntriesByType('resource'))");
			e.printStackTrace();
		}

		org.json.JSONArray jsonarray = new org.json.JSONArray(resourceAPI);

		System.out.println("Length=========>" + jsonarray.length());
		for (int i = 0; i < jsonarray.length(); i++) {
			org.json.JSONObject obj = jsonarray.getJSONObject(i);

			Integer size = (Integer) obj.get("transferSize");
			temp = temp + size;

			String type = (String) obj.get("initiatorType");

			if (type.equalsIgnoreCase("script")) {
				script++;
			} else if (type.equalsIgnoreCase("link")) {
				link++;
			}

			else if (type.equalsIgnoreCase("img")) {
				img++;
			} else if (type.equalsIgnoreCase("video")) {
				video++;
			} else if (type.equalsIgnoreCase("css")) {
				css++;
			} else if (type.equalsIgnoreCase("xmlhttprequest")) {
				textxml++;
			} else if (type.equalsIgnoreCase("iframe")) {
				iframe++;
			} else {
				other++;
			}

			System.out.println(size);
		}

		System.out.println(temp);
		System.out.println("script" + script);
		System.out.println("link" + link);
		System.out.println("img" + img);
		System.out.println("video" + video);
		System.out.println("css" + css);
		System.out.println("xmlhttprequest" + textxml);
		System.out.println("iframe" + iframe);
		System.out.println("other" + other);

		String redirect = "";
		String AppCache = "";
		String dnsLookup = "";
		String tcpConnect = "";
		String requestTime = "";
		String serverTime = "";
		String responseTransmit = "";
		String domLoad2Inter = "";
		String domLoad2DomLoaded = "";
		String domLoad2Complete = "";
		String onloadExecute = "";
		String ttFirstByte = "";
		String ttFirstImpression = "";
		String ttOnLoad = "";
		String Total = "";
		String unLoadTime = "";
		String connectTime = "";
		String totalServerTime = "";
		String clientOnLoadTime = "";
		String clientTotalTime = "";
		String initialConnection = "";
		String DomComplete = "";
		String DownloadTime = "";

		// Calculate Metrics

		if (requestStart >= 0 || navigationStart >= 0) {

			initialConnection = String.valueOf(requestStart - navigationStart);
			System.out.println("initialConnection: " + initialConnection);
		}

		if (requestStart >= 0 || responseStart >= 0) {
			// ttFirstByte = (int) (responseStart-navigationStart);
			ttFirstByte = String.valueOf(responseStart - requestStart);
			// System.out.println("ttFirstByte: "+ttFirstByte);
		}

		if (responseEnd >= 0 || responseStart >= 0) {

			DownloadTime = String.valueOf(responseEnd - responseStart);
			System.out.println("DownloadTime: " + DownloadTime);
		}

		if (domInteractive >= 0 || domLoading >= 0) {
			// domLoad2Inter = (int) (domInteractive-domLoading);
			domLoad2Inter = String.valueOf(domInteractive - domLoading);
			// System.out.println("domLoad2Inter: "+domLoad2Inter);
		}
		if (domContentLoadedEventEnd >= 0 || domLoading >= 0) {
			// domLoad2DomLoaded = (int) (domContentLoadedEventEnd-domLoading);
			domLoad2DomLoaded = String.valueOf(domContentLoadedEventEnd - domLoading);
			// System.out.println("domLoad2DomLoaded: "+domLoad2DomLoaded);
		}
		if (domComplete >= 0 || domLoading >= 0) {
			// domLoad2Complete = (int) (domComplete-domLoading);
			domLoad2Complete = String.valueOf(domComplete - domContentLoadedEventEnd);
			// System.out.println("domLoad2Complete: "+domLoad2Complete);
		}

		if (loadEventEnd >= 0 || navigationStart >= 0) {
			// Total = (int) (loadEventEnd-navigationStart);
			Total = String.valueOf(loadEventEnd - navigationStart);
			// System.out.println("Total: "+Total);
		}

		if (timersEnabled) {

			if (PageName.isEmpty() == false) {
				// Print the Performance Timing Values
				try {
					timerlog.append(requiredFormat.format(dateTime) + "\t" + browser + "\t" + ENV + "\t" + BUILD + "\t"
							+ PageName + "\t" + ttFirstByte + "\t" + ttFirstImpression + "\t" + ttOnLoad + "\t" + Total
							+ "\t" + redirect + "\t" + AppCache + "\t" + dnsLookup + "\t" + tcpConnect + "\t"
							+ requestTime + "\t" + serverTime + "\t" + responseTransmit + "\t" + domLoad2Inter + "\t"
							+ domLoad2DomLoaded + "\t" + domLoad2Complete + "\t" + onloadExecute + "\t" + unLoadTime
							+ "\t" + TESTURL + "\t" + TESTAGENT + "\t" + connectTime + "\t" + totalServerTime + "\t"
							+ clientOnLoadTime + "\t" + clientTotalTime + "\t" + initialConnection + "\t" + DomComplete
							+ "\t" + DownloadTime + "\n");

					timerlog.flush();

				} catch (IOException e1) {
					System.out.println("***Failed to wrtite Performance Timings to file.***");
					e1.printStackTrace();
				}
			}
		}

		System.out.println(
				"\t" + PageName + " Loaded in: " + Total + "ms\t\t(" + loadEventEnd + " - " + navigationStart + ")");

		// Print all timers if results seem fishy
		if (navigationStart == 0 || loadEventEnd == 0 || (loadEventEnd - navigationStart) < 0
				|| (loadEventEnd - navigationStart) > 80000) {
			System.out.println("   responseEnd: " + responseEnd);
			System.out.println("   msFirstPaint: " + msFirstPaint);
			System.out.println("   domLoading: " + domLoading);
			System.out.println("   domComplete: " + domComplete);
			System.out.println("   domInteractive: " + domInteractive);
			System.out.println("   responseStart: " + responseStart);
			System.out.println("   requestStart: " + requestStart);
			System.out.println("   domainLookupStart: " + domainLookupStart);
			System.out.println("   domainLookupEnd: " + domainLookupEnd);
			System.out.println("   connectStart: " + connectStart);
			System.out.println("   domContentLoadedEventEnd: " + domContentLoadedEventEnd);
			System.out.println("   connectEnd: " + connectEnd);
			System.out.println("   fetchStart: " + fetchStart);
			System.out.println("   unloadEventEnd: " + unloadEventEnd);
			System.out.println("   unloadEventStart: " + unloadEventStart);
			System.out.println("   redirectEnd: " + redirectEnd);
			System.out.println("   redirectStart: " + redirectStart);
			System.out.println("   loadEventStart: " + loadEventStart);
			System.out.println("   navigationStart: " + navigationStart);
			System.out.println("   loadEventEnd: " + loadEventEnd);
			System.out.println("   domContentLoadedEventStart: " + domContentLoadedEventStart);
			try {
				Thread.sleep(30000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				// e.printStackTrace();
			}
		}

		browserdata.put("TimeToFirstByte",Long.parseLong(ttFirstByte));
		browserdata.put("DOMLoadingtoLoaded", Long.parseLong(domLoad2DomLoaded));
		browserdata.put("DownloadTime",Long.parseLong(DownloadTime));
		browserdata.put("InitialConnection", Long.parseLong(initialConnection));
		browserdata.put("DOMLoadingtoComplete", Long.parseLong(domLoad2Complete));
		browserdata.put("TotalLoadTime",Long.parseLong(Total));
		browserdata.put("PageName", PageName);
		/*browserdata.put("ClientonLoadTime", clientOnLoadTime);*/
		/*browserdata.put("onLoadTime", ttOnLoad);*/
		/*browserdata.put("CacheLookup", AppCache);
		browserdata.put("onLoadExecuteTime", onloadExecute);*/
	
		/*browserdata.put("DNSLookup", dnsLookup);
		browserdata.put("RedirectTime", redirect);*/
		//browserdata.put("Build", BUILD);
		/*browserdata.put("ResponseTransmitTime", responseTransmit);
		browserdata.put("unLoadTime", unLoadTime);*/
	
		/*browserdata.put("ConnectTime", connectTime);
		browserdata.put("TestAgent", TESTAGENT);*/
		
		/*browserdata.put("ClientTotalTime", clientTotalTime);
		browserdata.put("DomComplete", DomComplete);*/
		
		/*browserdata.put("TCPConnect", tcpConnect);
		browserdata.put("Date/Time", requiredFormat.format(dateTime));
		browserdata.put("RequestSubmit", requestTime);
		browserdata.put("ServerTime", serverTime);
		browserdata.put("TestURL", TESTURL);*/
		/*browserdata.put("DownloadTime", DownloadTime);
		browserdata.put("Environment", ENV);
		browserdata.put("FirstImpression", ttFirstImpression);
		browserdata.put("TotalServerTime", totalServerTime);
		browserdata.put("Browser", browser);
		browserdata.put("DOMLoadingtoInteractive", domLoad2Inter);
		browserdata.put("PageSize", temp);
		browserdata.put("nwrequest", jsonarray.length());
		browserdata.put("script", script);
		browserdata.put("link", link);
		browserdata.put("img", img);
		browserdata.put("video", video);
		browserdata.put("css", css);
		browserdata.put("xmlhttprequest", textxml);
		browserdata.put("iframe", iframe);
		browserdata.put("other", other);*/
		return browserdata;
	}

	public static long startJavaTimer() {

		start = System.currentTimeMillis();
		System.out.println("start*********************" + start);

		return start;

	}

	public static JSONObject stopJavaTimer(String pagename) throws InterruptedException{
		JSONObject timer =new JSONObject();
		/*long totalTime;
		int count = 0;
		long timeWaitedChecking=0;
		
		long visbilityStart = System.currentTimeMillis();
		boolean visibility=checkVisbility(driver, element);
		boolean invisibility=checkInVisbility(driver, element);
		

		long visbilityStop = System.currentTimeMillis();

		if (visibility) {

			System.out.println("Element size is != 0");

			finish = System.currentTimeMillis();

			System.out.println(start + "::" + finish);
			totalTime = (finish - start) - (visbilityStop - visbilityStart);
			System.out.println("totalTime:" + totalTime);
			 timer.put("responsetime", totalTime);
			 timer.put("pagename", pagename);

		}

		else {
			for (;;) {
				
				visbilityStart = System.currentTimeMillis();
				 visibility=checkVisbility(driver, element);
				 invisibility=checkInVisbility(driver, element);
				 visbilityStop = System.currentTimeMillis();
				 timeWaitedChecking+=(visbilityStop - visbilityStart);
				if (visibility) {
					finish = System.currentTimeMillis();
					totalTime = (finish - start)
							- (timeWaitedChecking);
					System.out.println("totalTime:" + totalTime);
					timer.put("responsetime", totalTime);
					 timer.put("pagename", pagename);
					break;

				}

				if (invisibility) {
					System.out.println("Waited for 1 seconds !!!");
					Thread.sleep(1000);

				}
				if (count == 30) {
					System.out
							.println("Waited for 15 seconds !!! Unable to find the element");
					break;

				}
				count++;

			}

		}*/
		
		 stop=System.currentTimeMillis();
		 
		 finish=stop-start;
		 
		 System.out.println("finish*********************"+finish);
		
		 timer.put("responsetime", finish);
		 timer.put("pagename", pagename);
		return timer;
		
		
	}
	public static boolean checkVisbility(WebDriver driver, String element) {

		boolean visibility = (driver.findElements(By.id(element)).size() != 0)
				|| (driver.findElements(By.xpath(element)).size() != 0)
				|| (driver.findElements(By.name(element)).size() != 0);

		return visibility;

	}

	public static boolean checkInVisbility(WebDriver driver, String element) {

		boolean invisibility = (driver.findElements(By.id(element)).size() == 0)
				|| (driver.findElements(By.name(element)).size() == 0)
				|| (driver.findElements(By.xpath(element)).size() == 0);

		return invisibility;

	}

	public String CreateResponseJson(JSONArray timerarray)

	{

		String performancefile = "C:\\AccessibilityReport\\response.json";
		File perf = new File(performancefile);

		if (perf.exists()) {
			System.out.println("response.json File is created");
		}
		FileWriter writerperffile = null;
		try {
			writerperffile = new FileWriter(perf);
			writerperffile.write(timerarray.toString());
			writerperffile.flush();
			writerperffile.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return performancefile;

	}

	public static JSONObject CreateHar(BrowserMobProxy proxy, String pagename, int counter)
			throws InterruptedException {
		JSONObject profiling = new JSONObject();
		String sFileName1 = null;
		List<String> filelist = new ArrayList<String>();
		Thread.sleep(10000);
		Har har1 = proxy.getHar();
		sFileName1 = "C:\\AccessibilityReport\\harfile.json";
		String sFileName2 = "C:\\AccessibilityReport\\examples\\sample" + counter + ".har";

		File harfile1 = new File(sFileName1);
		File harfile2 = new File(sFileName2);
		try {
			har1.writeTo(harfile1);
			har1.writeTo(harfile2);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		proxy.endHar();

		JSONParser jsonparser = new JSONParser();

		try {
			Object obj = jsonparser.parse(new FileReader(harfile1.getAbsolutePath()));

			JSONObject jsonobject = (JSONObject) obj;
			JSONObject log = (JSONObject) jsonobject.get("log");
			JSONArray entries = (JSONArray) log.get("entries");
			System.out.println(entries.size());

			int script = 0;
			int image = 0;
			int html = 0;
			int css = 0;
			int font = 0;
			int other = 0;
			long temp = 0;
			int xhr = 0;
			int video = 0;
			for (int i = 0; i < entries.size(); i++)

			{

				JSONObject entriesget = (JSONObject) entries.get(i);
				// System.out.println("response" +response);
				JSONObject response = (JSONObject) entriesget.get("response");
				JSONObject content = (JSONObject) response.get("content");
				if (content != null) {
					String type = (String) content.get("mimeType");
					// System.out.println(type);
					long size = (long) content.get("size");
					temp = temp + size;

					if (type.contains("javascript") || type.contains("js")) {
						script++;
					}

					else if (type.contains("image")) {
						image++;
					}

					else if ((type.contains("html") || (type.contains("text/plain")) || (type.contains("text/html")))) {
						html++;
					} else if (type.contains("css")) {
						css++;
					} else if ((type.contains("font")) || (type.contains("woff2"))
							|| (type.contains("application/octet-stream"))) {
						font++;
					} else if (type.contains("json")) {
						xhr++;
					} else if (type.contains("video")) {
						video++;
					}

					else {

						other++;
					}

				}

			}
			if (script != 0)
				profiling.put("javascript", script);
			profiling.put("image", image);
			profiling.put("html", html);
			profiling.put("css", css);
			profiling.put("font", font);
			profiling.put("other", other);
			profiling.put("xhr", xhr);
			profiling.put("pagesize", temp);
			profiling.put("nwrequest", entries.size());
			profiling.put("pagename", pagename);
			profiling.put("harpath",
					harfile2.getAbsolutePath().replace(sFileName2, "examples\\sample" + counter + ".har"));

			System.out.println("script" + script);
			System.out.println("image" + image);
			System.out.println("html" + html);
			System.out.println("css" + css);
			System.out.println("font" + font);
			System.out.println("xhr" + xhr);
			System.out.println("other" + other);
			System.out.println("pagesize" + temp);
			System.out.println("nwrequest" + entries.size());

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return profiling;

	}

	public static JSONObject Recommendations(String pagename) {
		// TODO Auto-generated method stub

		String harfile = "C:\\AccessibilityReport\\harfile.json";
		JSONParser parser = new JSONParser();
		JSONObject recommendation = new JSONObject();
		JSONArray array = new JSONArray();
		try {

			Object obj = parser.parse(new FileReader(harfile));

			JSONObject jsonObject = (JSONObject) obj;

			// //String name = (String) jsonObject.get("Name");
			// String author = (String) jsonObject.get("Author");
			// //JSONArray companyList = (JSONArray)
			// jsonObject.get("Company List");

			JSONObject log = (JSONObject) jsonObject.get("log");
			JSONArray entries = (JSONArray) log.get("entries");

			NetworkRecommend t1 = new NetworkRecommend();
			t1.totalrequests = entries.size();

			JSONObject rule1 = new JSONObject();

			rule1.put("ruleHeader", "Validate no. of requests in a page");
			if (t1.totalrequests >= 10) {
				rule1.put("Message", "Total no. of requests in the page:" + +t1.totalrequests
						+ ".Consider reducing total no. of resources getting downloaded");
				rule1.put("Recommendation",
						"If possible combine multiple js/css files from same domain to single js/css.CSS spriting for images also reduces the no. of network calls");
			} else {
				rule1.put("Message", "Total no. of requests in the page:" + +t1.totalrequests
						+ ".No. of requests per page is within the industry standard");
				rule1.put("Recommendation", "none");
			}
			array.add(rule1);

			System.out.println(array);
			JSONObject rule2 = new JSONObject();

			t1.condition1 = t1.checkcachecontrol(entries);
			System.out.println("Total No. Of Requests in the page:" + t1.totalrequests);

			System.out.println("Rule 1 Cache Control:");

			rule2.put("ruleHeader", "Leverage Browsing Cache");
			int chk = 0;
			String message;
			message = "";
			if (!t1.condition1.get("Expiry").isEmpty()) {
				System.out.println(
						"Expires Header is not mentioned for the below resources" + "\n" + t1.condition1.get("Expiry"));
				// rule2.put("Expiries url", t1.condition1.get("Expiry"));
				message = "Url's without any expiry header:" + "\n\n" + t1.condition1.get("Expiry").toString()
						.substring(1).replaceFirst("]", "").replaceAll(",", "\n");
				chk = 1;
			}

			if (!t1.condition1.get("CacheControl").isEmpty()) {
				System.out.println("Cache Control Header is not mentioned for the below resources"
						+ t1.condition1.get("CacheControl"));
				// rule2.put("CacheControl url",
				// t1.condition1.get("CacheControl"));
				message = message + "Url's without cache control header:" + "\n\n" + t1.condition1.get("CacheControl")
						.toString().substring(1).replaceFirst("]", "").replaceAll(",", "\n");
				chk = 1;
			}
			if (!t1.condition1.get("CacheStatus").isEmpty()) {
				System.out.println(
						"Below resources are having 304 as status code" + "\n" + t1.condition1.get("CacheStatus"));
				message += "\n\n" + "Url's 304 status:" + "\n\n" + t1.condition1.get("CacheStatus").toString()
						.substring(1).replaceFirst("]", "").replaceAll(",", "\n");
				chk = 1;
			}
			if (chk == 0) {
				rule2.put("Message", "none");
				rule2.put("Recommendation", "none");
			} else {
				System.out.println("Check" + message);
				rule2.put("Message", message);
				rule2.put("Recommendation",
						"For having a good caching startegy it is recoomended to have cache control and expires header for all the resources, Also as a best practice it is recommended that no resources to get 304 status");
			}
			array.add(rule2);

			t1.condition2 = t1.findCompression(entries);

			JSONObject rule3 = new JSONObject();

			rule3.put("ruleHeader", "Apply Compression Technique");

			System.out.println("Rule 2 Compression Check:");
			if (!t1.condition2.isEmpty()) {
				System.out.println("Compression is not applied to below resources:" + "\n" + t1.condition2);
				rule3.put("Message", "No compression methodologies has been applied for the below URL's:" + "\n\n"
						+ t1.condition2.toString().substring(1).replaceFirst("]", "").replaceAll(",", "\n"));
				rule3.put("Recommendation",
						"It is recommended to apply gzip/deflate/br compression techniques to the resources by which we can minimize the amount of data getting transferred");

			} else {
				rule3.put("Message", "none");
				rule3.put("Recommendation", "none");

			}
			array.add(rule3);

			t1.condition3 = t1.findDuplicates(entries);

			JSONObject rule4 = new JSONObject();

			rule4.put("ruleHeader", "Avoid Duplicate calls");
			message = "";
			System.out.println("Rule 3 Duplicate calls in the page:");
			if (!t1.condition3.isEmpty()) {
				System.out.println("Below duplicate calls are observed in the page:" + "\n\n" + t1.condition3);
				rule4.put("Message", "Below duplicate calls were observed:" + "\n"
						+ t1.condition3.toString().substring(1).replaceFirst("]", "").replaceAll(",", "\n"));
				rule4.put("Recommendation", "Duplicate call needs to be avoided. Remove unnecessary network calls");
			} else {
				rule4.put("Message", "none");
				rule4.put("Recommendation", "none");
			}

			array.add(rule4);

			t1.errorurls = t1.errorenousurls(entries);
			JSONObject rule5 = new JSONObject();

			rule5.put("ruleHeader", "Errorneous Requests");

			List<String> list400 = new ArrayList<String>();
			List<String> list302 = new ArrayList<String>();

			list400 = t1.errorurls.get("404");
			list302 = t1.errorurls.get("302");

			System.out.println("Rule 4 Errorneous requests:");
			if (!list400.isEmpty()) {
				System.out.println("Below errorenous requests(400/404) were observed:" + "\n\n" + list400);
				rule5.put("Message", "Below resources have status code 400/404:" + "\n"
						+ list400.toString().substring(1).replaceFirst("]", "").replaceAll(",", "\n"));
				rule5.put("Recommendation", "Resolve 400/404 resources else remove the unwanted calls");
			} else {
				rule5.put("Message", "none");
				rule5.put("Recommendation", "none");
				System.out.println("No errorenous requests were observed");
			}

			array.add(rule5);

			System.out.println("Rule 5 Avoid redirects:");

			JSONObject rule6 = new JSONObject();

			rule6.put("ruleHeader", "Avoid Redirects");

			if (!list302.isEmpty()) {
				System.out.println("Below requests with 302 status code were observed:" + "\n\n" + list302);
				rule6.put("Message", "Status code 302 was observed for the url's:" + "\n\n"
						+ list302.toString().substring(1).replaceFirst("]", "").replaceAll(",", "\n"));
				rule6.put("Recommendation",
						"Provide direct url to the resource which will reduce the unwanted roundtrip of network call");
			} else {
				System.out.println("No redirects were observed in the page");
				rule6.put("Message", "none");
				rule6.put("Recommendation", "none");
			}
			array.add(rule6);

			t1.timetakingurls = t1.timeconsuming(entries);

			JSONObject rule7 = new JSONObject();

			rule7.put("ruleHeader", "Server time consuming");

			if (!t1.timetakingurls.isEmpty()) {
				rule7.put("Message", "Response time for the below individual request is over 500ms:" + "\n\n"
						+ t1.timetakingurls.toString().substring(1).replaceFirst("]", "").replaceAll(",", "\n"));
				rule7.put("Recommendation",
						"The requests seems to be time consuming from server/network side. This needs to be profiled");
			} else {
				rule7.put("Message", "none");
				rule7.put("Recommendation", "none");
			}
			array.add(rule7);

			t1.cssurls = t1.getDomainurls(entries, ".css");

			JSONObject rule8 = new JSONObject();

			rule8.put("ruleHeader", "Combine CSS and JS");

			message = "";
			chk = 0;
			for (String key : t1.cssurls.keySet()) {
				if (t1.cssurls.get(key).size() > 1) {
					chk = 1;
					message += "Below urls from the domain-" + key + "are the candidates for merging css:" + "\n\n"
							+ t1.cssurls.get(key).toString().substring(1).replaceFirst("]", "").replaceAll(",", "\n");
				}
			}

			t1.jsurls = t1.getDomainurls(entries, ".js");

			int chk1 = 0;
			for (String key : t1.jsurls.keySet()) {
				if (t1.jsurls.get(key).size() > 1) {
					chk1 = 1;
					message += "\n\n" + "Below urls from the domain-" + key + "are the candidates for merging js:"
							+ "\n\n"
							+ t1.jsurls.get(key).toString().substring(1).replaceFirst("]", "").replaceAll(",", "\n");
				}
			}

			if (chk == 1 || chk1 == 1) {
				rule8.put("Message", message);
				rule8.put("Recommendation",
						"Combine the candidate files into a single file or lesser multiple files which would reduce the no. of network calls in the page");
			} else {
				rule8.put("Message", "none");
				rule8.put("Recommendation", "none");
			}
			array.add(rule8);
			
			String Htmlcontent=t1.findHtmlContent(entries);
			System.out.println(Htmlcontent);
			if(Htmlcontent!="")
			{
				
				/*------Check import tag in the document-------*/
				int imprtcnt = 0;
				//compile("@import");
				Pattern pattern = Pattern.compile("@import",Pattern.CASE_INSENSITIVE);
				Matcher matcher = pattern.matcher(Htmlcontent);
				int count = 0;
				while (matcher.find())
				    count++;

				imprtcnt = count;
				
				JSONObject rule9 = new JSONObject();
			    //matcher.
				rule9.put("ruleHeader", "Check for IMPORT tag");
				System.out.println(imprtcnt);
				if (imprtcnt!=0) {
					rule9.put("Message","@IMPORT statement has been used for stylesheets in HTML document around "+imprtcnt+" places");
					rule9.put("Recommendation","Instead use a LINK tag which allows the browser to download stylesheets in parallel.");
				} else {
					rule9.put("Message", "none");
					rule9.put("Recommendation", "none");
				}
				
				array.add(rule9);
				/*********************************************************/
				
				Document html = null;
			            Document body = null;
			            Document head = null;
			            html = Jsoup.parse(Htmlcontent);
		                body = Jsoup.parse(html.getElementsByTag("body").toString());
		                head = Jsoup.parse(html.getElementsByTag("head").toString());
		                
		                pattern = Pattern.compile(">registersod",Pattern.CASE_INSENSITIVE);
		                count = 0;
						while (matcher.find())
						    count++;
						
		                int totSODCount = count;
		                int headSODCount = 0;
		               /**********Check Use of IFrames*******************/ 
		                int emptyiFrameCnt =  html.select("IFRAME").size();
		                
		                JSONObject rule10 = new JSONObject();
					    
						rule10.put("ruleHeader", "Use of IFRAMES");
						
						if (emptyiFrameCnt!=0) {
							rule10.put("Message","IFRAMES has been used in "+emptyiFrameCnt+" places");
							rule10.put("Recommendation","If the contents are nor important than the main page, set these IFRAME(S) SRC dynamically after high priority resources are downloaded");
						} else {
							rule10.put("Message", "none");
							rule10.put("Recommendation", "none");
						}
						
						array.add(rule10);
						
						/************************************************/
				/*********************Collect details of images********************/
		int emptyLinkCount = 0;
		int noscaleCount = 0;
		//String noScaleImgs[];
		//String scaleImgs[];
		int totImgCount = html.select("img").size();
		List<String> noScaleImgs = new ArrayList<String>();
		List<String> scaleImgs = new ArrayList<String>();
		
		for (int i = 0; i < totImgCount; i++)
        {
			//Element temp = html.select("img").get(i).at;
            if(html.select("img").get(i).attr("src") == "")
            {
                emptyLinkCount = emptyLinkCount + 1;
            }

            if(html.select("img").get(i).attr("width") == "" && html.select("img").get(i).attr("height") == "" && html.select("img").get(i).attr("style") == "" && html.select("img").get(i).attr("src") != "")
            {
                noscaleCount = noscaleCount + 1;
               noScaleImgs.add(html.select("img").get(i).attr("src"));
            }
            else
            {
                scaleImgs.add(html.select("img").get(i).attr("src"));
            }
        }

        for (int i = 0; i < html.select("script[src]").size(); i++)
        {
            if(html.select("script[src]").get(i).attr("src") == "")
            {
                emptyLinkCount = emptyLinkCount + 1;
            }
        }

        for (int i = 0; i < html.select("link[href]").size(); i++)
        {
            if( html.select("link[href]").get(i).attr("href") == "")
            {
                emptyLinkCount = emptyLinkCount + 1;
            }
        }
        
        /******************************************************************************************************************/
        
        /*************** Tags with empty SRC or HREF********************/
        
        JSONObject rule11 = new JSONObject();
        
        rule11.put("ruleHeader", "Empty SRC or HREF Tags");
		//
		if (emptyLinkCount!=0) {
			rule11.put("Message",emptyLinkCount+"instance(s) of empty SRC or HREF used in IMG,SCRIPT or LINK tag was found in the HTML document.");
			rule11.put("Recommendation","Remove the tags from the HTML document to avoid unnecessary HTTP call to server.");
		} else {
			rule11.put("Message", "none");
			rule11.put("Recommendation", "none");
		}
		
		array.add(rule11);
		/**************************************************************/
				     
		/*******************************Mention the dimensions of the images**************************************************/
		JSONObject rule12 = new JSONObject();
        
        rule12.put("ruleHeader", "Dimension of Images needs to be mentioned");
        //.toString().substring(1).replaceFirst("]", "")
        if (noscaleCount!=0) {
        	rule12.put("Message",noscaleCount+" instance(s) of IMG has no WIDTH or HEIGHT or STYLE defined. Below are the Images where diemnsion has not been mentioned:"+noScaleImgs.toString().substring(1).replaceFirst("]", "").replaceAll(",", "\n"));
        	rule12.put("Recommendation","Be sure to specify dimensions on the image element or block-level parent to avoid browser reflow or repaint.");
		} else {
			rule12.put("Message", "none");
			rule12.put("Recommendation", "none");
		}
		
		array.add(rule12);
		/**************************************************************************************************************/
		
		/*******************************Avoid Image scaling**************************************************/
		JSONObject rule13 = new JSONObject();
		rule13.put("ruleHeader", "Avoid Image scaling");
		if ((totImgCount - noscaleCount) >0) {
			rule13.put("Message",(totImgCount - noscaleCount)+" instance(s) of IMG has scaling defined. Below are the Images where scaling has been defined:"+scaleImgs.toString().substring(1).replaceFirst("]", "").replaceAll(",", "\n"));
			rule13.put("Recommendation","Make sure right size image used and avoid scaling in HTML");
		} else {
			rule13.put("Message", "none");
			rule13.put("Recommendation", "none");
		}
		
		array.add(rule13);
		/**********************************************************************************/
		/**********************Avoid Charset******************************/
		
		JSONObject rule14 = new JSONObject();
		rule14.put("ruleHeader", "Avoid charset in meta tag");
		
		if(head.select("meta").attr("content").contains("charset"))
		{
			rule14.put("Message","Charset has been mentioned in the meta tag of HTML document");
			rule14.put("Recommendation","Specifying a character set in a meta tag disables the lookahead downloader in IE8.To improve resource download parallelization move the character set to the HTTP ContentType response header.");
		}
		else
		{
			rule14.put("Message", "none");
			rule14.put("Recommendation", "none");
			
		}
		array.add(rule14);
		/****************************************************************/
        
		/**********************Make JS External******************************/
		int intJSCount = html.select("script").size() - (html.select("script[src]").size() + totSODCount);
		JSONObject rule15 = new JSONObject();
		rule15.put("ruleHeader", "Make JS as External");
		
		if(intJSCount>0)
		{
			rule15.put("Message",intJSCount+" instance(s) of internal Javascript has been identified in the HTML page");
			rule15.put("Recommendation","Make internal javascript to external if javascript is not simple.");
		}
		else
		{
			rule15.put("Message", "none");
			rule15.put("Recommendation", "none");
			
		}
		array.add(rule15);
		
		/********************************************************************/
		
		/**************************PUT CSS at Top***************************/
		int cssBodyCount = body.select("style").size();
		JSONObject rule16 = new JSONObject();
		rule16.put("ruleHeader", "PUT CSS at Top");
		if (cssBodyCount > 0 )
        {
			rule16.put("Message",cssBodyCount+" instance(s) of CSS stylesheet has been found in BODY");
			rule16.put("Recommendation","Specifying external stylesheet and inline style blocks in the body of an HTML document can negatively affect the browser's rendering performance. Move the CSS stylsheet to top of the HTML");
        }
		else
		{
			rule16.put("Message", "none");
			rule16.put("Recommendation", "none");
        }
		array.add(rule16);
		
		/********************************************************************/
		
		/******************Put Javascript at bottom****************************/
		
		JSONObject rule17 = new JSONObject();
		rule17.put("ruleHeader", "PUT JavaScript at Bottom");
		
		int jscntHead = (head.select("script").size() - (head.select("script[async]").size() + head.select("script[defer]").size() + headSODCount));
		 //head.select("script:not(script[async],script[defer])").size();
		
		List<String> jsList = new ArrayList<String>();
		 if (jscntHead>0)
		 {
		 for (int i = 0; i < head.select("script:not(script[async],script[defer])").size(); i++)
	        {
			 if(head.select("script:not(script[async],script[defer])").get(i).attr("src") != "")
             {
                 jsList.add(head.select("script:not(script[async],script[defer])").get(i).attr("src"));
             }
	        }
		 //called in HEAD without ASYNC or DEFER attribute can block parallel download of resources.
		 if(jsList.size()>0){
		 rule17.put("Message",jscntHead+" instance(s) of Javascript has been called in HEAD without ASYNC or DEFER attribute can block parallel download of resources. Below are the identified resources:"+jsList.toString().substring(1).replaceFirst("]", ""));
		 }
		 else
		 {
			 rule17.put("Message",jscntHead+" instance(s) of Inline Javascript has been called in HEAD without ASYNC or DEFER attribute which can block parallel download of resources.");
		 }
		 rule17.put("Recommendation","Move the Javascript to the bottom of the HTML or use ASYNC or DEFER attribute");
		 
		 }
		 else
		 {
			 rule17.put("Message", "none");
			 rule17.put("Recommendation", "none");
	        }
			array.add(rule17);     
		
		/***********************************************************************/
		
			}
			
			recommendation.put("recommendation", array);
			recommendation.put("pagename", pagename);
			System.out.println(recommendation);
		
			
			/*recommendation.put("recommendation", array);
			recommendation.put("pagename", pagename);
			System.out.println(recommendation);*/

			// JSONObject chk = (JSONObject) entries.get(0);

			// System.out.println(chk.get("request"));
			// System.out.println("Author: " + author);
			// System.out.println("\nCompany List:");
			// Iterator<String> iterator = companyList.iterator();
			// while (iterator.hasNext()) {
			// System.out.println(iterator.next());
			// }

		} catch (Exception e) {
			e.printStackTrace();
		}
		return recommendation;

	}

	public Map<String, List<String>> checkcachecontrol(JSONArray b1) {
		int size = b1.size();
		List<String> cacheContorlUrl = new ArrayList<String>();
		List<String> expiryUrl = new ArrayList<String>();
		List<String> wrongcachestatus = new ArrayList<String>();

		Map<String, List<String>> map = new HashMap<String, List<String>>();

		String url;

		for (int i = 0; i < size; i++) {
			JSONObject chk = (JSONObject) b1.get(i);

			JSONObject request = (JSONObject) chk.get("request");

			url = request.get("url").toString();

			JSONObject response = (JSONObject) chk.get("response");

			// System.out.println(response.get("status").toString());

			if (response.get("status").toString().contains("304")) {
				wrongcachestatus.add(url);
			}

			JSONArray headers = (JSONArray) response.get("headers");

			// System.out.println(headers);

			int c1 = 0;

			for (int j = 0; j < headers.size(); j++) {
				if (headers.get(j).toString().contains("Cache-Control")) {
					c1 = 1;
					break;
				}
			}

			if (c1 == 0) {
				cacheContorlUrl.add(url);
			}

			int c2 = 0;

			for (int j = 0; j < headers.size(); j++) {
				if (headers.get(j).toString().contains("Expires")) {
					c2 = 1;
					break;
				}
			}

			if (c2 == 0) {
				expiryUrl.add(url);
			}

		}

		// System.out.println(expiryUrl);
		// System.out.println(cacheContorlUrl);
		map.put("Expiry", expiryUrl);
		map.put("CacheControl", cacheContorlUrl);
		map.put("CacheStatus", wrongcachestatus);
		return map;
	}

	public List<String> findCompression(JSONArray b1) {
		int size = b1.size();
		List<String> compressionUrl = new ArrayList<String>();

		String url;

		for (int i = 0; i < size; i++) {
			JSONObject chk = (JSONObject) b1.get(i);

			JSONObject request = (JSONObject) chk.get("request");

			url = request.get("url").toString();

			if (!url.contains(".png") && !url.contains(".gif") && !url.contains(".jpeg") && !url.contains(".jpg")) {
				JSONObject response = (JSONObject) chk.get("response");

				// System.out.println(response.get("status").toString());

				JSONArray headers = (JSONArray) response.get("headers");

				// System.out.println(headers);

				int c1 = 0;

				for (int j = 0; j < headers.size(); j++) {
					if (headers.get(j).toString().contains("Content-Encoding")) {
						c1 = 1;
						break;
					}
				}

				if (c1 == 0) {
					compressionUrl.add(url);
				}

			}
		}

		return compressionUrl;
	}

	public List<String> findDuplicates(JSONArray b1) {
		int size = b1.size();
		List<String> duplicateUrl = new ArrayList<String>();

		Map<String, String> urlwithsize = new HashMap<String, String>();

		String url;

		for (int i = 0; i < size; i++) {
			JSONObject chk = (JSONObject) b1.get(i);

			JSONObject request = (JSONObject) chk.get("request");

			url = request.get("url").toString();

			JSONObject response = (JSONObject) chk.get("response");

			// System.out.println(response.get("bodySize").toString());

			if (urlwithsize.containsKey(url)) {
				if (response.get("bodySize").toString().equalsIgnoreCase(urlwithsize.get(url))) {
					duplicateUrl.add(url);
				}
			} else {
				urlwithsize.put(url, response.get("bodySize").toString());
			}

		}

		return duplicateUrl;
	}

	public Map<String, List<String>> errorenousurls(JSONArray b1) {
		int size = b1.size();
		List<String> url302 = new ArrayList<String>();
		List<String> url404 = new ArrayList<String>();

		Map<String, List<String>> map = new HashMap<String, List<String>>();

		String url;

		for (int i = 0; i < size; i++) {
			JSONObject chk = (JSONObject) b1.get(i);

			JSONObject request = (JSONObject) chk.get("request");

			url = request.get("url").toString();

			JSONObject response = (JSONObject) chk.get("response");

			// System.out.println(response.get("status").toString());

			if (response.get("status").toString().contains("302")) {
				url302.add(url);
			}

			if (response.get("status").toString().contains("400")
					|| response.get("status").toString().contains("404")) {
				url404.add(url);
			}

		}
		map.put("302", url302);
		map.put("404", url404);
		return map;

	}

	public List<String> timeconsuming(JSONArray b1) {
		int size = b1.size();
		List<String> timeconurl = new ArrayList<String>();

		String url;

		for (int i = 0; i < size; i++) {
			JSONObject chk = (JSONObject) b1.get(i);

			JSONObject request = (JSONObject) chk.get("request");

			url = request.get("url").toString();

			float f = Float.parseFloat(chk.get("time").toString());
			// System.out.println(f);
			if (f > 500) {
				timeconurl.add(url);
				// System.out.println(url);

			}

		}

		return timeconurl;
	}

	public Map<String, List<String>> getDomainurls(JSONArray b1, String str) {
		int size = b1.size();

		// List<String> expiryUrl = new ArrayList<String>();
		// List<String> wrongcachestatus = new ArrayList<String>();

		Map<String, List<String>> map = new HashMap<String, List<String>>();

		String url;

		for (int i = 0; i < size; i++) {
			JSONObject chk = (JSONObject) b1.get(i);

			JSONObject request = (JSONObject) chk.get("request");

			url = request.get("url").toString();

			if (url.endsWith(str)) {
				String domain;
				String[] split = url.split("/");
				domain = split[2];
				if (map.containsKey(domain)) {
					List<String> content = new ArrayList<String>();
					content = map.get(domain);
					content.add(url);
					map.put(domain, content);
				} else {
					List<String> content = new ArrayList<String>();
					content.add(url);
					map.put(domain, content);

				}

			}
		}

		for (String key : map.keySet()) {
			System.out.println("Key:" + key + ";Value:" + map.get(key));
		}
		// System.out.println(expiryUrl);
		// System.out.println(cacheContorlUrl);

		return map;

	}

	public static JSONArray CreateWaterfallJson()
			throws InterruptedException, FileNotFoundException, IOException, ParseException {

		JSONArray entriesarray;

		String sFileName1 = ".\\..\\harfile.json";
		File harfile1 = new File(sFileName1);
		JSONParser jsonparser = new JSONParser();

		Object obj = jsonparser.parse(new FileReader(harfile1.getAbsolutePath()));

		JSONObject jsonobject = (JSONObject) obj;
		JSONObject log = (JSONObject) jsonobject.get("log");
		JSONArray entries = (JSONArray) log.get("entries");
		System.out.println(entries.size());

		long size = 0;
		String mimeType = null;
		String text = null;

		entriesarray = new JSONArray();

		for (int i = 0; i < entries.size(); i++)

		{

			JSONObject entriesget = (JSONObject) entries.get(i);
			// System.out.println("response" +response);
			String pageref = (String) entriesget.get("pageref");
			String starttime = (String) entriesget.get("startedDateTime");

			JSONObject request = (JSONObject) entriesget.get("request");

			String method = (String) request.get("method");
			String url = (String) request.get("url");
			JSONObject postData = (JSONObject) request.get("postData");
			if (postData != null) {
				mimeType = (String) postData.get("mimeType");
				text = (String) postData.get("text");
			}
			JSONObject response = (JSONObject) entriesget.get("response");
			long status = (long) response.get("status");

			JSONObject content = (JSONObject) response.get("content");

			if (content != null) {
				String type = (String) content.get("mimeType");
				// System.out.println(type);
				size = (long) content.get("size");

			}

			JSONObject timings = (JSONObject) entriesget.get("timings");

			String ssl = (String) request.get("ssl");
			String connect = (String) request.get("connect");
			String dns = (String) request.get("dns");
			String wait = (String) request.get("wait");
			String blocked = (String) request.get("blocked");
			String send = (String) request.get("send");
			String receive = (String) request.get("receive");

			JSONObject entriesall = new JSONObject();

			entriesall.put("pageref", pageref);
			entriesall.put("startedDateTime", starttime);
			entriesall.put("method", method);
			entriesall.put("url", url);
			entriesall.put("mimeType", mimeType);
			// entriesall.put("text", text);
			entriesall.put("status", status);

			String sizecheck = Long.toString(size);
			if (sizecheck != null)
				entriesall.put("size", size);
			else
				entriesall.put("size", 0);
			if (ssl != null)
				entriesall.put("ssl", ssl);
			else
				entriesall.put("ssl", 0);
			if (connect != null)
				entriesall.put("connect", connect);
			else
				entriesall.put("connect", 0);
			if (dns != null)
				entriesall.put("dns", dns);
			else
				entriesall.put("dns", 0);
			if (wait != null)
				entriesall.put("wait", wait);
			else
				entriesall.put("wait", 0);
			if (blocked != null)
				entriesall.put("blocked", blocked);
			else
				entriesall.put("blocked", 0);
			if (send != null)
				entriesall.put("send", send);
			else
				entriesall.put("send", 0);
			if (receive != null)
				entriesall.put("receive", receive);
			else
				entriesall.put("receive", 0);

			System.out.println("entriesall--->" + entriesall);

			entriesarray.add(entriesall);
		}

		System.out.println("entriesarray--->" + entriesarray);

		String waterfallfile = "C:\\waterfall.json";
		File waterfal = new File(waterfallfile);

		FileWriter writerwaterfal = null;
		try {
			writerwaterfal = new FileWriter(waterfal);
			writerwaterfal.write(entriesarray.toString());
			writerwaterfal.flush();
			writerwaterfal.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (waterfal.exists()) {
			System.out.println("waterfall.json File is created");
		}

		return entriesarray;

	}

	public String responseAPI(WebDriver driver) throws JSONException {
		int temp = 0;
		int script = 0;
		int link = 0;
		int img = 0;
		int video = 0;
		int css = 0;
		int textxml = 0, iframe = 0, other = 0;
		int convert;
		String resourceAPI = null;
		js = (JavascriptExecutor) driver;
		wait = new WebDriverWait(driver, 30);

		JSONArray resourceapi = new JSONArray();
		try {
			resourceAPI = (String) js.executeScript("return JSON.stringify(performance.getEntriesByType('resource'))");
			System.out.println("   resourceAPI: "
					+ js.executeScript("return JSON.stringify(performance.getEntriesByType('resource'))"));
		} catch (Exception e) {
			// resourceAPI = (String) js.executeScript("return
			// JSON.stringify(performance.getEntriesByType('resource'))");
			e.printStackTrace();
		}

		org.json.JSONArray jsonarray = new org.json.JSONArray(resourceAPI);

		System.out.println("Length=========>" + jsonarray.length());
		for (int i = 0; i < jsonarray.length(); i++) {
			org.json.JSONObject obj = jsonarray.getJSONObject(i);

			Integer size = (Integer) obj.get("transferSize");
			temp = temp + size;
			String type = (String) obj.get("initiatorType");

			if (type.equalsIgnoreCase("script")) {
				script++;
			} else if (type.equalsIgnoreCase("link")) {
				link++;
			}

			else if (type.equalsIgnoreCase("img")) {
				img++;
			} else if (type.equalsIgnoreCase("video")) {
				video++;
			} else if (type.equalsIgnoreCase("css")) {
				css++;
			} else if (type.equalsIgnoreCase("xmlhttprequest")) {
				textxml++;
			} else if (type.equalsIgnoreCase("iframe")) {
				iframe++;
			} else {
				other++;
			}

			System.out.println(size);
		}

		System.out.println(temp);
		System.out.println("script" + script);
		System.out.println("link" + link);
		System.out.println("img" + img);
		System.out.println("video" + video);
		System.out.println("css" + css);
		System.out.println("xmlhttprequest" + textxml);
		System.out.println("iframe" + iframe);
		System.out.println("other" + other);
		convert = 1024 * 1024;
		int pagesize = (temp / convert);
		System.out.println(pagesize);

		return resourceAPI;

	}

	public String CreateJson(JSONArray output)

	{

		String performancefile = "C:\\AccessibilityReport\\performance.json";
		File perf = new File(performancefile);

		if (perf.exists()) {
			System.out.println("performance.json File is created");
		}
		FileWriter writerperffile = null;
		try {
			writerperffile = new FileWriter(perf);
			writerperffile.write(output.toString());
			writerperffile.flush();
			writerperffile.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return performancefile;

	}

	public String CreateHarJson(JSONArray hararray)

	{

		String performancefile = "C:\\AccessibilityReport\\log.json";
		File perf = new File(performancefile);

		if (perf.exists()) {
			System.out.println("performance.json File is created");
		}
		FileWriter writerperffile = null;
		try {
			writerperffile = new FileWriter(perf);
			writerperffile.write(hararray.toString());
			writerperffile.flush();
			writerperffile.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return performancefile;

	}

	public String CreateRecommendationsJSON(JSONArray recommendationsarray)

	{

		String performancefile = "C:\\AccessibilityReport\\recommendations.json";
		File perf = new File(performancefile);

		if (perf.exists()) {
			System.out.println("recommendations.json File is created");
		}
		FileWriter writerperffile = null;
		try {
			writerperffile = new FileWriter(perf);
			writerperffile.write(recommendationsarray.toString());
			writerperffile.flush();
			writerperffile.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return performancefile;

	}

	public String CreateJsonCache(JSONArray output)

	{

		String performancefile = ".\\..\\performancecache.json";
		File perf = new File(performancefile);

		if (perf.exists()) {
			System.out.println("performance.json File is created");
		}
		FileWriter writerperffile = null;
		try {
			writerperffile = new FileWriter(perf);
			writerperffile.write(output.toString());
			writerperffile.flush();
			writerperffile.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return performancefile;

	}

	public void ajaxPageTimer(String PageName, int loadTime) throws IOException {
		File file = new File("C:\\MultipleTransaction\\datafile.properties");
		FileInputStream fileInput = new FileInputStream(file);
		Properties properties = new Properties();
		properties.load(fileInput);
		String ENV = properties.getProperty("ENV");
		String browser = properties.getProperty("browser");
		String BUILD = properties.getProperty("BUILD");

		if (browser.equals("IE8")) {
			System.out.println("\t" + PageName + " Loading");
			return;
		}

		dateTime = new Date();

		// Print the Performance Timing Values
		if (timersEnabled) {
			try {
				timerlog.append(requiredFormat.format(dateTime) + "\t" + browser + "\t" + ENV + "\t" + BUILD + "\t"
						+ PageName + "\t\t\t" + loadTime + "\t" + loadTime + "\t\t\t\t\t\t\t\t\t\t\t\t\n");

				timerlog.flush();

			} catch (IOException e1) {
				System.out.println("***Failed to wrtite Performance Timings to file.***");
				e1.printStackTrace();
			}
		}

		System.out.println("\t" + PageName + " Loaded in: " + loadTime + "ms");

	}

	public void setMarker(String marker) {
		if (dtEnabled == false) {
			return;
		}
		try {
			js.executeAsyncScript("_dt_addMark('" + marker + "'); callback();");
		} catch (Exception e) {
			// System.out.println("***Unable to implement marker for "+ marker +
			// ".***");
		}
	}

	public void startTimer(String timer) {
		if (dtEnabled == false) {
			return;
		}
		timerName = timer;

		try {
			js.executeAsyncScript("_dt_setTimerName('" + timer + "'); callback();");
		} catch (Exception e) {
			// System.out.println("***Unable to implement manual dT timer for "+
			// timer + ".***");
		}
		start = System.currentTimeMillis();
	}

	public void stopTimer() {
		if (dtEnabled == false) {
			return;
		}

		finish = System.currentTimeMillis();

		try {
			js.executeAsyncScript("_dt_setTimerName(''); callback();");
		} catch (Exception e) {
			// System.out.println("***Unable to stop manual dT timer.***");
			// e.printStackTrace();
		}
	}

	public void setJSX(JavascriptExecutor newJSX) {
		js = newJSX;
	}

	public String getBuild(String BUILD) throws IOException {

		return BUILD;
	}

	public void AgentData11(String Env, String URL) {
		URL = URL;
		;
		if (Env == "sample") {
			URL = URL;
		}
		// Use either Perf or Prod based on TEST parameter.
		/*
		 * if (Env=="PRD") { //URL = "https://order.staplesadvantage.com/"; URL
		 * = "http://www.staplesadvantage.com/"; //URL =
		 * "http://np1.staplesadvantage.com/shop"; //URL =
		 * "https://np2.staplesadvantage.com/";
		 * 
		 * // Assign production credentials CUSTOMERID="10063345BOS";
		 * USERID="FRAPERF2"; PASSWORD = "performance";
		 * 
		 * // Production Federal test customer // CUSTOMERID="0001027892NAT"; //
		 * USERID="STAPLESADMIN1"; // PASSWORD = "staplesadmin1"; // SHIPTO =
		 * "CC-ACFJFKFEDERL (BOSTON, MA)"; // CHECKOUT=false; } else if
		 * (Env=="NP1") { URL = "http://np1.staplesadvantage.com/";
		 * 
		 * // Assign production credentials CUSTOMERID="10063345BOS";
		 * USERID="FRAPERF2"; PASSWORD = "performance"; } else if (Env=="PRF") {
		 * URL = "https://advantage.sltest.com/"; } else if (Env=="AKAPRF") {
		 * URL = "https://aka-sltest.staplesadvantage.com/"; } else if
		 * (Env=="QP1") { URL = "https://qp1.staplesadvantage.com/"; } else if
		 * (Env=="QP2") { URL = "https://qp2.staplesadvantage.com/"; } else if
		 * (Env=="SOASTAPRF") { URL = "https://advantage.sltest.com/"; } else if
		 * (Env=="QA1") { URL = "https://qa1.staplesadvantage.com/";
		 * //USERID="HAYELEI";
		 * 
		 * // Assign production credentials CUSTOMERID="1012054NAT";
		 * USERID="PERFUSER2"; PASSWORD = "staples"; } else if (Env=="AKAQA1") {
		 * URL = "https://aka-qa1.staplesadvantage.com/"; //USERID="HAYELEI";
		 * 
		 * // Assign production credentials CUSTOMERID="1012054NAT";
		 * USERID="PERFUSER2"; PASSWORD = "staples"; } else if (Env=="QA2") {
		 * URL = "https://qa2.staplesadvantage.com/";
		 * 
		 * CUSTOMERID="1410005BOS"; USERID="PERFUSER2"; PASSWORD = "staples"; }
		 * else if (Env=="AKAQA2") { URL =
		 * "https://aka-qa2.staplesadvantage.com/";
		 * 
		 * CUSTOMERID="1410005BOS"; USERID="PERFUSER2"; PASSWORD = "staples"; }
		 * else if (Env=="QA3") { URL = "https://qa3.staplesadvantage.com/";
		 * 
		 * // CUSTOMERID="1018242NAT"; // USERID="PERFUSER2";
		 * 
		 * CUSTOMERID="0916191043001BOS"; USERID="ADMIN";
		 * 
		 * PASSWORD = "staples"; } else if (Env=="AKAQA3") { URL =
		 * "https://aka-qa3.staplesadvantage.com/";
		 * 
		 * CUSTOMERID="1018242NAT"; USERID="PERFUSER2"; PASSWORD = "staples";
		 * }else if (Env=="QA7") { URL = "http://QA7.staplesadvantage.com/";
		 * CUSTOMERID="1018242NAT"; USERID="TNTADMIN1"; PASSWORD = "staples";
		 * }else if (Env=="AKAQA7") { URL =
		 * "http://AKA-QA7.staplesadvantage.com/";
		 * CUSTOMERID="1018342NAT";//"1018242NAT"; USERID="ADMIN";//"TNTADMIN1";
		 * PASSWORD = "staples"; } else if (Env=="DEV8") { URL =
		 * "http://aadvd8nasv01.staples.com/";
		 * 
		 * //CUSTOMERID="1018242NAT"; //USERID="PERFUSER0";
		 * 
		 * //CUSTOMERID="1018342NAT"; //L+ //USERID="SYSTEM";
		 * CUSTOMERID="0001006933001BOS"; //NL+ USERID="SYSTEM"; PASSWORD =
		 * "staples"; } else if (Env=="QA8") { URL =
		 * "http://QA8.staplesadvantage.com/"; /*CUSTOMERID="0001018242001NAT";
		 * //NL+ USERID="ADMIN"; PASSWORD = "staples";
		 */
		// CUSTOMERID="0001417863001RCH"; //L+
		// USERID="ADMIN"; //Padma

		// Regression User (Based off 1018242NAT / TNTADMIN3)
		// CUSTOMERID="1018242NAT";
		// USERID="PERFUSER2";

		/*
		 * CUSTOMERID="1013904LA"; USERID="TNTADMIN3";
		 * 
		 * PASSWORD = "staples"; }else if (Env=="QA12") { URL =
		 * "http://qa12.staplesadvantage.com/";
		 * 
		 * // CUSTOMERID="1018242NAT"; // USERID="PERFTEST2";
		 * 
		 * CUSTOMERID="0001410005001BOS"; USERID="PERFUSER2"; PASSWORD =
		 * "staples"; } else if (Env=="AKAQA12") { URL =
		 * "http://aka-qa12.staplesadvantage.com/";
		 * 
		 * // CUSTOMERID="1018242NAT"; // USERID="PERFTEST2";
		 * 
		 * /*CUSTOMERID="0001410005001BOS"; USERID="PERFUSER2"; PASSWORD =
		 * "staples"; } else if (Env=="Jordan") { URL =
		 * "http://qbmo-natitlt130.staplesams.com/";
		 * 
		 * CUSTOMERID="1018342NAT"; USERID="RRADMIN01"; PASSWORD = "staples"; }
		 * else { // Assign PERF environment credentials // URL =
		 * "https://qp1.staplesadvantage.com/"; //URL =
		 * "http://auth.staples.com/?campaign=homecertona/"; URL =
		 * "https://auth.staples.com/Ink-Toner-Finder/cat_SC43?campaign=vioby";
		 * // URL = "https://auth.staples.com/Ink-Toner-Finder/cat_SC43"; //URL
		 * = "https://advantage.sltest.com/"; //URL =
		 * "https://aka-sltest.staplesadvantage.com/";
		 * //CUSTOMERID="0001410005001BOS"; // USERID="ALTSTRESS4012"; //
		 * USERID="DEALSSTRESS5"; /*CUSTOMERID="0001412371DC"; USERID="DSAFI";
		 * PASSWORD = "staples";
		 */
	}

	// Set the Perf login credentials DO NOT CHANGE!!
	/*
	 * if (Env.equals("PRF") || Env.equals("AKAPRF") || Env.equals("QP1") ||
	 * Env.equals("QP2") || Env.equals("PRFSOASTA")) {
	 * CUSTOMERID="0001410005001BOS"; USERID="ALTSTRESS4012"; PASSWORD =
	 * "staples"; }
	 * 
	 * }
	 */

	public String getURL() {
		return URL;
	}

	/*
	 * public String getCustID () { return CUSTOMERID; }
	 * 
	 * public String getUserID () { return USERID; }
	 * 
	 * public String getPasswrod () { return PASSWORD; }
	 */

	public String getProfile() {
		return PROFILE;
	}

	public static JSONObject TxtParser(File srcFile) throws IOException {
		// TODO Auto-generated method stub

		JSONObject finalobj = new JSONObject();
		// JSONObject finalobj=new JSONObject();
		JSONArray objarray = new JSONArray();
		FileReader fr = new FileReader(srcFile);
		BufferedReader br = new BufferedReader(fr);
		String header = null;
		String str;
		int count = 0;
		String[] names = null;
		String[] values = null;
		int lines = 0;

		while ((str = br.readLine()) != null) {

			if (str.contains("Date")) {
				header = str;
				lines++;
				str = br.readLine();
			}
			if (lines > 0) {
				JSONObject output = new JSONObject();
				System.out.println("lines" + lines);
				System.out.println("values str" + str);
				StringTokenizer strtkn = new StringTokenizer(header, "\t");
				StringTokenizer strtkn1 = new StringTokenizer(str, "\t");
				count = strtkn.countTokens();
				/*
				 * System.out.println("nnnn"+strtkn.countTokens());
				 * System.out.println("ppp"+strtkn1.countTokens());
				 */
				System.out.println("counttttt" + count);
				names = new String[count];
				values = new String[count];
				for (int i = 0; i < count; i++) {
					String name = strtkn.nextToken();
					String value = strtkn1.nextToken();
					/*
					 * if (name.matches("Browser") || name.matches("PageName")
					 * || name.matches("TimeToFirstByte") ||
					 * name.matches("RedirectTime") || name.matches("TestURL")
					 * || name.matches("TotalServerTime")) {
					 */
					System.out.println("before values" + name + value);
					names[i] = name;
					values[i] = value;
					output.put(name, value);

					// objarray.add(output);
				}
				// }
				/*
				 * if(recommarray.size()!=0) { output.put("recommendations",
				 * recommarray); } else if(recommarray.size()==0) {
				 * output.put("recommendations",
				 * "Reccomendations not available"); }
				 * 
				 * if(mitiarray.size()!=0) { output.put("mitigation",
				 * mitiarray); } else if(mitiarray.size()==0) {
				 * output.put("mitigation", "Mitigation not available"); }
				 */

				System.out.println("output json at each i" + output);
				objarray.add(output);
				/* objarray.add(recommarray); */

			}

		}
		finalobj.put("output", objarray);
		/* finalobj.put("recommendations", recommarray); */
		System.out.println("finallyyyy" + objarray);

		File file = new File("C:/Jar/datafile.properties");
		FileInputStream fileInput = new FileInputStream(file);
		Properties properties = new Properties();
		properties.load(fileInput);
		// String performancefile =
		// properties.getProperty("path")+"\\"+"performance.json";
		// String performancefile
		// ="C:\\Users\\Sindhuja.Raja\\Documents\\AccessibilityReport\\CTS\\performance.json";
		String performancefile = "C:\\Users\\Sindhuja.Raja\\Documents\\AccessibilityReport\\CTS\\performancecache.json";
		System.out.println(performancefile);
		File perf = new File(performancefile);

		if (perf.exists()) {
			System.out.println("performance.json File is created");
		}
		FileWriter writerperffile = null;
		try {
			writerperffile = new FileWriter(perf);
			writerperffile.write(finalobj.toString());
			writerperffile.flush();
			writerperffile.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		// finalobj=(JSONObject)(objarray);
		/*
		 * for(int i=0;i<objarray.size();i++) { finalobj.put( objarray)); }
		 */
		return finalobj;
	}

	public static JSONObject TxtParserWithCache(File srcFile, JSONArray recommarray, JSONArray mitiarray)
			throws IOException {
		// TODO Auto-generated method stub

		JSONObject finalobj = new JSONObject();
		// JSONObject finalobj=new JSONObject();
		JSONArray objarray = new JSONArray();
		FileReader fr = new FileReader(srcFile);
		BufferedReader br = new BufferedReader(fr);
		String header = null;
		String str;
		int count = 0;
		String[] names = null;
		String[] values = null;
		int lines = 0;

		while ((str = br.readLine()) != null) {

			if (str.contains("Date")) {
				header = str;
				lines++;
				str = br.readLine();
			}
			if (lines > 0) {
				JSONObject output = new JSONObject();
				System.out.println("lines" + lines);
				System.out.println("values str" + str);
				StringTokenizer strtkn = new StringTokenizer(header, "\t");
				StringTokenizer strtkn1 = new StringTokenizer(str, "\t");
				count = strtkn.countTokens();
				/*
				 * System.out.println("nnnn"+strtkn.countTokens());
				 * System.out.println("ppp"+strtkn1.countTokens());
				 */
				System.out.println("counttttt" + count);
				names = new String[count];
				values = new String[count];
				for (int i = 0; i < count; i++) {
					String name = strtkn.nextToken();
					String value = strtkn1.nextToken();
					/*
					 * if (name.matches("Browser") || name.matches("PageName")
					 * || name.matches("TimeToFirstByte") ||
					 * name.matches("RedirectTime") || name.matches("TestURL")
					 * || name.matches("TotalServerTime")) {
					 */
					System.out.println("before values" + name + value);
					names[i] = name;
					values[i] = value;
					output.put(name, value);

					// objarray.add(output);
				}
				// }

				if (recommarray.size() != 0) {
					output.put("recommendations", recommarray);
				} else if (recommarray.size() == 0) {
					output.put("recommendations", "Reccomendations not available");
				}

				if (mitiarray.size() != 0) {
					output.put("mitigation", mitiarray);
				} else if (mitiarray.size() == 0) {
					output.put("mitigation", "Mitigation not available");
				}

				System.out.println("output json at each i" + output);
				objarray.add(output);
				/* objarray.add(recommarray); */

			}

		}
		finalobj.put("output", objarray);
		/* finalobj.put("recommendations", recommarray); */
		System.out.println("finallyyyy" + objarray);

		// finalobj=(JSONObject)(objarray);
		/*
		 * for(int i=0;i<objarray.size();i++) { finalobj.put( objarray)); }
		 */
		return finalobj;
	}

	public static void takeSnapShot(String nftcxurl) throws Exception {

		String jpgpath = "C:\\AccessibilityReport\\test.jpg";
		System.setProperty("webdriver.chrome.driver", "C:\\Jar\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		driver.get(nftcxurl);

		driver.manage().window().maximize();

		Thread.sleep(2000);

		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		// Now you can do whatever you need to do with it, for example copy
		// somewhere
		FileUtils.copyFile(scrFile, new File(jpgpath));

		driver.quit();

		SystemDateandTime();

	}

	public static void SystemDateandTime() throws IOException {

		// Create object of SimpleDateFormat class and decide the format
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");

		// get current date time with Date()
		Date date = new Date();

		// Now format the date
		String date1 = dateFormat.format(date);

		// Print the Date
		System.out.println("Current date and time is " + date1);

		JSONObject reporttime = new JSONObject();

		reporttime.put("datetime", date1);
		File report = new File("C:\\AccessibilityReport" + "\\reporttime.json");
		report.createNewFile();

		FileWriter reportfile = new FileWriter(report);
		reportfile.write(reporttime.toString());
		reportfile.flush();
		reportfile.close();

	}

}
