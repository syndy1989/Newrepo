package com.charles;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Iterator;

import org.brotli.dec.BrotliInputStream;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.DeflaterInputStream;
import java.util.zip.GZIPInputStream;


public class NetworkRecommend {
	public int totalrequests;

	public Map<String, List<String>> condition1 = new HashMap<String, List<String>>();

	public List<String> condition2 = new ArrayList<String>();

	public List<String> condition3 = new ArrayList<String>();

	public Map<String, List<String>> errorurls = new HashMap<String, List<String>>();

	public Map<String, List<String>> cssurls = new HashMap<String, List<String>>();
	public Map<String, List<String>> jsurls = new HashMap<String, List<String>>();

	public List<String> timetakingurls = new ArrayList<String>();
	
	
	public static void main(String[] args) throws InterruptedException, IOException{
		
		 //NetRecommend("C:\\AccessibilityReport_MultipleTransaction\\examples\\sample1.har", "Home");
		NetRecommend("C:\\AccessibilityReport\\har.har", "Home");
		
	}

	public static JSONObject NetRecommend(String harfile,String pagename) {
		// TODO Auto-generated method stub
		JSONParser parser = new JSONParser();
		JSONObject recommendation = new JSONObject();
		JSONArray array = new JSONArray();
		try {

			Object obj = parser.parse(new FileReader(harfile));

			JSONObject jsonObject = (JSONObject) obj;

			// //String name = (String) jsonObject.get("Name");
			// String author = (String) jsonObject.get("Author");
			// //JSONArray companyList = (JSONArray)
			// jsonObject.get("Company List");

			JSONObject log = (JSONObject) jsonObject.get("log");
			JSONArray entries = (JSONArray) log.get("entries");

			NetworkRecommend t1 = new NetworkRecommend();
			t1.totalrequests = entries.size();

			JSONObject rule1 = new JSONObject();
			
			rule1.put("ruleHeader", "Validate no. of requests in a page");
			if (t1.totalrequests >= 10) {
				rule1.put(
						"Message",
						"Total no. of requests in the page:"+
								+ t1.totalrequests+
								 ".Consider reducing total no. of resources getting downloaded");
				rule1.put(
						"Recommendation",
						"If possible combine multiple js/css files from same domain to single js/css.CSS spriting for images also reduces the no. of network calls");
			} else {
				rule1.put(
						"Message",
						"Total no. of requests in the page:"+
								+ t1.totalrequests+
								".No. of requests per page is within the industry standard");
				rule1.put("Recommendation", "none");
			}
			array.add(rule1);

			System.out.println(array);
			JSONObject rule2 = new JSONObject();

			t1.condition1 = t1.checkcachecontrol(entries);
			System.out.println("Total No. Of Requests in the page:"
					+ t1.totalrequests);

			System.out.println("Rule 1 Cache Control:");

			rule2.put("ruleHeader", "Leverage Browsing Cache");
			int chk = 0;
			String message;
			message = "";
			if (!t1.condition1.get("Expiry").isEmpty()) {
				System.out
						.println("Expires Header is not mentioned for the below resources"+"\n"
								+ t1.condition1.get("Expiry"));
				// rule2.put("Expiries url", t1.condition1.get("Expiry"));
				message = "Url's without any expiry header:"+"\n\n"
						+ t1.condition1.get("Expiry").toString().substring(1)
								.replaceFirst("]", "").replaceAll(",", "\n");
				chk = 1;
			}

			if (!t1.condition1.get("CacheControl").isEmpty()) {
				System.out
						.println("Cache Control Header is not mentioned for the below resources"
								+ t1.condition1.get("CacheControl"));
				// rule2.put("CacheControl url",
				// t1.condition1.get("CacheControl"));
				message = message
						+ "Url's without cache control header:"+"\n\n"
						+ t1.condition1.get("CacheControl").toString()
								.substring(1).replaceFirst("]", "").replaceAll(",", "\n");
				chk = 1;
			}
			if (!t1.condition1.get("CacheStatus").isEmpty()) {
				System.out
						.println("Below resources are having 304 as status code"+"\n"
								+ t1.condition1.get("CacheStatus"));
				message += "\n\n"+"Url's 304 status:"+"\n\n"
						+ t1.condition1.get("CacheStatus").toString()
								.substring(1).replaceFirst("]", "").replaceAll(",", "\n");
				chk = 1;
			}
			if (chk == 0) {
				rule2.put("Message", "none");
				rule2.put("Recommendation", "none");
			} else {
				System.out.println("Check" + message);
				rule2.put("Message", message);
				rule2.put(
						"Recommendation",
						"For having a good caching startegy it is recoomended to have cache control and expires header for all the resources, Also as a best practice it is recommended that no resources to get 304 status");
			}
			array.add(rule2);

			t1.condition2 = t1.findCompression(entries);

			JSONObject rule3 = new JSONObject();

			rule3.put("ruleHeader", "Apply Compression Technique");

			System.out.println("Rule 2 Compression Check:");
			if (!t1.condition2.isEmpty()) {
				System.out
						.println("Compression is not applied to below resources:"+"\n"
								+ t1.condition2);
				rule3.put("Message",
						"No compression methodologies has been applied for the below URL's:"+"\n\n"
								+ t1.condition2.toString().substring(1)
										.replaceFirst("]", "").replaceAll(",", "\n"));
				rule3.put(
						"Recommendation",
						"It is recommended to apply gzip/deflate/br compression techniques to the resources by which we can minimize the amount of data getting transferred");

			} else {
				rule3.put("Message", "none");
				rule3.put("Recommendation", "none");

			}
			array.add(rule3);

			t1.condition3 = t1.findDuplicates(entries);

			JSONObject rule4 = new JSONObject();

			rule4.put("ruleHeader", "Avoid Duplicate calls");
			message = "";
			System.out.println("Rule 3 Duplicate calls in the page:");
			if (!t1.condition3.isEmpty()) {
				System.out
						.println("Below duplicate calls are observed in the page:"+"\n\n"
								+ t1.condition3);
				rule4.put("Message",
						"Below duplicate calls were observed:"+"\n"
								+ t1.condition3.toString().substring(1)
										.replaceFirst("]", "").replaceAll(",", "\n"));
				rule4.put("Recommendation",
						"Duplicate call needs to be avoided. Remove unnecessary network calls");
			} else {
				rule4.put("Message", "none");
				rule4.put("Recommendation", "none");
			}

			array.add(rule4);

			t1.errorurls = t1.errorenousurls(entries);
			JSONObject rule5 = new JSONObject();

			rule5.put("ruleHeader", "Errorneous Requests");

			List<String> list400 = new ArrayList<String>();
			List<String> list302 = new ArrayList<String>();

			list400 = t1.errorurls.get("404");
			list302 = t1.errorurls.get("302");

			System.out.println("Rule 4 Errorneous requests:");
			if (!list400.isEmpty()) {
				System.out
						.println("Below errorenous requests(400/404) were observed:"+"\n\n"
								+ list400);
				rule5.put(
						"Message",
						"Below resources have status code 400/404:"+"\n"
								+ list400.toString().substring(1)
										.replaceFirst("]", "").replaceAll(",", "\n"));
				rule5.put("Recommendation",
						"Resolve 400/404 resources else remove the unwanted calls");
			} else {
				rule5.put("Message", "none");
				rule5.put("Recommendation", "none");
				System.out.println("No errorenous requests were observed");
			}

			array.add(rule5);

			System.out.println("Rule 5 Avoid redirects:");

			JSONObject rule6 = new JSONObject();

			rule6.put("ruleHeader", "Avoid Redirects");

			if (!list302.isEmpty()) {
				System.out
						.println("Below requests with 302 status code were observed:"+"\n\n"
								+ list302);
				rule6.put(
						"Message",
						"Status code 302 was observed for the url's:"+"\n\n"
								+ list302.toString().substring(1)
										.replaceFirst("]", "").replaceAll(",", "\n"));
				rule6.put(
						"Recommendation",
						"Provide direct url to the resource which will reduce the unwanted roundtrip of network call");
			} else {
				System.out.println("No redirects were observed in the page");
				rule6.put("Message", "none");
				rule6.put("Recommendation", "none");
			}
			array.add(rule6);

			t1.timetakingurls = t1.timeconsuming(entries);

			JSONObject rule7 = new JSONObject();

			rule7.put("ruleHeader", "Server time consuming");

			if (!t1.timetakingurls.isEmpty()) {
				rule7.put("Message",
						"Response time for the below individual request is over 500ms:"+"\n\n"
								+ t1.timetakingurls.toString().substring(1)
										.replaceFirst("]", "").replaceAll(",", "\n"));
				rule7.put(
						"Recommendation",
						"The requests seems to be time consuming from server/network side. This needs to be profiled");
			} else {
				rule7.put("Message", "none");
				rule7.put("Recommendation", "none");
			}
			array.add(rule7);

			t1.cssurls = t1.getDomainurls(entries, ".css");

			JSONObject rule8 = new JSONObject();

			rule8.put("ruleHeader", "Combine CSS and JS");

			message = "";
			chk = 0;
			for (String key : t1.cssurls.keySet()) {
				if (t1.cssurls.get(key).size() > 1) {
					chk = 1;
					message += "Below urls from the domain-"
							+ key
							+ "are the candidates for merging css:"+"\n\n"
							+ t1.cssurls.get(key).toString().substring(1)
									.replaceFirst("]", "").replaceAll(",", "\n");
				}
			}

			t1.jsurls = t1.getDomainurls(entries, ".js");

			int chk1 = 0;
			for (String key : t1.jsurls.keySet()) {
				if (t1.jsurls.get(key).size() > 1) {
					chk1 = 1;
					message += "\n\n"+"Below urls from the domain-"
							+ key
							+ "are the candidates for merging js:"+"\n\n"
							+ t1.jsurls.get(key).toString().substring(1)
									.replaceFirst("]", "").replaceAll(",", "\n");
				}
			}

			if (chk == 1 || chk1 == 1) {
				rule8.put("Message", message);
				rule8.put(
						"Recommendation",
						"Combine the candidate files into a single file or lesser multiple files which would reduce the no. of network calls in the page");
			} else {
				rule8.put("Message", "none");
				rule8.put("Recommendation", "none");
			}
			array.add(rule8);
			/*recommendation.put("recommendation", array);
			recommendation.put("pagename", pagename);
			System.out.println(recommendation);*/

			// JSONObject chk = (JSONObject) entries.get(0);

			// System.out.println(chk.get("request"));
			// System.out.println("Author: " + author);
			// System.out.println("\nCompany List:");
			// Iterator<String> iterator = companyList.iterator();
			// while (iterator.hasNext()) {
			// System.out.println(iterator.next());
			// }
			
			
			String Htmlcontent=t1.findHtmlContent(entries);
			System.out.println(Htmlcontent);
			if(Htmlcontent!="")
			{
				
				/*------Check import tag in the document-------*/
				int imprtcnt = 0;
				//compile("@import");
				Pattern pattern = Pattern.compile("@import",Pattern.CASE_INSENSITIVE);
				Matcher matcher = pattern.matcher(Htmlcontent);
				int count = 0;
				while (matcher.find())
				    count++;

				imprtcnt = count;
				
				JSONObject rule9 = new JSONObject();
			    //matcher.
				rule9.put("ruleHeader", "Check for IMPORT tag");
				System.out.println(imprtcnt);
				if (imprtcnt!=0) {
					rule9.put("Message","@IMPORT statement has been used for stylesheets in HTML document around "+imprtcnt+" places");
					rule9.put("Recommendation","Instead use a LINK tag which allows the browser to download stylesheets in parallel.");
				} else {
					rule9.put("Message", "none");
					rule9.put("Recommendation", "none");
				}
				
				array.add(rule9);
				/*********************************************************/
				
				Document html = null;
			            Document body = null;
			            Document head = null;
			            html = Jsoup.parse(Htmlcontent);
		                body = Jsoup.parse(html.getElementsByTag("body").toString());
		                head = Jsoup.parse(html.getElementsByTag("head").toString());
		                
		                pattern = Pattern.compile(">registersod",Pattern.CASE_INSENSITIVE);
		                count = 0;
						while (matcher.find())
						    count++;
						
		                int totSODCount = count;
		                int headSODCount = 0;
		               /**********Check Use of IFrames*******************/ 
		                int emptyiFrameCnt =  html.select("IFRAME").size();
		                
		                JSONObject rule10 = new JSONObject();
					    
						rule10.put("ruleHeader", "Use of IFRAMES");
						
						if (emptyiFrameCnt!=0) {
							rule10.put("Message","IFRAMES has been used in "+emptyiFrameCnt+" places");
							rule10.put("Recommendation","If the contents are nor important than the main page, set these IFRAME(S) SRC dynamically after high priority resources are downloaded");
						} else {
							rule10.put("Message", "none");
							rule10.put("Recommendation", "none");
						}
						
						array.add(rule10);
						
						/************************************************/
				/*********************Collect details of images********************/
		int emptyLinkCount = 0;
		int noscaleCount = 0;
		//String noScaleImgs[];
		//String scaleImgs[];
		int totImgCount = html.select("img").size();
		List<String> noScaleImgs = new ArrayList<String>();
		List<String> scaleImgs = new ArrayList<String>();
		
		for (int i = 0; i < totImgCount; i++)
        {
			//Element temp = html.select("img").get(i).at;
            if(html.select("img").get(i).attr("src") == "")
            {
                emptyLinkCount = emptyLinkCount + 1;
            }

            if(html.select("img").get(i).attr("width") == "" && html.select("img").get(i).attr("height") == "" && html.select("img").get(i).attr("style") == "" && html.select("img").get(i).attr("src") != "")
            {
                noscaleCount = noscaleCount + 1;
               noScaleImgs.add(html.select("img").get(i).attr("src"));
            }
            else
            {
                scaleImgs.add(html.select("img").get(i).attr("src"));
            }
        }

        for (int i = 0; i < html.select("script[src]").size(); i++)
        {
            if(html.select("script[src]").get(i).attr("src") == "")
            {
                emptyLinkCount = emptyLinkCount + 1;
            }
        }

        for (int i = 0; i < html.select("link[href]").size(); i++)
        {
            if( html.select("link[href]").get(i).attr("href") == "")
            {
                emptyLinkCount = emptyLinkCount + 1;
            }
        }
        
        /******************************************************************************************************************/
        
        /*************** Tags with empty SRC or HREF********************/
        
        JSONObject rule11 = new JSONObject();
        
        rule11.put("ruleHeader", "Empty SRC or HREF Tags");
		//
		if (emptyLinkCount!=0) {
			rule11.put("Message",emptyLinkCount+"instance(s) of empty SRC or HREF used in IMG,SCRIPT or LINK tag was found in the HTML document.");
			rule11.put("Recommendation","Remove the tags from the HTML document to avoid unnecessary HTTP call to server.");
		} else {
			rule11.put("Message", "none");
			rule11.put("Recommendation", "none");
		}
		
		array.add(rule11);
		/**************************************************************/
				     
		/*******************************Mention the dimensions of the images**************************************************/
		JSONObject rule12 = new JSONObject();
        
        rule12.put("ruleHeader", "Dimension of Images needs to be mentioned");
        //.toString().substring(1).replaceFirst("]", "")
        if (noscaleCount!=0) {
        	rule12.put("Message",noscaleCount+" instance(s) of IMG has no WIDTH or HEIGHT or STYLE defined. Below are the Images where diemnsion has not been mentioned:"+noScaleImgs.toString().substring(1).replaceFirst("]", "").replaceAll(",", "\n"));
        	rule12.put("Recommendation","Be sure to specify dimensions on the image element or block-level parent to avoid browser reflow or repaint.");
		} else {
			rule12.put("Message", "none");
			rule12.put("Recommendation", "none");
		}
		
		array.add(rule12);
		/**************************************************************************************************************/
		
		/*******************************Avoid Image scaling**************************************************/
		JSONObject rule13 = new JSONObject();
		rule13.put("ruleHeader", "Avoid Image scaling");
		if ((totImgCount - noscaleCount) >0) {
			rule13.put("Message",(totImgCount - noscaleCount)+" instance(s) of IMG has scaling defined. Below are the Images where scaling has been defined:"+scaleImgs.toString().substring(1).replaceFirst("]", "").replaceAll(",", "\n"));
			rule13.put("Recommendation","Make sure right size image used and avoid scaling in HTML");
		} else {
			rule13.put("Message", "none");
			rule13.put("Recommendation", "none");
		}
		
		array.add(rule13);
		/**********************************************************************************/
		/**********************Avoid Charset******************************/
		
		JSONObject rule14 = new JSONObject();
		rule14.put("ruleHeader", "Avoid charset in meta tag");
		
		if(head.select("meta").attr("content").contains("charset"))
		{
			rule14.put("Message","Charset has been mentioned in the meta tag of HTML document");
			rule14.put("Recommendation","Specifying a character set in a meta tag disables the lookahead downloader in IE8.To improve resource download parallelization move the character set to the HTTP ContentType response header.");
		}
		else
		{
			rule14.put("Message", "none");
			rule14.put("Recommendation", "none");
			
		}
		array.add(rule14);
		/****************************************************************/
        
		/**********************Make JS External******************************/
		int intJSCount = html.select("script").size() - (html.select("script[src]").size() + totSODCount);
		JSONObject rule15 = new JSONObject();
		rule15.put("ruleHeader", "Make JS as External");
		
		if(intJSCount>0)
		{
			rule15.put("Message",intJSCount+" instance(s) of internal Javascript has been identified in the HTML page");
			rule15.put("Recommendation","Make internal javascript to external if javascript is not simple.");
		}
		else
		{
			rule15.put("Message", "none");
			rule15.put("Recommendation", "none");
			
		}
		array.add(rule15);
		
		/********************************************************************/
		
		/**************************PUT CSS at Top***************************/
		int cssBodyCount = body.select("style").size();
		JSONObject rule16 = new JSONObject();
		rule16.put("ruleHeader", "PUT CSS at Top");
		if (cssBodyCount > 0 )
        {
			rule16.put("Message",cssBodyCount+" instance(s) of CSS stylesheet has been found in BODY");
			rule16.put("Recommendation","Specifying external stylesheet and inline style blocks in the body of an HTML document can negatively affect the browser's rendering performance. Move the CSS stylsheet to top of the HTML");
        }
		else
		{
			rule16.put("Message", "none");
			rule16.put("Recommendation", "none");
        }
		array.add(rule16);
		
		/********************************************************************/
		
		/******************Put Javascript at bottom****************************/
		
		JSONObject rule17 = new JSONObject();
		rule17.put("ruleHeader", "PUT JavaScript at Bottom");
		
		int jscntHead = (head.select("script").size() - (head.select("script[async]").size() + head.select("script[defer]").size() + headSODCount));
		 //head.select("script:not(script[async],script[defer])").size();
		
		List<String> jsList = new ArrayList<String>();
		 if (jscntHead>0)
		 {
		 for (int i = 0; i < head.select("script:not(script[async],script[defer])").size(); i++)
	        {
			 if(head.select("script:not(script[async],script[defer])").get(i).attr("src") != "")
             {
                 jsList.add(head.select("script:not(script[async],script[defer])").get(i).attr("src"));
             }
	        }
		 //called in HEAD without ASYNC or DEFER attribute can block parallel download of resources.
		 if(jsList.size()>0){
		 rule17.put("Message",jscntHead+" instance(s) of Javascript has been called in HEAD without ASYNC or DEFER attribute can block parallel download of resources. Below are the identified resources:"+jsList.toString().substring(1).replaceFirst("]", ""));
		 }
		 else
		 {
			 rule17.put("Message",jscntHead+" instance(s) of Inline Javascript has been called in HEAD without ASYNC or DEFER attribute which can block parallel download of resources.");
		 }
		 rule17.put("Recommendation","Move the Javascript to the bottom of the HTML or use ASYNC or DEFER attribute");
		 
		 }
		 else
		 {
			 rule17.put("Message", "none");
			 rule17.put("Recommendation", "none");
	        }
			array.add(rule17);     
		
		/***********************************************************************/
		
			}
			
			recommendation.put("recommendation", array);
			recommendation.put("pagename", pagename);
			System.out.println(recommendation);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return recommendation;

	}
	
	public static String decompressBrotli(byte[] compressed) throws IOException {
		ByteArrayInputStream bis = new ByteArrayInputStream(compressed);
		BrotliInputStream gis = new BrotliInputStream(bis);
		BufferedReader br = new BufferedReader(new InputStreamReader(gis, "UTF-8"));
		StringBuilder sb = new StringBuilder();
		String line;
		while((line = br.readLine()) != null) {
			sb.append(line);
		}
		br.close();
		gis.close();
		bis.close();
		return sb.toString();
	}
	
	public static String decompressGzip(byte[] compressed) throws IOException {
		ByteArrayInputStream bis = new ByteArrayInputStream(compressed);
		GZIPInputStream gis = new GZIPInputStream(bis);
		BufferedReader br = new BufferedReader(new InputStreamReader(gis, "UTF-8"));
		StringBuilder sb = new StringBuilder();
		String line;
		while((line = br.readLine()) != null) {
			sb.append(line);
		}
		br.close();
		gis.close();
		bis.close();
		return sb.toString();
	}
	public static String decompressDeflate(byte[] compressed) throws IOException {
		ByteArrayInputStream bis = new ByteArrayInputStream(compressed);
		DeflaterInputStream gis = new DeflaterInputStream(bis);
		BufferedReader br = new BufferedReader(new InputStreamReader(gis, "UTF-8"));
		StringBuilder sb = new StringBuilder();
		String line;
		while((line = br.readLine()) != null) {
			sb.append(line);
		}
		br.close();
		gis.close();
		bis.close();
		return sb.toString();
	}

	

	public List<String> timeconsuming(JSONArray b1) {
		int size = b1.size();
		List<String> timeconurl = new ArrayList<String>();

		String url;

		for (int i = 0; i < size; i++) {
			JSONObject chk = (JSONObject) b1.get(i);

			JSONObject request = (JSONObject) chk.get("request");

			url = request.get("url").toString();

			float f = Float.parseFloat(chk.get("time").toString());
			// System.out.println(f);
			if (f > 500) {
				timeconurl.add(url);
				// System.out.println(url);

			}

		}

		return timeconurl;
	}

	public Map<String, List<String>> getDomainurls(JSONArray b1, String str) {
		int size = b1.size();

		// List<String> expiryUrl = new ArrayList<String>();
		// List<String> wrongcachestatus = new ArrayList<String>();

		Map<String, List<String>> map = new HashMap<String, List<String>>();

		String url;

		for (int i = 0; i < size; i++) {
			JSONObject chk = (JSONObject) b1.get(i);

			JSONObject request = (JSONObject) chk.get("request");

			url = request.get("url").toString();

			if (url.endsWith(str)) {
				String domain;
				String[] split = url.split("/");
				domain = split[2];
				if (map.containsKey(domain)) {
					List<String> content = new ArrayList<String>();
					content = map.get(domain);
					content.add(url);
					map.put(domain, content);
				} else {
					List<String> content = new ArrayList<String>();
					content.add(url);
					map.put(domain, content);

				}

			}
		}

		for (String key : map.keySet()) {
			System.out.println("Key:" + key + ";Value:" + map.get(key));
		}
		// System.out.println(expiryUrl);
		// System.out.println(cacheContorlUrl);

		return map;

	}
	
	public String findHtmlContent(JSONArray entries)
	{
		String Htmlcontent="";
		try{
		
		for(int k=0;k<entries.size();k++)
		{
			JSONObject temp = (JSONObject) entries.get(k);
			JSONObject response = (JSONObject) temp.get("response");
			if(response.get("status").toString().contains("20"))
			{	
			JSONObject content =(JSONObject) response.get("content");
			
			JSONArray headers = (JSONArray) response.get("headers");
			String contentencoding="";
			int checkparse=0;
			for(int l=0;l<headers.size();l++)
			{
				 temp = (JSONObject) headers.get(l);
				//System.out.println("Headrers " + temp.toString());
				//System.out.println("Headrers content " + temp.get("name"));
				
				if(temp.get("name").toString().contains("Content-Type"))
				{
					System.out.println("Content type " + temp.get("value").toString());
					
					if(!temp.get("value").toString().contains("image")&&!temp.get("value").toString().contains("javascript")&&!temp.get("value").toString().contains("octet-stream")&&!temp.get("value").toString().contains("application")&&!temp.get("value").toString().contains("css"))
					{
						checkparse =1;
					}
					System.out.println("Check Parse:" + checkparse);
					break;
				}
				
		}
			if(checkparse == 1)
			{
				contentencoding ="plain";
			}
				
			for(int l=0;l<headers.size();l++)
			{
				temp = (JSONObject) headers.get(l);
				if(temp.get("name").toString().contains("Content-Encoding"))
				{
				System.out.println("Content Encoding " + temp.get("value").toString());
				if(temp.get("value").toString().contains("gzip"))
				{
					
					contentencoding ="gzip";
				}
				else if(temp.get("value").toString().contains("br"))
				{
					contentencoding ="br";
				}
				else if(temp.get("value").toString().contains("deflate"))
				{
					contentencoding ="deflate";
				}
				
				}
			}
			System.out.println("ContentEncoding " + contentencoding);
			System.out.println("mimetype " + content.get("mimeType").toString());
			
			if(content.get("mimeType").toString().contains("html"))
			{
				byte [] barr;
				if(contentencoding=="br")
				{
				
				if(content.get("text").toString().contains("</html>"))
				{
					Htmlcontent = content.get("text").toString();
				}
				else
				{
					System.out.println("before value is " + new String(content.get("text").toString()));
					barr = Base64.getDecoder().decode(content.get("text").toString().getBytes("UTF-8"));
					System.out.println("Decoded using br value is " + decompressBrotli(barr));
					Htmlcontent = decompressBrotli(barr);
				}
				
				break;
				}
				else if(contentencoding=="gzip")
				{
					if(content.get("text").toString().contains("</html>"))
					{
						Htmlcontent = content.get("text").toString();
					}
					else
					{
					System.out.println("before value is " + new String(content.get("text").toString()));
					barr = Base64.getDecoder().decode(content.get("text").toString().getBytes("UTF-8"));
					System.out.println("Decodedusing gzip value is " + decompressGzip(barr));
					Htmlcontent = decompressGzip(barr);
					}
					break;
				
				}
				else if(contentencoding=="deflate")
				{
					if(content.get("text").toString().contains("</html>"))
					{
						Htmlcontent = content.get("text").toString();
					}
					else
					{
					System.out.println("before value is " + new String(content.get("text").toString()));
					barr = Base64.getDecoder().decode(content.get("text").toString().getBytes("UTF-8"));
					System.out.println("Decodedusing gzip value is " + decompressDeflate(barr));
					Htmlcontent =decompressDeflate(barr);
					}
					break;
				}
				else if(contentencoding=="plain")
				{
					System.out.println("using plain " + content.get("text").toString());
					if(content.get("text").toString().contains("</html>"))
					{
						Htmlcontent = content.get("text").toString();
						break;
					}
					
				}
				
			}
			}
		}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return Htmlcontent;

	}

	public Map<String, List<String>> checkcachecontrol(JSONArray b1) {
		int size = b1.size();
		List<String> cacheContorlUrl = new ArrayList<String>();
		List<String> expiryUrl = new ArrayList<String>();
		List<String> wrongcachestatus = new ArrayList<String>();

		Map<String, List<String>> map = new HashMap<String, List<String>>();

		String url;

		for (int i = 0; i < size; i++) {
			JSONObject chk = (JSONObject) b1.get(i);

			JSONObject request = (JSONObject) chk.get("request");

			url = request.get("url").toString();

			JSONObject response = (JSONObject) chk.get("response");

			// System.out.println(response.get("status").toString());

			if (response.get("status").toString().contains("304")) {
				wrongcachestatus.add(url);
			}

			JSONArray headers = (JSONArray) response.get("headers");

			// System.out.println(headers);

			int c1 = 0;

			for (int j = 0; j < headers.size(); j++) {
				if (headers.get(j).toString().contains("Cache-Control")) {
					c1 = 1;
					break;
				}
			}

			if (c1 == 0) {
				cacheContorlUrl.add(url);
			}

			int c2 = 0;

			for (int j = 0; j < headers.size(); j++) {
				if (headers.get(j).toString().contains("Expires")) {
					c2 = 1;
					break;
				}
			}

			if (c2 == 0) {
				expiryUrl.add(url);
			}

		}

		// System.out.println(expiryUrl);
		// System.out.println(cacheContorlUrl);
		map.put("Expiry", expiryUrl);
		map.put("CacheControl", cacheContorlUrl);
		map.put("CacheStatus", wrongcachestatus);
		return map;
	}

	public List<String> findCompression(JSONArray b1) {
		int size = b1.size();
		List<String> compressionUrl = new ArrayList<String>();

		String url;

		for (int i = 0; i < size; i++) {
			JSONObject chk = (JSONObject) b1.get(i);

			JSONObject request = (JSONObject) chk.get("request");

			url = request.get("url").toString();

			if (!url.contains(".png") && !url.contains(".gif")
					&& !url.contains(".jpeg") && !url.contains(".jpg")) {
				JSONObject response = (JSONObject) chk.get("response");

				// System.out.println(response.get("status").toString());

				JSONArray headers = (JSONArray) response.get("headers");

				// System.out.println(headers);

				int c1 = 0;

				for (int j = 0; j < headers.size(); j++) {
					if (headers.get(j).toString().contains("Content-Encoding")) {
						c1 = 1;
						break;
					}
				}

				if (c1 == 0) {
					compressionUrl.add(url);
				}

			}
		}

		return compressionUrl;
	}

	public List<String> findDuplicates(JSONArray b1) {
		int size = b1.size();
		List<String> duplicateUrl = new ArrayList<String>();

		Map<String, String> urlwithsize = new HashMap<String, String>();

		String url;

		for (int i = 0; i < size; i++) {
			JSONObject chk = (JSONObject) b1.get(i);

			JSONObject request = (JSONObject) chk.get("request");

			url = request.get("url").toString();

			JSONObject response = (JSONObject) chk.get("response");

			// System.out.println(response.get("bodySize").toString());

			if (urlwithsize.containsKey(url)) {
				if (response.get("bodySize").toString()
						.equalsIgnoreCase(urlwithsize.get(url))) {
					duplicateUrl.add(url);
				}
			} else {
				urlwithsize.put(url, response.get("bodySize").toString());
			}

		}

		return duplicateUrl;
	}

	public Map<String, List<String>> errorenousurls(JSONArray b1) {
		int size = b1.size();
		List<String> url302 = new ArrayList<String>();
		List<String> url404 = new ArrayList<String>();

		Map<String, List<String>> map = new HashMap<String, List<String>>();

		String url;

		for (int i = 0; i < size; i++) {
			JSONObject chk = (JSONObject) b1.get(i);

			JSONObject request = (JSONObject) chk.get("request");

			url = request.get("url").toString();

			JSONObject response = (JSONObject) chk.get("response");

			// System.out.println(response.get("status").toString());

			if (response.get("status").toString().contains("302")) {
				url302.add(url);
			}

			if (response.get("status").toString().contains("400")
					|| response.get("status").toString().contains("404")) {
				url404.add(url);
			}

		}
		map.put("302", url302);
		map.put("404", url404);
		return map;

	}
}

	

	
