package permanenttsb.steps;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.logging.Logger;

import org.json.JSONException;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.nft.PerformanceMetrics;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.lightbody.bmp.BrowserMobProxy;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.client.ClientUtil;
import net.lightbody.bmp.proxy.CaptureType;

public class Definitions {
	
	private final static Logger LOGGER = Logger.getLogger(Definitions.class.getName());
	
	private static Properties prop;
    static DesiredCapabilities capabilities = new DesiredCapabilities();
    static BrowserMobProxy proxy = new BrowserMobProxyServer();
    static PerformanceMetrics collect = new PerformanceMetrics();
    static int counter=0;
    static String sitevalue = null;
	static JSONObject browserdata;
	static JSONArray output = new JSONArray();
	static JSONObject harjson=new JSONObject();
	static JSONArray hararray=new JSONArray();
	static JSONObject recommendations=new JSONObject();
	static JSONArray recommendationsarray=new JSONArray();
	static JSONArray timerarray=new JSONArray();
	static JSONObject timer =new JSONObject();
	static String ENV="sample";
	static String PROJECT="sampleproject";
	static 	boolean dynaTrace = false;
	static boolean browserTimers = true;
	static int ITERATIONS = 1;
	static String browser="Chrome-" ;
	static JavascriptExecutor js = null;
	static String BUILD="build";
	static String TESTURL="https://www.permanenttsb.ie/";
	static Properties properties = new Properties();
    static{
    	
    	/*String propapth="C:\\CI_CD\\datafile.properties";
    	File file = new File(propapth);
		FileInputStream fileInput;
		try {
			fileInput = new FileInputStream(file);
			properties.load(fileInput);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ENV = properties.getProperty("ENV");
		 PROJECT = properties.getProperty("PROJECT");
		browser = properties.getProperty("browser");
		BUILD = properties.getProperty("BUILD");
		 TESTURL = properties.getProperty("URL");*/
		
		//Browsemobproxy settings
		
				// start the proxy
				proxy.start(0);

				// get the Selenium proxy object
				Proxy seleniumProxy = ClientUtil.createSeleniumProxy(proxy);
				proxy.setHarCaptureTypes(CaptureType.getAllContentCaptureTypes());
				proxy.enableHarCaptureTypes(CaptureType.REQUEST_CONTENT, CaptureType.RESPONSE_CONTENT,CaptureType.RESPONSE_HEADERS);
				
				// configure it as a desired capability
				
				
				capabilities.setCapability(CapabilityType.PROXY, seleniumProxy);
				capabilities.setCapability("acceptInsecureCerts", true);
				
				capabilities.setJavascriptEnabled(true);
				capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
				capabilities.setCapability(CapabilityType.SUPPORTS_JAVASCRIPT, true);
    }
	
	WebDriver driver = new ChromeDriver(capabilities);
	
	
	@Before
	public void openBrowser() {
		System.setProperty("webdriver.chrome.driver","chromedriver");
		driver.manage().window().maximize();
	}
	
	@After
	public void closeBrowser() throws Exception {
		
		// Create json
				
				collect.CreateJson(output);
				collect.CreateHarJson(hararray);
				collect.CreateRecommendationsJSON(recommendationsarray);
				collect.CreateResponseJson(timerarray);
				
		driver.close();
		proxy.stop();
	}
	
	@Given("permanenttsb online user is successfully able to launch the web application")
	public void permanenttsb_online_user_is_successfully_able_to_launch_the_web_application() throws Exception {
		
		 
		counter++;
		collect.clearCache();
		proxy.newHar("https://www.permanenttsb.ie/");
		collect.startJavaTimer();
		
	    driver.get("https://www.permanenttsb.ie/");
	    
	    collect.takeSnapShot(TESTURL);
	    timer=collect.stopJavaTimer("BusinessBanking");
		harjson=collect.CreateHar(proxy,"BusinessBanking",counter);
		recommendations=collect.Recommendations("BusinessBanking");
		sitevalue = collect.SiteNavigationwithCache(driver, browser, ENV, TESTURL, BUILD, PROJECT);
		browserdata = collect.pageTimer("BusinessBanking", sitevalue, TESTURL, BUILD, ENV);
		output.add(browserdata);
		hararray.add(harjson);
		timerarray.add(timer);
		recommendationsarray.add(recommendations);
	    Assert.assertEquals("Navigated to the invalid Page or Page is not properly loaded. Please check the url once !!!","Personal and Business Banking | permanent tsb",driver.getTitle());
	}

	@When("user is able to navigate to Current Accounts")
	public void user_is_able_to_navigate_to_Current_Accounts() throws InterruptedException, IOException, JSONException {
		counter++;
		proxy.newHar("https://www.permanenttsb.ie/");
		collect.startJavaTimer();
		
		driver.navigate().to("https://www.permanenttsb.ie/everyday-banking/");
		
		
		Assert.assertEquals("Navigated to the invalid Page or Page is not properly loaded. Please check the url once !!!","For All your Banking Needs - Everyday Banking | permanent tsb",driver.getTitle());
		Thread.sleep(2000);
		timer=collect.stopJavaTimer("EverydayBanking");
		harjson=collect.CreateHar(proxy,"EverydayBanking",counter);
		recommendations=collect.Recommendations("EverydayBanking");
		sitevalue = collect.SiteNavigationwithCache(driver, browser, ENV, TESTURL, BUILD, PROJECT);
		browserdata = collect.pageTimer("EverydayBanking", sitevalue, TESTURL, BUILD, ENV);
		output.add(browserdata);
		hararray.add(harjson);
		timerarray.add(timer);
		recommendationsarray.add(recommendations);
	}

	@When("user wants to explore current accounts more")
	public void user_wants_to_explore_current_accounts_more() throws InterruptedException, IOException, JSONException {
		WebElement CrntAccount = driver.findElement(By.xpath("/html[1]/body[1]/div[6]/section[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/a[1]"));
		
		counter++;
		proxy.newHar("https://www.permanenttsb.ie/");
		collect.startJavaTimer();
		
		CrntAccount.click();
		
		timer=collect.stopJavaTimer("CuurentAccounts");
		harjson=collect.CreateHar(proxy,"CuurentAccounts",counter);
		recommendations=collect.Recommendations("CuurentAccounts");
		sitevalue = collect.SiteNavigationwithCache(driver, browser, ENV, TESTURL, BUILD, PROJECT);
		browserdata = collect.pageTimer("CuurentAccounts", sitevalue, TESTURL, BUILD, ENV);
		output.add(browserdata);
		hararray.add(harjson);
		timerarray.add(timer);
		recommendationsarray.add(recommendations);
	}

	@When("user tries to book an appointment by submitting the details {string} {string} {string} {string} {string} {string} {string} {string}")
	public void user_tries_to_book_an_appointment_by_submitting_the_details(String firstName, String surName, String dobDay, String dobMonth, String dobYear, String address1, String address2, String town) throws InterruptedException, IOException, JSONException {
		WebElement clickStartSwitchNow = driver.findElement(By.xpath("/html[1]/body[1]/div[6]/div[1]/div[2]/div[1]/div[2]/div[2]/div[1]/a[1]"));
		
		counter++;
		proxy.newHar("https://www.permanenttsb.ie/");
		collect.startJavaTimer();
		
		clickStartSwitchNow.click();
		
		timer=collect.stopJavaTimer("ApplicationForm");
		harjson=collect.CreateHar(proxy,"ApplicationForm",counter);
		recommendations=collect.Recommendations("ApplicationForm");
		sitevalue = collect.SiteNavigationwithCache(driver, browser, ENV, TESTURL, BUILD, PROJECT);
		browserdata = collect.pageTimer("ApplicationForm", sitevalue, TESTURL, BUILD, ENV);
		output.add(browserdata);
		hararray.add(harjson);
		timerarray.add(timer);
		recommendationsarray.add(recommendations);
		
		WebElement selectYourDetailsTitle = driver.findElement(By.xpath("/html[1]/body[1]/div[5]/section[2]/div[2]/div[1]/div[1]/div[1]/div[1]/form[1]/div[1]/div[1]/div[1]/label[1]/div[1]/ins[1]"));
		
		/*counter++;
		proxy.newHar("https://www.permanenttsb.ie/");
		collect.startJavaTimer();*/
		
		selectYourDetailsTitle.click();
		
		/*timer=collect.stopJavaTimer(driver.getTitle());
		harjson=collect.CreateHar(proxy,driver.getTitle(),counter);
		recommendations=collect.Recommendations(driver.getTitle());
		sitevalue = collect.SiteNavigationwithCache(driver, browser, ENV, TESTURL, BUILD, PROJECT);
		browserdata = collect.pageTimer(driver.getTitle(), sitevalue, TESTURL, BUILD, ENV);
		output.add(browserdata);
		hararray.add(harjson);
		timerarray.add(timer);
		recommendationsarray.add(recommendations);*/
		
		WebElement setYourDetailsFirstName = driver.findElement(By.id("Step1_FirstName"));
		setYourDetailsFirstName.sendKeys(firstName);
		
		WebElement setYourDetailsSurName = driver.findElement(By.id("Step1_Surname"));
		setYourDetailsSurName.sendKeys(surName);
		
		WebElement setYourDetailsDate = driver.findElement(By.id("Step1_DOBDay"));
		setYourDetailsDate.sendKeys(dobDay);
		
		WebElement setYourDetailsMonth = driver.findElement(By.id("Step1_DOBMonth"));
		setYourDetailsMonth.sendKeys(dobMonth);

		WebElement setYourDetailsYear = driver.findElement(By.id("Step1_DOBYear"));
		setYourDetailsYear.sendKeys(dobYear);
		
		WebElement setYourDetailsAddress1 = driver.findElement(By.id("Step1_Address_NumberStreet"));
		setYourDetailsAddress1.sendKeys(address1);
		
		WebElement setYourDetailsAddress2 = driver.findElement(By.id("Addressline2"));
		setYourDetailsAddress2.sendKeys(address2);

		WebElement setYourDetailsAddress3 = driver.findElement(By.id("Step1_Address_TownCity"));
		setYourDetailsAddress3.sendKeys(town);
		
		setYourDetailsAddress3.sendKeys(Keys.TAB);
		
	}

	@Then("system successfully alerts the user to enter mandatory details")
	public void verifyTheAlerts() throws InterruptedException, IOException, JSONException {
		
		
		driver.findElement(By.name("next")).sendKeys(Keys.ENTER);

		
		String expectedErrorMessage = "Please select a county.";
		String actualErrorMessage = driver.findElement(By.xpath("/html[1]/body[1]/div[5]/section[2]/div[2]/div[1]/div[1]/div[1]/div[1]/form[1]/div[1]/div[2]/span[7]/span[1]")).getText();
		Assert.assertEquals(expectedErrorMessage, actualErrorMessage);
		LOGGER.info("-------------------------------------------------------------------------------------");
		LOGGER.info("Expected Error Message : " + expectedErrorMessage);
		LOGGER.info("Actual Error Message : " + actualErrorMessage);
		LOGGER.info("-------------------------------------------------------------------------------------");
	}


}
