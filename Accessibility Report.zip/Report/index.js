 
$.ajaxSetup({
    async: false
});  


$.getJSON("donut.json", function(json) {
            var hits=json.rundetails;
            //alert(JSON.stringify(hits));
           //alert(json.rundetails.length);
var critical=0,serious=0,minor=0,moderate=0, temp=0,temp_serious=0,temp_min=0,temp_mod=0;
           for(var i=0;i<json.rundetails.length;i++){

//alert(json.rundetails.length)
             critical=json.rundetails[i].critical;
            temp=temp+critical;
             serious=json.rundetails[i].serious;
             temp_serious=temp_serious+serious;
             minor=json.rundetails[i].minor;
             temp_min=temp_min+minor;
             moderate=json.rundetails[i].moderate;
             temp_mod=temp_mod+moderate;
            //var pagename=json.rundetails[i].pagename;

                     document.getElementById("critical").innerHTML ="Critical :"+temp; 
                      document.getElementById("serious").innerHTML = "Serious :"+temp_serious;
                       document.getElementById("moderate").innerHTML = "Moderate :" +temp_mod;
                        document.getElementById("minor").innerHTML = "Minor :" +temp_min;
           }
 
        
/*Morris.Donut({
  element: 'chart',
  colors: ["#8B0000", "#FF0000", "#FFBF00","#008000"],
  data: [
    {label: "Critical", value: critical},
    {label: "Serious", value: serious},
    {label: "Moderate", value: moderate},
    {label: "Minor", value: minor}
  ]
});*/
});



       $.getJSON("performance.json", function(json) { 
     
      var hits=json.length;
     // alert(hits);
      var transname, pageloadtime,totalpage_time;
      var size=45;
      var temp=0;

        for(i=0;i<json.Transactions.length;i++)
        {
 // transname=json.Transactions[i].name;

       pageloadtime=json.Transactions[i].visuallyComplete
      // alert(totalpage_time)


       
                      
           }

           

             if(pageloadtime>=5000){
              temp++; 

               document.getElementById("Violated").innerHTML ="SLA Violated Pages:"+temp; 
            }

            else{

    document.getElementById("Violated").innerHTML ="No SLA Violated Pages"; 

       }

});


  $.getJSON("zap.json", function(json) {
            var hits=json.securitydetails;
            //alert(JSON.stringify(hits));
           //alert(hits);
var High,Medium,Low,info;
           for(var i=0;i<json.securitydetails.length;i++){

             High =json.securitydetails[i].High;
             Medium=json.securitydetails[i].Medium;
             Low=json.securitydetails[i].Low;
             info=json.securitydetails[i].info;

               

                    
           }

  document.getElementById("high").innerHTML="High :"+High;
  document.getElementById("medium").innerHTML="Medium :"+Medium;
  document.getElementById("low").innerHTML="Low :"+Low;
  document.getElementById("info").innerHTML="info :"+info;
                  
        
/*Morris.Donut({
  element: 'chart',
  colors: ["#8B0000", "#FF0000", "#008000","#FFBF00"],
  data: [
    {label: "High", value: High},
    {label: "Medium", value: Medium},
    {label: "Low", value: Low},
    {label: "info", value: info}
  ]
});*/
});


$.getJSON("performance.json", function(json) {

var hits=json;
//alert(JSON.stringify(hits));
var testur1;
  for(var i=0;i<hits.length;i++)
            {   

testur1=hits[i].TestURL;
              }
document.getElementById("url").innerHTML ="<a href=>"+testur1+"</a>" ;
    });