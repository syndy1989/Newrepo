$.getJSON("donut.json", function(json) {
            var hits=json.rundetails;
            //alert(JSON.stringify(hits));
           //alert(hits);
var critical,serious,minor,moderate;
           for(var i=0;i<json.rundetails.length;i++){

             critical=json.rundetails[i].critical;
             serious=json.rundetails[i].serious;
             minor=json.rundetails[i].minor;
             moderate=json.rundetails[i].moderate;
           }
             
             var data = [
      { y: 'Critical', a:critical},
      { y: 'Serious', b: serious},
      { y: 'Moderate',   c: moderate},
      { y: 'Minor',  d: minor}
    ],
    config = {
      data: data,
      xkey: 'y',
      ykeys: ['a','b','c','d'],
      labels: ['Critical', 'Serious','Moderate','Minor'],
      fillOpacity: 0.6,
      hideHover: 'false',
      stacked:'true',
      resize: true,
       barWidth: '1200px',
     barColors: ['#ff6600','#04d215','#ff0f00','#67b7dc']
  };


config.element = 'chartpagesize';
Morris.Bar(config);
 
     
});

$.getJSON("violations.json", function(json) { 

var hits=json;
//alert(hits.length)
var render,css,cssrules,javascript,text;

var row=document.createElement('h3');
row.setAttribute("style","color:#3c9adc");
row.innerHTML="Impact - Critical";

var row1=document.createElement('h3');
row1.setAttribute("style","color:#3c9adc");
row1.innerHTML="Impact - Serious";

var row2=document.createElement('h3');
row2.setAttribute("style","color:#3c9adc");
row2.innerHTML="Impact - Moderate";

var row3=document.createElement('h3');
row3.setAttribute("style","color:#3c9adc");
row3.innerHTML="Impact - Minor";

for(var i=0;i<hits.length;i++)
            {  
    var eachobj=hits[i];

    var eachobjkeys=Object.keys(eachobj);

 for(var j=0;j<eachobjkeys.length;j++)
 {
  var uniqueobj=eachobj[j];
  var uniquekeys=Object.keys(uniqueobj);

 var impact=uniqueobj["impact"];

 if(impact=="critical")
 {
                        var ul=document.createElement('ul');
                        var li1=document.createElement('li'); 
                        li1.setAttribute("style","color:#808080");       
                        var li2=document.createElement('li')
                        li2.setAttribute("style","color:#808080");  
                        var li3=document.createElement('li');
                        li3.setAttribute("style","color:#808080");  

                      

                  
                        li1.innerText="Violation :"+uniqueobj["Help"];

                        li2.innerText="Description :"+uniqueobj["description"];

                         li3.innerText="Guidelines :"+uniqueobj["Guidelines"];
                    
                       ul.appendChild(li1);
                       ul.appendChild(li2);
                       ul.appendChild(li3);
                       
                       row.appendChild(ul);
                     }

                     if(impact=="serious")
              {
                        var ul=document.createElement('ul');
                        var li1=document.createElement('li'); 
                        li1.setAttribute("style","color:#808080");       
                        var li2=document.createElement('li')
                        li2.setAttribute("style","color:#808080");  
                        var li3=document.createElement('li');
                        li3.setAttribute("style","color:#808080");  
                                       
                        li1.innerText="Violation :"+uniqueobj["Help"];

                        li2.innerText="Description :"+uniqueobj["description"];

                        li3.innerText="Guidelines :"+uniqueobj["Guidelines"];

                       ul.appendChild(li1);
                       ul.appendChild(li2);
                       ul.appendChild(li3);
                       
                       row1.appendChild(ul);

                     }

                     if(impact=="moderate")
      {
                        var ul=document.createElement('ul');
                        var li1=document.createElement('li'); 
                        li1.setAttribute("style","color:#808080");       
                        var li2=document.createElement('li')
                        li2.setAttribute("style","color:#808080");  
                        var li3=document.createElement('li');
                        li3.setAttribute("style","color:#808080"); 

                        li1.innerText="Violation :"+uniqueobj["Help"];

                        li2.innerText="Description :"+uniqueobj["description"];

                        li3.innerText="Guidelines :"+uniqueobj["Guidelines"];

                        ul.appendChild(li1);
                        ul.appendChild(li2);
                        ul.appendChild(li3);
                        row2.appendChild(ul);

                     }

                     if(impact=="minor")
    {
                        var ul=document.createElement('ul');
                        var li1=document.createElement('li'); 
                        li1.setAttribute("style","color:#808080");       
                        var li2=document.createElement('li')
                        li2.setAttribute("style","color:#808080");  
                        var li3=document.createElement('li');                       
                        li3.setAttribute("style","color:#808080");  
                        li1.innerText="Violation :"+uniqueobj["Help"];

                        li2.innerText="Description :"+uniqueobj["description"];

                        li3.innerText="Guidelines :"+uniqueobj["Guidelines"];

                       ul.appendChild(li1);
                       ul.appendChild(li2);
                       ul.appendChild(li3);
                       

                       row3.appendChild(ul);

                     }

                      


}

}

document.getElementById("violations").appendChild(row);
document.getElementById("violations").appendChild(row1);
document.getElementById("violations").appendChild(row2);
document.getElementById("violations").appendChild(row3);

});
