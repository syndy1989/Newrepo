$.ajaxSetup({
    async: false
}); 

var crawlingmaxcpu=0;
var crawlingmaxmem=0;
var netslacount=0;

          var url = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
          //alert("url" +url.length);
          var params=[];
        for (var i=0;i<url.length;i++) 
          {
            params[i] = url[i].split(",");
         //   alert("saket - "+params[i]);
          }
  // var usecasenamedtl=params[0];
  var usecasenamedtl="Ooredoo_PostpaidDgl";
//  alert("usecasenamedtl test"+ usecasenamedtl)
  var usecasesortdtl=params[1];
  var totalrequestsize=0;
  var totalreceivedsize=0;
  var reqsizarray=[];
  var respsizearray=[];
/*$.getJSON("Result.json", function(json) 
{
    var mainObj=json;
     for(var i=0;i<json.length;i++)
                      {       
                        var eachobj=mainObj[i];
                        var eachobjkeys=Object.keys(eachobj);
                        eachobjkeys.forEach(function (key)
                         {
                       // if(eachobj.hasOwnProperty(usecasenamedtl))
                        {                          
                       var eachusecase=eachobj[eachobjkeys];    

                       for(var j=0;j<eachusecase.length;j++)
                        {
                        var eachpage=eachusecase[j];
                        var eachpagekeys=Object.keys(eachpage);
                        var pagewisedetails=eachpage[eachpagekeys];
                               
                        var row=document.createElement('div');
                        row.setAttribute("class","row");
                        row.setAttribute("id",eachpagekeys)

                        var gridWidth=document.createElement('div');
                        gridWidth.setAttribute("class","col-lg-12");

                        var panelRoot=document.createElement('div');
                        panelRoot.setAttribute("class","panel panel-default");

                        var panelHeading=document.createElement('div');
                        panelHeading.setAttribute("class","panel-heading");

                        var heading3=document.createElement('a');
                        heading3.setAttribute("class","panel-title");                        
                       
                        var icon=document.createElement('i');
                        icon.setAttribute("class","fa fa-long-arrow-right fa-fw");

                        heading3.appendChild(icon);
                        heading3.innerHTML=eachpagekeys;
                        heading3.setAttribute("onclick","doit('"+eachpagekeys+"');");

                        panelHeading.appendChild(heading3);
                /*        var panelBody=document.createElement('div');
                        panelBody.setAttribute("class","panel-body");
                        panelBody.setAttribute("id","panellinks");

                        panelRoot.appendChild(panelHeading);
                   //     panelRoot.appendChild(panelBody)
                        gridWidth.appendChild(panelRoot);
                        row.appendChild(gridWidth);
                        document.getElementById("Networktable").appendChild(row);       
                    } 
                 }                     
            });
         }          

});*/
    



$.getJSON("Result.json", function(json) 
{
  
    var mainObj=json;
  //  alert("saket i - "+json.length);
     for(var i=0;i<json.length;i++)
                      {   
                        //alert("saket i - "+json.length);

                        var eachobj=mainObj[i];
                        var eachobjkeys=Object.keys(eachobj);
                        eachobjkeys.forEach(function (key)
                         {
                                            
                       var eachusecase=eachobj[eachobjkeys];    
                       //alert("saket j - "+ eachobjkeys);
                       for(var j=0;j<eachusecase.length;j++)
                        {
                         // alert("saket j - "+ eachusecase.length);
                        var eachpage=eachusecase[j];
                        var eachpagekeys=Object.keys(eachpage);
                        var pagewisedetails=eachpage[eachpagekeys];
                        //alert("eachpage - "+eachpage+" -- eachpagekeys  - "+eachpagekeys+" -- pagewisedetails - "+pagewisedetails);       
                        var row=document.createElement('div');
                        row.setAttribute("class","row");
                        row.setAttribute("id",eachpagekeys)

                        var gridWidth=document.createElement('div');
                        gridWidth.setAttribute("class","col-lg-12");

                        var panelRoot=document.createElement('div');
                        panelRoot.setAttribute("class","panel panel-default");

                      
                        gridWidth.appendChild(panelRoot);
                        row.appendChild(gridWidth);
                        document.getElementById("Networktable").appendChild(row); 
           

                          //alert("saket j - "+ eachusecase.length);
                          //var eachpage=eachusecase[j];
                          //var eachpagekeys=Object.keys(eachpage);
                          //var pagewisedetails=eachpage[eachpagekeys];
                        //  alert("eachpagekeys - "+eachpagekeys);
                          /*alert("  ----   "+document.getElementById(eachpagekeys+eachpagekeys));
                          var panelBody=document.createElement('div');
                          panelBody.setAttribute("class","panel-body");
                          panelBody.setAttribute("id","panellinks");*/
                          loadrecommendations(eachpagekeys.toString());
                          loadPerformance(eachpagekeys.toString());
                        //  loadgraph(eachpagekeys.toString());
                         /* panelBody.appendChild(load);
                          document.getElementById(eachpagekeys+eachpagekeys).appendChild(panelBody);*/

                        }



                                     
            });
         }          

});




/*$.getJSON("individual.json", function(json) 
                {
                    var individuaobj=json;
                   for(var i=0;i<individuaobj.length;i++)
                   {
                    if((individuaobj[i].activity).includes(usecasenamedtl))
                    {
                       // alert("yes if done"+individuaobj[i].activity);
                        var tablerow=document.createElement('tr');
                
                                var tablecolum1=document.createElement('td');
                                var tablecolum2=document.createElement('td');

                                tablecolum1.innerHTML=individuaobj[i].activity;
                                tablecolum2.innerHTML=individuaobj[i].ResponseTime;

                                tablerow.appendChild(tablecolum1);
                                tablerow.appendChild(tablecolum2);

                                document.getElementById("Responsetime").appendChild(tablerow);
                         }      
                   }
             });*/  
//$('[id="expandlinks"]').prop("onclick", null).off("click");
/*function doit(value)
{

//  alert("value - "+value);
    var ul = document.getElementById(value);
if(ul!=undefined)
{
$("#"+"expandlinks").remove();
$("#"+value+value).remove();
}

                       var accordion=document.getElementById(value);
                      alert("accordion - "+accordion);
                        var panelBody=document.createElement('div');
                    
                        panelBody.setAttribute("class","panel-body");
                        panelBody.setAttribute("id","expandlinks")

                        var tablediv=document.createElement('div')
                        var tablelink=document.createElement('a');
                        tablediv.appendChild(tablelink);
                        var graphdiv=document.createElement('div')
                        var graphlink=document.createElement('a');
                        graphdiv.appendChild(graphlink);
                        var recommndiv=document.createElement('div');
                        var recommendlink=document.createElement('a');
                        recommndiv.appendChild(recommendlink)
                        tablelink.innerHTML="Pagewise View";
                        graphlink.innerHTML="Timeline View";
                        recommendlink.innerHTML="Recommendations";
                        panelBody.appendChild(tablediv);
                       
                        panelBody.appendChild(recommndiv);
                        panelBody.appendChild(graphdiv);
                        accordion.appendChild(panelBody);


tablelink.setAttribute("onclick","loadPerformance('"+value+"')");

recommendlink.setAttribute("onclick","loadrecommendations('"+value+"')");

graphlink.setAttribute("onclick","loadgraph('"+value+"')");

}*/