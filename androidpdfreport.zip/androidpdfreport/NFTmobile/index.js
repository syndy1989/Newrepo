$.ajaxSetup({
    async: false
});
                var cpuavgtemp=0;
                var cpumaxtemp=0;
                var memavgtemp=0;
                var memmaxtemp=0;
                var crawlingavgcpu=0;
                var crawlingmaxcpu=0;
                var crawlingavgmem=0;
                var crawlingmaxmem=0;
                var launch_time=0;
                  var AppSize;
         var Appsize ;
         var requestID;

  $.getJSON("mobile.json", function(json)
   {
      
          

  $.getJSON("appsize.json", function(json)
   {
     
    appjson=json;
//  alert("json"+JSON.stringify(json));
    AppSize=appjson.FileSize;
    requestID=appjson.RequestId;
    AppSize=parseFloat(AppSize);
   /* console.log("AppSize"+AppSize+"requestID"+requestID);*/
     Appsize=AppSize.toFixed(2);
 /*$('#sidenavbar').append('<li class="active"> <a href= http://localhost:8082/MobileReports/getPackageDetails.action?requestId='+requestID+'><i class="fa fa-fw fa-dashboard"></i>SummaryReport</a></li>');*/
     });

         var hits=json
         for(var k=0;k<hits.length;k++)  
{

 $('#demo').append('<li><a href= final.html?'+hits[k]._source.Application.runs.rundetails.usecasedetail.usecasename+' ><i class=fa fa-fw fa-bar-chart-o></i>'+hits[k]._source.Application.runs.rundetails.usecasedetail.usecasename+'</a></li>');
  
} 
          
            var currentbuildNumber=0;
            var previousbuildNumber=0;
            
            for(var i=0;i<hits.length;i++)
            {


                if(hits.length==0)
                {

                 currentbuildNumber=parseInt(hits[i]._source.Application.runs.rundetails["runid"]);
        
                }
                else if(hits.length==1)
                {

                previousbuildNumber=parseInt(hits[i]._source.Application.runs.rundetails["runid"]);
                if(currentbuildNumber<previousbuildNumber)
                {
                    var temp=currentbuildNumber;
                    currentbuildNumber=previousbuildNumber;
                    previousbuildNumber=temp;
                }
                }
            else
            {
             
                    if(currentbuildNumber<parseInt(hits[i]._source.Application.runs.rundetails["runid"]))
                    {
                        previousbuildNumber=currentbuildNumber;
                        currentbuildNumber=parseInt(hits[i]._source.Application.runs.rundetails["runid"]);
                    }
                    else if ((previousbuildNumber<parseInt(hits[i]._source.Application.runs.rundetails["runid"]))&&(parseInt(hits[i]._source.Application.runs.rundetails["runid"])!=currentbuildNumber)) {

                        previousbuildNumber= parseInt(hits[i]._source.Application.runs.rundetails["runid"]);
                    }
            }


            }


             var currentTransactions=[];
            var previousTransactions=[];
            var currentJob;
            var previousJob;
            var usecasename;
            

                if(currentbuildNumber!=previousbuildNumber)
                {
                   for(var i=0;i<hits.length;i++)
                    {

                           if(parseInt(hits[i]._source.Application.runs.rundetails["runid"])==currentbuildNumber)
                                 {
                                        currentJob=hits[i]._source;
                                      currentTransactions.push(hits[i]._source);

                                 }
                                 else  if(parseInt(hits[i]._source.Application.runs.rundetails["runid"])==previousbuildNumber)
                                 {
                                        previousJob=hits[i]._source;

                                      previousTransactions.push(hits[i]._source);
                                 }
                                 usecasename=hits[i]._source.Application.runs.rundetails.usecasedetail.usecasename;
                                // alert(usecasename);

                    }
                }


          // window.alert("imman"+JSON.stringify(currentJob.applicationName));
          //document.getElementById("packageid").innerHTML=currentJob.Application.applicationName;
              //   document.getElementById("runid").innerHTML=currentJob.Application.runs.rundetails.runid;
                //       document.getElementById("usecasecount").innerHTML=currentTransactions.length;
           var moorisArray=[];


            for(var i=0;i<currentTransactions.length;i++)
            {
                var currentObje=currentTransactions[i];
                 var moorisObject={};
                 moorisObject.period=currentObje.Application.runs.rundetails.usecasedetail.usecasename;
                /* moorisObject.battery=currentObje.Application.runs.rundetails.usecasedetail.usecasedetails.averagebattery;*/
                 moorisObject.cpu=currentObje.Application.runs.rundetails.usecasedetail.usecasedetails.averagecpu;
                 moorisObject.memory=parseFloat(currentObje.Application.runs.rundetails.usecasedetail.usecasedetails.averagememory)/1024;
                  /*moorisObject.network=parseInt(currentObje.Application.runs.rundetails.usecasedetail.usecasedetails.usecaseresponsetime.launchtime)/1000;*/
                 moorisArray.push(moorisObject)

            }
            var cpu=0,battery=0,network=0,memory=0;
            var totaltransfered=0;
            var totalreceived=0;
             for(var i=0;i<currentTransactions.length;i++)
            {
                var currentObje=currentTransactions[i];

                  cpu+=parseInt(currentObje.Application.runs.rundetails.usecasedetail.usecasedetails.averagecpu);
                 /* battery+=parseInt(currentObje.Application.runs.rundetails.usecasedetail.usecasedetails.averagebattery);*/
                  memory+=(parseInt(currentObje.Application.runs.rundetails.usecasedetail.usecasedetails.averagememory))/1024;
                  totaltransfered+=Math.round((currentObje.Application.runs.rundetails.usecasedetail.usecasedetails.TotalTransfered)/1024);
                    totalreceived+=Math.round((currentObje.Application.runs.rundetails.usecasedetail.usecasedetails.TotalReceived)/1024);
                  /*network+=(parseInt(currentObje.Application.runs.rundetails.usecasedetail.usecasedetails.usecaseresponsetime.launchtime))/1000;*/


            }
            

            for(var i=0;i<currentTransactions.length;i++)
            {

                if(currentTransactions[i].Application.runs.rundetails.usecasedetail.usecasename=="App-Launch");
                {
                 launchObje=currentTransactions[i];
            }
            if(currentTransactions[i].Application.runs.rundetails.usecasedetail.usecasename!="App-Launch")
            {

                crawlerObje=currentTransactions[i];
            }
            }


            var launchObje={},crawlerObje=[];
            //alert(currentTransactions.length);
            for(var i=0;i<currentTransactions.length;i++)
            {

                if(currentTransactions[i].Application.runs.rundetails.usecasedetail.usecasename=="App-Launch");
                {
                 launchObje=currentTransactions[i];
                 //alert(JSON.stringify(launchObje));
            }
            if(currentTransactions[i].Application.runs.rundetails.usecasedetail.usecasename!="App-Launch")
            {
              //  alert(i+JSON.stringify(currentTransactions[i]))
                crawlerObje.push(currentTransactions[i]);
                
            }
            }
            // console.log("crawlerObje"+JSON.stringify(crawlerObje))
           //console.log(JSON.stringify(currentTransactions));
                //document.getElementById("overallcpu").innerHTML=Math.ceil(cpu/currentTransactions.length)+"%";
                
            packageid=currentJob.Application.applicationName;
         //   alert(packageid)
            //var usecases=currentJob._source.Application.runs.rundetails;
            // console.log(JSON.stringify(packageid));
            document.getElementById("packagename").innerHTML=packageid+" -AppSize";

                                                            if(Appsize<=15)
                                                                {
 
                                                                document.getElementById('AppSizePanel').className+= 'panel panel-green';
 
                                                                }
 
                                                                else if(Appsize>15&&Appsize<50)
 
                                                                {
 
                                                                document.getElementById('AppSizePanel').className+= 'panel panel-yellow';
 
                                                                }
 
                                                                else if(Appsize>50)
 
                                                                {
 
                                                                document.getElementById('AppSizePanel').className+= 'panel panel-red';
 
                                                                }
 
                                                                document.getElementById("AppSize").innerHTML=Appsize+"MB";      
                    document.getElementById("AppSize_table").innerHTML="For your current AppSize of "+Appsize+"MB below are the indicative download time at various network speeds";                                                                
var speedarr=[2,5,10,15];
var data=[];
var temp=[];
for(var i=0;i<speedarr.length;i++)
{
var j=(Appsize/speedarr[i])
var k=j.toFixed(3);
//alert("k"+k);     
temp.push(k);
}
var time_one=temp[0];
var time_sec=temp[1];
var time_third=temp[2];
var time_four=temp[3];
document.getElementById("time_one").innerHTML=time_one;
document.getElementById("time_sec").innerHTML=time_sec;
document.getElementById("time_third").innerHTML=time_third;
document.getElementById("time_four").innerHTML=time_four;
for(var n=0;n<temp.length;n++)
{
var eachaval=[];
eachaval.push(speedarr[n],temp[n]);
data.push(eachaval)
}


                launch_time=launchObje.Application.runs.rundetails.usecasedetail.usecasedetails.pagewisedetails.launchtime;
            //     launch_time=21432;
          
                
                if(launch_time<3000)
                {
                document.getElementById('launchpanel').className+= 'panel panel-green';
                    /* document.getElementById("RESPSLA").innerHTML="Response Time is WITHIN SLA";
                       document.getElementById('RESPSLA').style.color= 'green';
                */
                }
                else if((launch_time<3000)&&(launch_time>=5000))
                {
                document.getElementById('launchpanel').className+= 'panel panel-yellow';
                 /*document.getElementById('RESPSLA').style.color= 'orange';*/
                   }
                else if(launch_time>=5000)
                {
                document.getElementById('launchpanel').className+= 'panel panel-red';
                /* document.getElementById('RESPSLA').style.color= 'red';*/
                }
             //   alert("launch_time"+launch_time)
                document.getElementById("launchid").innerHTML=launch_time+"ms";
                var launchavgcpu= launchObje.Application.runs.rundetails.usecasedetail.usecasedetails.averagecpu;
               // alert(launchavgcpu);
                var maxcpu=launchObje.Application.runs.rundetails.usecasedetail.usecasedetails.maxcpu;
               // alert(maxcpu);
                
                if(maxcpu<=50)
                {
                document.getElementById('cpupanel').className+= 'panel panel-green';
              /*  document.getElementById('CPUSLA').style.color= 'green';
                document.getElementById("CPUSLA").innerHTML="CPU is WITHIN SLA";*/
                }
                else if(maxcpu>50&&maxcpu<=70)
                {
                document.getElementById('cpupanel').className+= 'panel panel-yellow';
               /* document.getElementById('CPUSLA').style.color= 'yellow';
                document.getElementById("CPUSLA").innerHTML="CPU MET SLA";*/
                }
                else if(maxcpu>70)
                {
                document.getElementById('cpupanel').className+= 'panel panel-red';
               /* document.getElementById('CPUSLA').style.color= 'red';
                document.getElementById("CPUSLA").innerHTML="CPU EXCEEDED SLA";*/
                }
                document.getElementById("launchavgcpu").innerHTML="Avg CPU:"+launchavgcpu+"%"
                document.getElementById("launchmaxcpu").innerHTML="Max CPU: "+maxcpu+"%";
                
                var launchavgmem=Math.round((launchObje.Application.runs.rundetails.usecasedetail.usecasedetails.averagememory)/1024);
                //alert(launchavgmem);
                var launchmaxmem=Math.round((launchObje.Application.runs.rundetails.usecasedetail.usecasedetails.maxmemory)/1024);
                
                if(launchmaxmem<=70)
                {

                document.getElementById('memorypanel').className+= 'panel panel-green';
              /*  document.getElementById('MEMSLA').style.color= 'green';
                document.getElementById("MEMSLA").innerHTML="Memory is WITHIN SLA";*/
                }
                else if(launchmaxmem>70&&launchmaxmem<200)
                {
                document.getElementById('memorypanel').className+= 'panel panel-yellow';
               /*   document.getElementById('MEMSLA').style.color= 'orange';
                document.getElementById("MEMSLA").innerHTML="Memory MET SLA";*/
                }
                else if(launchmaxmem>200)
                {
                document.getElementById('memorypanel').className+= 'panel panel-red';
              /*    document.getElementById('MEMSLA').style.color= 'red';
                document.getElementById("MEMSLA").innerHTML="Memory EXCEEDED SLA";*/
                }
                
                                                              
                 document.getElementById("launchavgmem").innerHTML="Avg Memory: "+launchavgmem+"mb";
                 document.getElementById("launchmaxmem").innerHTML="Max Memory: "+launchmaxmem+"mb";
             //    alert("askjd"+crawlerObje.length)
  
                 for(var i=0;i<crawlerObje.length;i++)
                 {
                   cpuavgtemp=crawlerObje[i].Application.runs.rundetails.usecasedetail.usecasedetails.averagecpu;
                   if(cpuavgtemp>crawlingavgcpu)
                   {
                    crawlingavgcpu=cpuavgtemp;
                   }
                   cpumaxtemp=crawlerObje[i].Application.runs.rundetails.usecasedetail.usecasedetails.maxcpu;
                   if(cpumaxtemp>crawlingmaxcpu)
                   {
                    crawlingmaxcpu=cpumaxtemp;
                   }
                   memavgtemp=crawlerObje[i].Application.runs.rundetails.usecasedetail.usecasedetails.averagememory;
                   if(memavgtemp>crawlingavgmem)
                   {
                    crawlingavgmem=memavgtemp;
                   }
                   memmaxtemp=crawlerObje[i].Application.runs.rundetails.usecasedetail.usecasedetails.maxmemory;
                   if(memmaxtemp>crawlingmaxmem)
                   {
                    crawlingmaxmem=memmaxtemp;
                   }
                 }
                
                /* crawlingavgcpu=Math.round(cpuavgsum);
               
                 crawlingmaxcpu=Math.round(cpumaxsum);*/
          
                
                if(crawlingmaxcpu<=50)
                {
                document.getElementById('navicpupanel').className+= 'panel panel-green';
                }
                else if(crawlingmaxcpu>50&&crawlingmaxcpu<70)
                {
                document.getElementById('navicpupanel').className+= 'panel panel-yellow';
                }
                else if(crawlingmaxcpu>70)
                {
                document.getElementById('navicpupanel').className+= 'panel panel-red';
                }

                 document.getElementById("crawlingmaxcpu").innerHTML="Max CPU: "+crawlingmaxcpu+"%";
                 document.getElementById("crawlingavgcpu").innerHTML="Avg CPU: "+crawlingavgcpu+"%";

                 crawlingavgmem=Math.round((crawlingavgmem)/1024);
                crawlingmaxmem=Math.round((crawlingmaxmem)/1024);
                if(crawlingmaxmem<=70)
                {
                document.getElementById('navimemorypanel').className+= 'panel panel-green';
                }
                else if(crawlingmaxmem>70&&crawlingmaxmem<200)
                {
                document.getElementById('navimemorypanel').className+= 'panel panel-yellow';
                }
                else if(crawlingmaxmem>200)
                {
                document.getElementById('navimemorypanel').className+= 'panel panel-red';
                }

                 document.getElementById("crawlingavgmem").innerHTML="Avg Memory: "+crawlingavgmem+"mb";

                 document.getElementById("crawlingmaxmem").innerHTML="Max Memory: "+crawlingmaxmem+"mb";

                

                       dataMorrisArray=[];
    });


     /* $.getJSON("individual.json", function(json) {
        //window.alert('test');
            var parsedJson=[]
            var overallframeloaded=0;
            var overalljanksloaded=0;
       for(var j=0;j<json.length;j++)
            {
                for(i=0;i<json.length;i++)
                {
                 



                var metrics=json[i].activitymetrics;
                var cpu,thread,memory,before,after,name,gpuframe,gpujanks;
                before=json[i].beforeScreen;
                after=json[i].afterScreen;
                name=json[i].activity
                for(var k=0;k<metrics.length;k++)
                {
                    var keys=Object.keys(metrics[k]);
                    if(keys.length==2)
                    {
                        cpu=metrics[k].cpu.cpuincrease;
                        thread=metrics[k].thread.threadincrease;
                    }
                    if(keys.length==1)
                    {
                        if(keys[0]=="memory")
                        memory=metrics[k].memory.memoryincrease;
                        if(keys[0]=="gpu")
                        {
                        gpuframe=metrics[k].gpu.gpuframes;
                         gpujanks=metrics[k].gpu.gpujanks;
                    }
                    }
                    //window.alert(keys[0]+":"+keys[1]+":"+keys.length);
                }



                overallframeloaded+=parseInt(gpuframe);
                overalljanksloaded+=parseInt(gpujanks);


                    //}
                }
            }
          //  window.alert(overallframeloaded+":"+overalljanksloaded);
            if(isNaN(overallframeloaded))
            {
                 document.getElementById("framesrendered").innerHTML="Total Frames: "+0;
            }
            else
            {
                 document.getElementById("framesrendered").innerHTML="Total Frames: "+overallframeloaded;
            }
            if(isNaN(overalljanksloaded))
            {
                 document.getElementById("frameslost").innerHTML="Jank Frames : "+0;
            }
            else
            {
                 document.getElementById("frameslost").innerHTML="Jank Frames: "+overalljanksloaded;
            }
            //document.getElementById("framesrendered").innerHTML="Total Frames: "+overallframeloaded;framespanel
            
            var FramesLostPer=((overalljanksloaded/overallframeloaded)*100);
            //alert(FramesLostPer);
            if((FramesLostPer>=0)&(FramesLostPer<=10))
            {
            document.getElementById('framespanel').className+= 'panel panel-green';
            }
            else if((FramesLostPer>10)&(FramesLostPer<20))
            {
            document.getElementById('framespanel').className+= 'panel panel-yellow';
            }
            else
            {
            document.getElementById('framespanel').className+= 'panel panel-yellow';
            }
            
            
    }); */
   

    