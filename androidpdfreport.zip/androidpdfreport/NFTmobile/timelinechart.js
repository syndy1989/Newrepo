function loadgraph(ClickName)
{
   var ul = document.getElementById(ClickName);
   console.log(ul)
    if(ul!=undefined)
{
	console.log(ClickName)
  var RequestedPageArr=[];
  var StrTimeArr=[];
  var EndTimeArr=[];
  var role=[];
  var size;
  var color=[];
                $.getJSON("Result.json", function(json)
    {


     $("#"+ClickName+ClickName).remove();
     $("#timelineChart").remove();
//alert("uifffff"+ul.childElementCount)



                                var hits= json
                                for(var i=0;i< json.length ;i++)
                                {
                                                var eachobj=hits[i];
                                                var eachobjkeys=Object.keys(eachobj);
                                //            var eachusecase=eachobj[eachobjkeys]; 
                                                                                                                 
                                                eachobjkeys.forEach(function (key)
                                                {
                                                                if(eachobj.hasOwnProperty(usecasenamedtl))
                                                                {                          
                                                                                var eachusecase=eachobj[eachobjkeys];    

                                                                                for(var j=0;j<eachusecase.length;j++)
                                                                                {
                                                                                                var eachPage = eachusecase[j];
                                                                                                var eachpagekeys=Object.keys(eachPage);
                                                                                                if(eachpagekeys==ClickName)
                                                                                                {
                                                                                                    
                                                                                                   // alert(ClickName+"=="+eachpagekeys)
                                                                                                                var pagewisedetails=eachPage[eachpagekeys];
                                                                                                               
                                                                                                                
                                                                                                                var chartDiv1 = document.createElement('div');
                                                                                                                chartDiv1.setAttribute("class","row");
                                                                                                                 chartDiv1.setAttribute("id",ClickName+ClickName);
                                                                                                       
                                                                                                                var gridWidth=document.createElement('div');
                        gridWidth.setAttribute("class","col-lg-12");

                        var panelRoot=document.createElement('div');
                        panelRoot.setAttribute("class","panel panel-default");

                        var panelHeading=document.createElement('div');
                        panelHeading.setAttribute("class","panel-heading");

                        var heading3=document.createElement('a');
                        heading3.setAttribute("class","panel-title");                        
                       
                        var icon=document.createElement('i');
                        icon.setAttribute("class","fa fa-long-arrow-right fa-fw");

                        heading3.appendChild(icon);
                        heading3.innerHTML=eachpagekeys;
                                                                  

                        var panelBody=document.createElement('div');
                        panelBody.setAttribute("class","panel-body");                                              
                         var chartDiv = document.createElement('div');
                        chartDiv.setAttribute("class","col-lg-12");
                                                                                                               chartDiv.setAttribute("id","timelineChart");                                    
                                                                                                             
                                                                                                                 size = pagewisedetails.NetworkDetails.length;
                                                                                                                var hig = (45*size) +100;
                                                                                                                chartDiv.setAttribute("style", "height: "+hig+"px;");
                                                                                                                var n = 0;
                                                                                                                for(var m=0; m<(pagewisedetails.NetworkDetails.length); m++)
                                                                                                                {
                                                                                                //                            alert("naa vandhitenn"+ClickName)     
                                                                                                                                var networkdetails = pagewisedetails.NetworkDetails[m];
                                                                                                                                var strTime =      networkdetails.Time.start ;
                                                                                                                                                
                                                                                                                                strTime = strTime.replace(/([-:.T])/gi, ',');
                                                                                                //                            alert("strTime is "+strTime);
                                                                                                //                            var EndTime =   networkdetails.Time.end ;
                                                                                                //                            EndTime = EndTime.replace(/([-:.T])/gi, ',');
                                                                                                                                strTime=strTime.slice(0, -6);
                                                                                                //                            EndTime=EndTime.slice(0, -6);
                                                                                                                                var caseWiseStrtTime = strTime ;
                                                                                                                                                
                                                                                                                                var strtTmSplt = strTime.split(",");
                                                                                                                                var sec = parseInt(strtTmSplt[6]);
                                                                                                                                var min = parseInt(strtTmSplt[5]);
                                                                                                                                                
                                                                                                                                                
                                                                                                                                var q=0;
                                                                                                                                              
                                                                                                                                var caseWiseEndTime ="";
                                                                                                                                for(var p=n;p<(n+4);p++)
                                                                                                                                {
                                                                                //                                                            alert("loop no "+ q)
                                                                                                                                                                
                                                                                                                                                if(q==0)
                                                                                                                                                {
                                                                                                                                                                
                                                                                                                                                                sec= sec+ networkdetails.Duration.connect ;
                                                                                                                                                                if(sec>=1000)
                                                                                                                                                                {
                                                                                                                                                                                sec = sec-1000;
                                                                                                                                                                                min = min+1;
                                                                                                                                                                }
                                                                                                                                                                caseWiseEndTime="";
                                                                                                                                                                for(var r=0; r<7;r++)
                                                                                                                                                                {              
                                                                                                                                                                                if(r==5)
                                                                                                                                                                                {
                                                                                                                                                                                                caseWiseEndTime = caseWiseEndTime+ min +",";
                                                                                                                                                                                }
                                                                                                                                                                                else if(r==6)
                                                                                                                                                                                {
                                                                                                                                                                                                caseWiseEndTime = caseWiseEndTime+ sec ;
                                                                                                                                                                                }
                                                                                                                                                                                else
                                                                                                                                                                                {
                                                                                                                                                                                                caseWiseEndTime = caseWiseEndTime+ strtTmSplt[r] +","; 
                                                                                                                                                                                }
                                                                                                                                                                                
                                                                                                                                                                }
                                                                                                                                                                StrTimeArr[p] = caseWiseStrtTime ;
                                                                                                                                                                EndTimeArr[p] = caseWiseEndTime ;
                                                                                                                                                                role[p] = "connect" ;
                                                                                                                                                                color[p]="#4285f4"
                                                                                                //                                                            alert(p +"  role, caseWiseStrtTimecase, WiseEndTime  "+role[p]+"  "+caseWiseStrtTime+"  "+caseWiseEndTime)
                                                                                                                                                }
                                                                                                                                                if(q==1)
                                                                                                                                                {
                                                                                                                                                                sec= sec+ networkdetails.Duration.dns ;
                                                                                                                                                                if(sec>=1000)
                                                                                                                                                                {
                                                                                                                                                                                sec = sec-1000;
                                                                                                                                                                                min = min+1;
                                                                                                                                                                }
                                                                                                                                                                caseWiseEndTime="";
                                                                                                                                                                for(var r=0; r<7;r++)
                                                                                                                                                                {
                                                                                                                                                                
                                                                                                                                                                                if(r==5)
                                                                                                                                                                                {
                                                                                                                                                                                                caseWiseEndTime = caseWiseEndTime+ min +",";
                                                                                                                                                                                }
                                                                                                                                                                                else if(r==6)
                                                                                                                                                                                {
                                                                                                                                                                                                caseWiseEndTime = caseWiseEndTime+ sec ;
                                                                                                                                                                                }
                                                                                                                                                                                else
                                                                                                                                                                                {
                                                                                                                                                                                                caseWiseEndTime = caseWiseEndTime+ strtTmSplt[r] +","; 
                                                                                                                                                                                }
                                                                                                                                                                                                
                                                                                                                                                                }
                                                                                                                                                                StrTimeArr[p] = caseWiseStrtTime ;
                                                                                                                                                                EndTimeArr[p] = caseWiseEndTime ;
                                                                                                                                                                role[p] = "dns" ;
                                                                                                                                                                 color[p]="#db4437"
                                                                                                                //                                            alert(p +"  role, caseWiseStrtTimecase, WiseEndTime  "+role[p]+"  "+caseWiseStrtTime+"  "+caseWiseEndTime)
                                                                                                                                                }
                                                                                                                                                if(q==2)
                                                                                                                                                {                                                                              
                                                                                                                                                                sec= sec+ networkdetails.Duration.ssl ;
                                                                                                                                                                if(sec>=1000)
                                                                                                                                                                {
                                                                                                                                                                                sec = sec-1000;
                                                                                                                                                                                min = min+1;
                                                                                                                                                                }
                                                                                                                                                                caseWiseEndTime="";
                                                                                                                                                                for(var r=0; r<7;r++)
                                                                                                                                                                {
                                                                                                                                                                                
                                                                                                                                                                                if(r==5)
                                                                                                                                                                                {
                                                                                                                                                                                                caseWiseEndTime = caseWiseEndTime+ min +",";
                                                                                                                                                                                }
                                                                                                                                                                                else if(r==6)
                                                                                                                                                                                {
                                                                                                                                                                                                caseWiseEndTime = caseWiseEndTime+ sec ;
                                                                                                                                                                                }
                                                                                                                                                                                else
                                                                                                                                                                                {
                                                                                                                                                                                                caseWiseEndTime = caseWiseEndTime+ strtTmSplt[r] +","; 
                                                                                                                                                                                }
                                                                                                                                                                                                
                                                                                                                                                                }
                                                                                                                                                                StrTimeArr[p] = caseWiseStrtTime ;
                                                                                                                                                                EndTimeArr[p] = caseWiseEndTime ;
                                                                                                                                                                role[p] = "ssl" ;
                                                                                                                                                                    color[p] = "#f4b400" ;
                                                                                                                //                                            alert(p +"  role, caseWiseStrtTimecase, WiseEndTime  "+role[p]+"  "+caseWiseStrtTime+"  "+caseWiseEndTime)
                                                                                                                                                                
                                                                                                                                                }
                                                                                                                                                if(q==3)
                                                                                                                                                {
                                                                                                                                                                sec= sec+ networkdetails.Duration.latency ;
                                                                                                                                                                if(sec>=1000)
                                                                                                                                                                {
                                                                                                                                                                                sec = sec-1000;
                                                                                                                                                                                min = min+1;
                                                                                                                                                                }
                                                                                                                                                                caseWiseEndTime="";
                                                                                                                                                                for(var r=0; r<7;r++)
                                                                                                                                                                {
                                                                                                                                                                                                
                                                                                                                                                                                if(r==5)
                                                                                                                                                                                {
                                                                                                                                                                                                caseWiseEndTime = caseWiseEndTime+ min +",";
                                                                                                                                                                                }
                                                                                                                                                                                else if(r==6)
                                                                                                                                                                                {
                                                                                                                                                                                                caseWiseEndTime = caseWiseEndTime+ sec ;
                                                                                                                                                                                }
                                                                                                                                                                                else
                                                                                                                                                                                {
                                                                                                                                                                                                caseWiseEndTime = caseWiseEndTime+ strtTmSplt[r] +","; 
                                                                                                                                                                                }
                                                                                                                                                                                                
                                                                                                                                                                }
                                                                                                                                                                StrTimeArr[p] = caseWiseStrtTime ;
                                                                                                                                                                EndTimeArr[p] = caseWiseEndTime ;
                                                                                                                                                                role[p] = "latency" ;
                                                                                                                //                                            alert(p +"  role, caseWiseStrtTimecase, WiseEndTime  "+role[p]+"  "+caseWiseStrtTime+"  "+caseWiseEndTime)
                                                                                                                                                                 color[p] = "#0f9d58" ;   
                                                                                                                                                }
                                                                                                                                                
                                                                                                                                                caseWiseStrtTime = caseWiseEndTime;
                                                                                                                
                                                                                                                                                q++;
                                                                                                                                                RequestedPageArr[p] = networkdetails.RequestedPage+"_"+n ;
                                                                                                                                                                                                    
                                                                                                                                      
                                                                                                                                }
                                                                                                                                n = n +4;
      
                                                                                                
                                                                                                }
                                                                                           
                                                                                  panelHeading.appendChild(heading3);
                                                                                                panelBody.appendChild(chartDiv)

                                                                                                panelRoot.appendChild(panelHeading);
                                                                                                panelRoot.appendChild(panelBody)
                                                                                                gridWidth.appendChild(panelRoot);          
                                                                                                chartDiv1.appendChild(gridWidth);
                                                                                                                
                                                                                                document.getElementById(eachpagekeys).appendChild(chartDiv1); 

                                                                                }
                                                                }
                                                }
                                                
        })
          
    }
        

                              
})
 drawChart()   
    }                                                                  
       
                                                                                       
                                                                                           
                                                                                                                
    
                                                                                           
                                                                 function drawChart(){
/**
 * ---------------------------------------
 * This demo was created using amCharts 4.
 * 
 * For more information visit:
 * https://www.amcharts.com/
 * 
 * Documentation is available at:
 * https://www.amcharts.com/docs/v4/
 * ---------------------------------------
 */
// Themes begin
$.getScript("core.js");
$.getScript("charts.js");
$.getScript("animated.js");
setTimeout(function() { drawChart2()}, 100);


                                                                                                
                                                                                                                /* <!-- drawChart(RequestedPageArr ,StrTimeArr, EndTimeArr); -->*/
                                                                              function drawChart2(){

  	var datarray=[];
  	console.log(RequestedPageArr.length)
  	  for(var j=0; j<(RequestedPageArr.length); j++)
     {
console.log(str1)
   var str1 = StrTimeArr[j].split(",");
   var str2 = EndTimeArr[j].split(",");
   var start=(new Date(str1[0],str1[1],str1[2],str1[3],str1[4],str1[5],str1[6]))
      var end=(new Date(str2[0],str2[1],str2[2],str2[3],str2[4],str2[5],str2[6]))
      var sd = new Date(start);
sdatetext = sd.toTimeString();

sdatetext =sdatetext.split(' ')[0] +' ' + sd.getMilliseconds();

var ed=new Date(end);
edatetext = ed.toTimeString();

edatetext =edatetext.split(' ')[0] +' ' + ed.getMilliseconds();
   var seconds = (new Date(end.getTime())- new Date(start.getTime())) / 1000;
    datarray.push({
       	"category":RequestedPageArr[j],
       	"start":new Date(start),
       	"end":new Date(end),
"startme":sdatetext,
"endme":edatetext,
       	"seconds":seconds,
       	"color":color[j],
       	"task":role[j]
       })                

    }
    console.log(datarray)
  	am4core.useTheme(am4themes_animated);
// Themes end

var chart = am4core.create(document.getElementById('timelineChart'), am4charts.XYChart);
chart.hiddenState.properties.opacity = 0; // this creates initial fade-in

chart.paddingRight = 30;


var colorSet = new am4core.ColorSet();
colorSet.saturation = 0.4;

chart.data = datarray;



var categoryAxis = chart.yAxes.push(new am4charts.CategoryAxis());
categoryAxis.dataFields.category = "category";
categoryAxis.renderer.grid.template.location = 0;
var label = categoryAxis.renderer.labels.template;
label.truncate = true;
label.maxWidth = 500;

label.tooltipText = "{category}";
categoryAxis.tooltip.maxWidth = 400;
categoryAxis.tooltip.label.wrap = true;
categoryAxis.tooltip.label.textAlign = "middle";


categoryAxis.renderer.inversed = true;

var dateAxis = chart.xAxes.push(new am4charts.DateAxis());

// dateAxis.max = new Date(2018, 0, 1, 24, 0, 0, 0).getTime();
//dateAxis.strictMinMax = true;
dateAxis.baseInterval = {
  "timeUnit": "millisecond",
  "count": 10
}
dateAxis.renderer.tooltipLocation = 0;

var series1 = chart.series.push(new am4charts.ColumnSeries());
series1.columns.template.width = am4core.percent(80);

series1.columns.template.tooltipText = "{task}:\nStart - End: {startme}-{endme}\nDuration: {seconds} seconds";
series1.dataFields.openDateX = "start";
series1.dataFields.dateX = "end";

series1.dataFields.categoryY = "category";
series1.columns.template.propertyFields.fill = "color"; // get color from data
series1.columns.template.propertyFields.stroke = "color";
series1.columns.template.strokeOpacity = 1;

chart.scrollbarX = new am4core.Scrollbar();
  }                         
                                                                                                          
                                                                                              
    }
}