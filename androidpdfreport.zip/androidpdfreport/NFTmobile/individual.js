   $.ajaxSetup({
    async: false
});

var Resultjson=null;
var eachobjkeys=null;

        $.getJSON("mobile.json", function(json) 
        {     
      var hits=json
   
for(var k=0;k<hits.length;k++)  
{

 $('#demo').append('<li><a href= final.html?'+hits[k]._source.Application.runs.rundetails.usecasedetail.usecasename+' ><i class=fa fa-fw fa-bar-chart-o></i>'+hits[k]._source.Application.runs.rundetails.usecasedetail.usecasename+'</a></li>');
  
} 
 });

 $.getJSON("Result.json", function(json) 
              {
       Resultjson=json;
     console.log(Resultjson);
          });       
                    
                       
  $.getJSON("individual.json", function(json)
   {

        for(var l=0;l<Resultjson.length;l++)
        {
                     var eachpagekeys;
                     var PageSize=0;
                      var eachpagesize;
                     var eachobj=Resultjson[l];

	if(JSON.stringify(eachobj).includes("App-Launch"))
{
continue;
}

                      eachobjkeys=Object.keys(eachobj);
                       
		
                    

                eachobjkeys.forEach(function (key)
                         {

                       var eachusecase=eachobj[eachobjkeys];    
                 //  console.log("eachusecase"+JSON.stringify(eachusecase))
                     for(var m=0;m<eachusecase.length;m++)
                     {
                        var PageSize=0;
                      var eachpagesize;
                         var eachpage=eachusecase[m];  

                     //   console.log("eachpage"+JSON.stringify(eachpage));
                         eachpagekeys=Object.keys(eachpage);
                        //alert(eachpage.size)
                        //alert("eachpage"+(eachpagekeys.length));
                        var pagewisedetails=eachpage[eachpagekeys];
                     // alert("pagewisedetails"+JSON.stringify(pagewisedetails));
                      var pagewisekeys=Object.keys(pagewisedetails);
                     var netcalls=pagewisedetails.NetworkDetails.length;  
                        
                        //alert(netcalls)
                      for(var x=0;x<netcalls;x++)
                        {
                            eachpagesize=pagewisedetails.NetworkDetails[x].ResponseSize;
//alert(eachpagesize);
                            PageSize=PageSize+eachpagesize;
                        }
                      
                        var transactionsize=0;       
                        var parsedJson=[];

//alert(json.length);
//alert(eachpagekeys);
                        for(i=0;i<json.length;i++)
                         {

                            name=json[i].activity
//salert(name);

                            if(name==eachpagekeys)
                            {
                var metrics=json[i].activitymetrics;
                var cpu,thread,memory,before,after,name,gpuframe,gpujanks,responsetime, maxcpu, maxmem;
                before=json[i].beforeScreen;
                     
                after=json[i].afterScreen;
            
                responsetime=json[i].ResponseTime
                for(var k=0;k<metrics.length;k++)
                {
                    var keys=Object.keys(metrics[k]);
                    if(keys.length==2)
                    {
                        cpu=metrics[k].cpu.cpuincrease;
                      maxcpu = metrics[k].cpu.cpumax;
                        //thread=metrics[k].thread.threadincrease;
                    }
                    if(keys.length==1)
                    {
                        if(keys[0]=="memory")
                        {
                        memory=(Math.round(metrics[k].memory.memoryincrease)/1024).toFixed(0);
                         maxmem = (Math.round(metrics[k].memory.memorymax)/1024).toFixed(0);
                      }
                        if(keys[0]=="gpu")
                        {
                        gpuframe=metrics[k].gpu.gpuframes;
                         gpujanks=metrics[k].gpu.gpujanks;
                       }
			if(keys[0]=="cpu")
                        {
                        cpu=metrics[k].cpu.cpuincrease;
                      maxcpu = metrics[k].cpu.cpumax;
                        //thread=metrics[k].thread.threadincrease;
                       }
                    }
                }
                    var tablerow=document.createElement('tr');
                    var tablecolumn0=document.createElement('td');
                    var tablecolum1=document.createElement('td');
                    var tablecolum2=document.createElement('td');
                   
                    var tablecolum3=document.createElement('td');
                    var tablecolum4=document.createElement('td');
                    var tablecolum5=document.createElement('td');
                    var tablecolum6=document.createElement('td');
                    var tablecolum7=document.createElement('td');
                    var tablecolum8=document.createElement('td');
                   
                    var tablecolum9=document.createElement('td');
                    var tablecolum10=document.createElement('td');
                    var tablecolum11=document.createElement('td');

                    tablecolumn0.innerHTML=i+1;
                    tablecolum1.innerHTML=name;

                    tablecolum2.innerHTML="<img src='"+before+"' class='img-rounded' alt='loading...' width='50' height='75'> </td>";
                    tablecolum2.setAttribute("id",before+i);
                    tablecolum8.innerHTML="<img src='"+after+"' class='img-rounded' alt='loading...' width='50' height='75'> </td>";
                    tablecolum8.setAttribute("id",after+i);

                    (function(){
                      var testbefore=before;
                      var testafter=after;             
                      tablecolum2.addEventListener("click",function(){popup(testbefore);},false);
                              tablecolum8.addEventListener("click",function(){popup(testafter);},false);
                    })();
                   
                      cpu=cpu.toString();
                      cpu=cpu.replace("%","");
                      cpu=parseFloat(cpu);

                     
                      if(cpu<=10)
                      {
                         tablecolum3.innerHTML=(maxcpu)+" , "+cpu+" (↑) "+"<img src='greendot.png' class='img-rounded' align='right' alt='loading...'> </td>";
                      }
                      else if(cpu>10 && cpu<=15)
                      {
                         tablecolum3.innerHTML=(maxcpu)+" , "+cpu+" (↑) "+"<img src='amberdot.png' class='img-rounded'  align='right'  alt='loading...' > </td>";
                      }
                      else
                      {
                         tablecolum3.innerHTML=(maxcpu)+" , "+cpu+" (↑) "+"<img src='reddot.png' class='img-rounded' align='right'  alt='loading...' > </td>";
                      }
                    if(memory<=(30))
                      {
                           tablecolum4.innerHTML=(maxmem)+" , "+memory+" (↑) "+"<img src='greendot.png' class='img-rounded'  align='right' alt='loading...'> </td>";
                        }
                    else if((memory>30)&&(memory<=50))
                       {
                           tablecolum4.innerHTML=(maxmem)+" , "+memory+" (↑) "+"<img src='amberdot.png' class='img-rounded' align='right'  alt='loading...'> </td>";
                       }
                     else 
                       {
                           tablecolum4.innerHTML=(maxmem)+" , "+memory+" (↑) "+"<img src='reddot.png' class='img-rounded'  align='right' alt='loading...'> </td>";
                       }

                    tablecolum6.innerHTML=gpuframe;
                    tablecolum7.innerHTML=gpujanks;

                    if(responsetime<=3000)
                    {
                     tablecolum9.innerHTML=responsetime+"<img src='greendot.png' class='img-rounded'  align='right' alt='loading...'> </td>";
                    }
                      else if((responsetime>3000)&&(responsetime<5000))
                    {
                        tablecolum9.innerHTML=responsetime+"<img src='amberdot.png' class='img-rounded'  align='right' alt='loading...' > </td>";
                    }
                    else
                    {
                          tablecolum9.innerHTML=responsetime+"<img src='reddot.png' class='img-rounded' align='right'  alt='loading...' > </td>";
                    }

                         if(netcalls<=10)
                    {
                     tablecolum11.innerHTML=netcalls+"<img src='greendot.png' class='img-rounded'  align='right' alt='loading...'> </td>";
                    }
                      else if((netcalls>10)&&(netcalls<50))
                    {
                        tablecolum11.innerHTML=netcalls+"<img src='amberdot.png' class='img-rounded'  align='right' alt='loading...' > </td>";
                    }
                    else
                    {
                          tablecolum11.innerHTML=netcalls+"<img src='reddot.png' class='img-rounded'  align='right' alt='loading...' > </td>";
                    }

                    if(PageSize<(500*1024))
                   {
                    tablecolum10.innerHTML=PageSize+"<img src='greendot.png' class='img-rounded'  align='right' alt='loading...'> </td>";
                   }
                   else if((PageSize>(500*1024))&&(PageSize<=(750*1024)))
                   {
                      tablecolum10.innerHTML=PageSize+"<img src='amberdot.png' class='img-rounded'  align='right' alt='loading...' > </td>";
                   }
                   else if(PageSize>(750*1024))
                  {
                    tablecolum10.innerHTML=PageSize+"<img src='reddot.png' class='img-rounded' align='right'  alt='loading...' > </td>";
                   }
                                
                    tablerow.appendChild(tablecolumn0);
                    tablerow.appendChild(tablecolum1);
                    tablerow.appendChild(tablecolum9);
                    tablerow.appendChild(tablecolum3);
                    tablerow.appendChild(tablecolum4);
                   /* tablerow.appendChild(tablecolum6);
                    tablerow.appendChild(tablecolum7);*/
                    tablerow.appendChild(tablecolum10);
                    tablerow.appendChild(tablecolum11);
                    tablerow.appendChild(tablecolum2);
                    tablerow.appendChild(tablecolum8);       

                   document.getElementById("transactiondetails").appendChild(tablerow);                                        
           }
         }
       }
    });
  }
                     


 function popup(evt)
{

  $('#imagepreview').attr('src',evt); // here asign the image to the modal when the user click the enlarge link
   $('#imagemodal').modal('show');
   var imagename=evt;
   imagename=imagename.replace("..","");
   imagename=imagename.replace("\\","");
   imagename=imagename.replace("\\","");
   imagename=imagename.replace(".png","");
   imagename=imagename.replace("screen","");
  document.getElementById("myModalLabel").innerHTML=imagename;
}
});