 $.getJSON("mobile.json", function(json) { 
    // alert("welcome")
    
      var hits=json
      //alert(hits.length);
        // console.log  ("Application JSON"+JSON.stringify(hits));
       
    //console.log("Application JSON"+JSON.stringify(usecases[0].usecasename));
    //   alert("length"+usecases.length)
        //var usecases=hits.usecase;
   
for(var k=0;k<hits.length;k++)  
{

 $('#demo').append('<li><a href= final.html?'+hits[k]._source.Application.runs.rundetails.usecasedetail.usecasename+' ><i class=fa fa-fw fa-bar-chart-o></i>'+hits[k]._source.Application.runs.rundetails.usecasedetail.usecasename+'</a></li>');
  
}  });

        
  $.getJSON("mobile.json", function(json) {
       

         var hits=json;
            var currentbuildNumber=0;
            var previousbuildNumber=0;
            for(var i=0;i<hits.length;i++)
            {
               

                if(hits.length==0)
                {
                    
                 currentbuildNumber=parseInt(hits[i]._source.Application.runs.rundetails["runid"]);
                }
                else if(hits.length==1)
                {
                        
                previousbuildNumber=parseInt(hits[i]._source.Application.runs.rundetails["runid"]);
                if(currentbuildNumber<previousbuildNumber)
                {
                    var temp=currentbuildNumber;
                    currentbuildNumber=previousbuildNumber;
                    previousbuildNumber=temp;
                }
                }
            else
            {
                    if(currentbuildNumber<parseInt(hits[i]._source.Application.runs.rundetails["runid"]))
                    {
                        previousbuildNumber=currentbuildNumber;
                        currentbuildNumber=parseInt(hits[i]._source.Application.runs.rundetails["runid"]);
                    }
                    else if ((previousbuildNumber<parseInt(hits[i]._source.Application.runs.rundetails["runid"]))&&(parseInt(hits[i]._source.Application.runs.rundetails["runid"])!=currentbuildNumber)) {
                        
                        previousbuildNumber= parseInt(hits[i]._source.Application.runs.rundetails["runid"]);
                    }
            }
              
               
            }


             var currentTransactions=[];
            var previousTransactions=[];
            var currentJob;
            var previousJob;
          

                if(currentbuildNumber!=previousbuildNumber)
                {
                   for(var i=0;i<hits.length;i++)
                    {   
                        
                           if(parseInt(hits[i]._source.Application.runs.rundetails["runid"])==currentbuildNumber)
                                 {
                                        currentJob=hits[i]._source;
                                      currentTransactions.push(hits[i]._source);

                                      
                                 } 
                                 else  if(parseInt(hits[i]._source.Application.runs.rundetails["runid"])==previousbuildNumber)
                                 {
                                        previousJob=hits[i]._source;
                                      
                                      previousTransactions.push(hits[i]._source);
                                 } 
                    }
                }
               
         
          // window.alert("imman"+JSON.stringify(currentJob.applicationName));
          document.getElementById("packageid").innerHTML=currentJob.Application.applicationName;
                // document.getElementById("runid").innerHTML=currentJob.Application.runs.rundetails.runid;
                       //document.getElementById("usecasecount").innerHTML=currentTransactions.length;


                       if(currentTransactions.length==previousTransactions.length)
            {        

                /*window.alert('test1');*/
            for(var i=0;i<currentTransactions.length;i++)
            {


              

                                 var tablerow=document.createElement('tr');
                
                    var tablecolum1=document.createElement('td');
                    var tablecolum2=document.createElement('td');
                    var tablecolum3=document.createElement('td');
               


                    tablecolum1.innerHTML=currentTransactions[i].Application.runs.rundetails.usecasedetail.usecasename;
                    tablecolum2.innerHTML=currentTransactions[i].Application.runs.rundetails.usecasedetail.usecasedetails.averagecpu;
                    tablecolum3.innerHTML=currentTransactions[i].Application.runs.rundetails.usecasedetail.usecasedetails.maxcpu;
           

                    tablerow.appendChild(tablecolum1);
                    tablerow.appendChild(tablecolum2);
                    tablerow.appendChild(tablecolum3);
         
                

                    
              // document.getElementById("transactiondetails").appendChild(tablerow);   

               
                

            }   
           }   
 if(currentTransactions.length!=previousTransactions.length)
            {        
                
            for(var i=0;i<currentTransactions.length;i++)
            {


              

                                 var tablerow=document.createElement('tr');
                
                    var tablecolum1=document.createElement('td');
                    var tablecolum2=document.createElement('td');
                    var tablecolum3=document.createElement('td');
               


                    tablecolum1.innerHTML=currentTransactions[i].Application.runs.rundetails.usecasedetail.usecasename;
                    tablecolum2.innerHTML=currentTransactions[i].Application.runs.rundetails.usecasedetail.usecasedetails.averagecpu;
                    tablecolum3.innerHTML=currentTransactions[i].Application.runs.rundetails.usecasedetail.usecasedetails.maxcpu;
           

                    tablerow.appendChild(tablecolum1);
                    tablerow.appendChild(tablecolum2);
                    tablerow.appendChild(tablecolum3);
         
                

                    
              // document.getElementById("transactiondetails").appendChild(tablerow);   

               
                

            }   
           }   



                    for(var i=0;i<currentTransactions.length;i++)
                    {

                        var row=document.createElement('div');
                        row.setAttribute("class","row");

                        var gridWidth=document.createElement('div');
                        gridWidth.setAttribute("class","col-lg-12");

                        var panelRoot=document.createElement('div');
                        panelRoot.setAttribute("class","panel panel-default");

                        var panelHeading=document.createElement('div');
                        panelHeading.setAttribute("class","panel-heading");

                        var heading3=document.createElement('h3');
                        heading3.setAttribute("class","panel-title");

                        var icon=document.createElement('i');
                        icon.setAttribute("class","fa fa-long-arrow-right fa-fw");

                        heading3.appendChild(icon);
                        heading3.innerHTML="Usecase Graph:  "+currentTransactions[i].Application.runs.rundetails.usecasedetail.usecasename;

                        

                        var panelBody=document.createElement('div');
                        panelBody.setAttribute("class","panel-body");

                        var chart=document.createElement('div');
                        chart.setAttribute("id",currentTransactions[i].Application.runs.rundetails.usecasedetail.usecasename);

                        panelBody.appendChild(chart);
                        panelHeading.appendChild(heading3);

                        panelRoot.appendChild(panelHeading);
                        panelRoot.appendChild(panelBody);

                        gridWidth.appendChild(panelRoot);
                        row.appendChild(gridWidth);
                        //document.getElementById("mainDiv").appendChild(row); 
                         }
                        // window.alert(JSON.stringify(currentJob.Application.runs.rundetails.usecasedetail.usecasedetails.cpudetails));
            // window.alert( Object.keys(currentJob.Application.runs.rundetails.usecasedetail.usecasedetails.cpudetails).length);
          
          document.getElementById("productName").innerHTML=currentJob.Application.runs.rundetails.usecasedetail.usecasedetails.appPhone.phone["[ro$product$model]"];
          document.getElementById("ram").innerHTML=currentJob.Application.runs.rundetails.usecasedetail.usecasedetails.appPhone.phone["[phoneRam]"];
//[deviceos]
         //document.getElementById("DeviceOS").innerHTML="MarshMellow";
	document.getElementById("DeviceOS").innerHTML=currentJob.Application.runs.rundetails.usecasedetail.usecasedetails.appPhone.phone["[deviceos]"];
          // document.getElementById("ram").innerHTML="2GB";
         //  document.getElementById("operator").innerHTML=currentJob.Application.runs.rundetails.usecasedetail.usecasedetails.appPhone.phone["[gsm$sim$operator$alpha]"];
           document.getElementById("timeZone").innerHTML=currentJob.Application.runs.rundetails.usecasedetail.usecasedetails.appPhone.phone["[persist$sys$timezone]"];
           document.getElementById("cpu").innerHTML=currentJob.Application.runs.rundetails.usecasedetail.usecasedetails.appPhone.phone["[devicecores]"];
          
          
             var dataMorrisArray=[];
                        var duration=300;
             var intervalCounter=0;
                    for(var i=0;i<currentTransactions.length;i++)
                    { 
                        
                        
                        for(var j=0;j<Object.keys(currentJob.Application.runs.rundetails.usecasedetail.usecasedetails.cpudetails).length;j++)
                        {
                            var dataMorrisObj={};
                                       var interval=Math.round(300/Object.keys(currentJob.Application.runs.rundetails.usecasedetail.usecasedetails.cpudetails).length);
                        /*window.alert(interval);*/
                       /* window.alert(interval);*/
                        intervalCounter+=interval;
                         //window.alert(intervalCounter);
                       // window.alert(intervalCounter);
                                dataMorrisObj["y"]=intervalCounter;
                    dataMorrisObj["a"]=currentTransactions[i].Application.runs.rundetails.usecasedetail.usecasedetails.cpudetails[(j+1)+"s"];
                        dataMorrisArray.push(dataMorrisObj);
                        }
                        /*
                        Morris.Line({
                                element: currentTransactions[i].Application.runs.rundetails.usecasedetail.usecasename,
                                 data:dataMorrisArray,
                                  xkey: 'y',
                                 ykeys: ['a'],
                                    labels: ['Series A'],
                                parseTime: false
                            });*/
dataMorrisArray=[];
                    }

//window.alert(JSON.stringify(dataMorrisArray));
//console.log("testimman:"+JSON.stringify(dataMorrisArray));
 /*                   Morris.Line({
  element: 'line-example',
  data: [
    { y: '2006', a: 100},
    { y: '2007', a: 75},
    { y: '2008', a: 50 },
    { y: '2009', a: 75 },
    { y: '2010', a: 50 },
    { y: '2011', a: 75},
    { y: '2012', a: 100 }
  ],
  xkey: 'y',
  ykeys: ['a'],
  labels: ['Series A']
});*/
//document.getElementById("percentile90").appendChild(tablerow); 
                             /*      <div class="row">
                    <div class="col-lg-6">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h3 class="panel-title"><i class="fa fa-long-arrow-right fa-fw"></i>Mobile Market Share</h3>
                            </div>
                            <div class="panel-body">
                                <div id="morris-donut-chart"></div>
                                
                            </div>
                        </div>
                    </div>*/



                   
          /* var moorisArray=[];
          

            for(var i=0;i<currentTransactions.length;i++)
            {
                var currentObje=currentTransactions[i];
                 var moorisObject={};
                 moorisObject.period=currentObje.Application.runs.rundetails.usecasedetail.usecasename;
                 moorisObject.battery=currentObje.Application.runs.rundetails.usecasedetail.usecasedetails.averagebattery;
                 moorisObject.cpu=currentObje.Application.runs.rundetails.usecasedetail.usecasedetails.averagecpu;
                 moorisObject.memory=parseFloat(currentObje.Application.runs.rundetails.usecasedetail.usecasedetails.averagememory)/1024;
                  moorisObject.network=parseInt(currentObje.Application.runs.rundetails.usecasedetail.usecasedetails.usecaseresponsetime)/1000;
                 moorisArray.push(moorisObject)

            }
            var cpu=0,battery=0,network=0,memory=0;
             for(var i=0;i<currentTransactions.length;i++)
            {
                var currentObje=currentTransactions[i];
                 
                  cpu+=parseInt(currentObje.Application.runs.rundetails.usecasedetail.usecasedetails.averagecpu);
                  battery+=parseInt(currentObje.Application.runs.rundetails.usecasedetail.usecasedetails.averagebattery);
                  memory+=(parseInt(currentObje.Application.runs.rundetails.usecasedetail.usecasedetails.averagememory))/1024;
                  network+=(parseInt(currentObje.Application.runs.rundetails.usecasedetail.usecasedetails.usecaseresponsetime))/1000;
               

            }

                document.getElementById("overallcpu").innerHTML=Math.ceil(cpu/currentTransactions.length)+"%";
                 document.getElementById("overallbattery").innerHTML=Math.ceil(battery/currentTransactions.length)+"mAh";
                  document.getElementById("overallmemory").innerHTML=Math.ceil(memory/currentTransactions.length)+"mB";*/
                  // document.getElementById("overallnetwork").innerHTML=Math.ceil(network/currentTransactions.length)+"s";
             
    });
/*[{
            period: 'Launch',
            battery: 250,
            cpu: 50,
            memory: 26,
            network:100

        }, {
            period: 'Login',
              battery: 210,
            cpu: 40,
            memory: 30,
            network:90
        }, {
            period: 'Search',
             battery: 220,
            cpu: 50,
            memory: 26,
            network:100
        }, {
            period: 'Buy',
              battery: 230,
            cpu: 60,
            memory: 15,
            network:100
        }, {
            period: 'Cart',
              battery: 190,
            cpu: 75,
            memory: 16,
            network:60
        }, {
            period: 'Report',
             battery: 300,
            cpu: 8,
            memory: 121,
            network:50
    
}]*/