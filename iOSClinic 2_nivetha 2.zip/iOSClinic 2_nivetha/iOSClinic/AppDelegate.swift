//
//  AppDelegate.swift
//  iOSClinic
//
//  Created by Immanuel Thomas on 13/03/18.
//  Copyright © 2018 Immanuel Thomas. All rights reserved.
//

import UIKit
import AVFoundation
import UserNotifications
import Foundation

import Darwin


@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
    var mainViewController = ViewController()
    var metricsCollector = MetricsCollector()
    var metricscollectoroverall = MetricsCollector() /* separate thread for overall*/
    var backgroundTask = BackgroundTask()
    func getNotificationsettings(){
        UNUserNotificationCenter.current().getNotificationSettings{
            (settings) in
            print("Notification Settings:\(settings)");
           // guard settings.authorizationStatus == .authorised else { return }
            //UIApplication.registerForRemoteNotifications()
        }
    }
    
    func registerForPushNotifications(){
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert,.sound,.badge]){
            (granted,error) in
            print("permission granted: \(granted)")
            guard granted else { return }
            self.getNotificationsettings()
        }
    }
    //Entry Point
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        do{
            
            backgroundTask.startBackgroundTask();
            registerForPushNotifications();
            application.registerForRemoteNotifications()
            try AVAudioSession.sharedInstance().setCategory(AVAudioSessionCategoryPlayback,with:.mixWithOthers);
            print("playback ok");
            try AVAudioSession.sharedInstance().setActive(true);
            print("Session is active");
        }
        catch{
            print(error);
        }
        
        print("UIDevice Version :\(UIDevice.version())");
        print("UIDevice batteryLevel :\(UIDevice.current.batteryLevel)");
        print("UIDevice systemName :\(UIDevice.current.systemName)");
        print("UIDevice systemVersion :\(UIDevice.current.systemVersion)");
        print("UIDevice batteryState :\(UIDevice.current.batteryState.rawValue)");
        print("UIDevice name :\(UIDevice.current.name)");
        print("UIDevice model :\(UIDevice.current.model)");
        print("UIDevice orientation :\(UIDevice.current.orientation.rawValue)");
        debugPrint("testworkinglog");
        
        //future log files
        var paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let documentsDirectory = paths[0]
        let fileName = "\(Date()).log"
        let logFilePath = (documentsDirectory as NSString).appendingPathComponent(fileName)
        freopen(logFilePath.cString(using: String.Encoding.ascii)!, "a+", stderr)
        
        return true
    }
    
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        
       
        let tokenParts = deviceToken.map {
            data -> String in
            return String(format: "%02.2hhx",data);
        }
        let token = tokenParts.joined();
    var tokendel:Data?=nil;
         var finalJsonResult=[String : Any] ();
        finalJsonResult["DeviceToken"]=token;
        do{
            let finalResult = try JSONSerialization.data(withJSONObject: finalJsonResult, options: JSONSerialization.WritingOptions.prettyPrinted);
            //print(finalResult);
            tokendel=finalResult;
           
        }
        catch{
            
        }
        //tokendel=finalResult;
      // tokendel=finalJsonResult;
        print("DEVICE TOKEN = \(token)")
        
        let endpoint = "http://192.168.43.223:8089/entry-point/devicetokentest";
        
        guard let endpointUrl = URL(string: endpoint) else {
            return ();
        }
          print("Kalpanadevi = \(token)")
        var request = URLRequest(url: endpointUrl)
        request.httpMethod = "POST"
        request.httpBody=tokendel
        //request.addValue("token=\(token)", forHTTPHeaderField: "Authorization")
       // request.httpBody=tokendel;
       // request.addValue("application/json", forHTTPHeaderField: "Content-Type")
       // request.addValue("application/json", forHTTPHeaderField: "Accept")
        
        let sessionConfig = URLSessionConfiguration.default
        var proxyDict = [AnyHashable : Any]()
        proxyDict[kCFStreamPropertyProxyLocalBypass as String] = "192.168.43.223"
        sessionConfig.connectionProxyDictionary = proxyDict
        let session = URLSession.init(configuration: sessionConfig, delegate: nil, delegateQueue: OperationQueue.current)
        let task = session.dataTask(with: request);
        task.resume()
        
        
    }
    func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error) {
        print("Error:");
        print(error);
    }
    func application(_ application: UIApplication, didReceiveRemoteNotification userInfo: [AnyHashable : Any]) {
        
        print("userinfo :\(String(describing:userInfo))");
        let aps: [AnyHashable: Any] = userInfo["aps"] as! [AnyHashable : Any];
        let s = String(describing: aps[AnyHashable("alert")]!);
      
        
        
        let srnumber = String(describing: userInfo[AnyHashable("srNumber")]!);
         let usecasename = String(describing: userInfo[AnyHashable("usecase")]!);
        var pagename : String = "";
        if userInfo["pagename"] != nil
        {
         pagename = String(describing: userInfo[AnyHashable("pagename")]!);
        }
         print("pagename:\(String(describing: pagename))");
        print("srnumber : \(srnumber)");
         print("usecasename : \(usecasename)");
        if( s == "start"){
           
            metricsCollector.startPerformanceHandler(usecaseName: usecasename , srNumber: srnumber, pagename: pagename);
        }
        if(s == "stop"){
           
            metricsCollector.stopPerformanceHandler();
        }
        
        if( s == "startoverall"){
            
         //   metricsCollector.startStop = true;
         //   metricsCollector.startOverallPerformanceHandler(usecaseName: usecasename , srNumber: srnumber, pagename: pagename);
             metricscollectoroverall.startStop = true;
             metricscollectoroverall.startOverallPerformanceHandler(usecaseName: usecasename , srNumber: srnumber, pagename: pagename);
            
        }
        if(s == "stopoverall"){
            metricscollectoroverall.startStop = false;
            //metricsCollector.stopOverallPerformanceHandler();
            
        }
        print(s+":test");
        print("hellow world");
        
      
        
      
    }
    func applicationWillTerminate(_ application: UIApplication) {
     
        if let vc = window?.rootViewController as? ViewController{
            vc.stopWhenTerminate();
            
        }
        //backgroundTask.stopBackgroundTask();
           print("app terminated");
    }
    func applicationWillEnterForeground(_ application: UIApplication) {
        print("enter foreground");
    }
    func applicationDidEnterBackground(_ application: UIApplication) {
        print("enter background");
    }
 


}

