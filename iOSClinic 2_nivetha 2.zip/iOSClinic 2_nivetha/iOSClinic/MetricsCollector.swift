//
//  MetricsCollector.swift
//  iOSClinic
//
//  Created by Immanuel Thomas on 26/04/18.
//  Copyright © 2018 Immanuel Thomas. All rights reserved.
//

import Foundation
import UIKit



class MetricsCollector{
    //var backgroundTask = BackgroundTask()
    var backgroundTimer:Timer!;
    var backgroundPusher:Timer!;
    //cpu,memory storage dictionary and counter for each second detail
    var cpuDict: [String : Any ]? = [String :Any]();
    var memoryUsedDict : [String :Any]? = [String :Any]();
    var memoryFreeDict : [String :Any]? = [String :Any]();
    var memoryCompressedDict : [String :Any]? = [String :Any]();
    var counter=0;
    var cpucounter=0;
    var useCase: String?
    var srno:String?
    var pagename:String?
    var sumCpu:Double = 0;
    var sumMemoryUsed:Double = 0;
    var sumMemoryFree:Double = 0;
    var sumMemoryCompressed:Double = 0;
    var maxCpu:Double = 0;
    var maxMemoryUsed:Double = 0;
    var maxMemoryFree:Double = 0;
    var maxMemoryCompressed:Double = 0;
    var startTime : Double = 0;
    var endTime :Double = 0;
    var startStop :Bool = true;
    var systemCPULatest :Double=0;
    @objc private func timerHandler() {
        
        
        print("Time Remaining In Background : \(UIApplication.shared.backgroundTimeRemaining)");
        
        print("Application CPU: \(System.cpu.applicationUsage())");
        
        let cpuSystemUsage = System.cpu.systemUsage()
        if !(cpuSystemUsage.system + cpuSystemUsage.user + cpuSystemUsage.nice).isNaN
        {
         systemCPULatest = cpuSystemUsage.system + cpuSystemUsage.user + cpuSystemUsage.nice;
        }
        print("System CPU: \(cpuSystemUsage.system + cpuSystemUsage.user + cpuSystemUsage.nice)");
        
        print("Application Memory: \(System.memory.applicationUsage().used)");
        
        let ramSysUsage = System.memory.systemUsage()
        
        print("System Memory: \(ramSysUsage)");
        
        let percent = (ramSysUsage.active + ramSysUsage.inactive + ramSysUsage.wired) / ramSysUsage.total

        print("Used System Memory:\(ramSysUsage.active + ramSysUsage.inactive + ramSysUsage.wired)");
        print("Percent Of System Memory:\(percent * 100.0)")
        self.counter+=1;
        if !systemCPULatest.isNaN
        {
        print("Testing cpu data:\(systemCPULatest)")
        sumCpu += systemCPULatest;
        self.cpucounter+=1;
        }
        sumMemoryFree += (ramSysUsage.free)/(1024*1024);
        sumMemoryUsed += (ramSysUsage.active + ramSysUsage.inactive + ramSysUsage.wired)/(1024*1024);
        sumMemoryCompressed += (ramSysUsage.compressed)/(1024*1024);
        
        
        if systemCPULatest > maxCpu {
            maxCpu = systemCPULatest
        }
        
        if ((ramSysUsage.free)/(1024*1024)) > maxMemoryFree {
            maxMemoryFree = (ramSysUsage.free)/(1024*1024) ;
        }
        
        if ((ramSysUsage.active + ramSysUsage.inactive + ramSysUsage.wired)/(1024*1024)) > maxMemoryUsed {
            maxMemoryUsed = ((ramSysUsage.active + ramSysUsage.inactive + ramSysUsage.wired)/(1024*1024))
        }
        
        if ((ramSysUsage.compressed)/(1024*1024)) > maxMemoryCompressed {
            
            maxMemoryCompressed = ((ramSysUsage.compressed)/(1024*1024))
        }
        
        self.cpuDict?["\(counter)s"] = systemCPULatest;
        self.memoryUsedDict?["\(counter)s"]=(ramSysUsage.active + ramSysUsage.inactive + ramSysUsage.wired)/(1024*1024);
        self.memoryFreeDict?["\(counter)s"]=(ramSysUsage.free)/(1024*1024);
        self.memoryCompressedDict?["\(counter)s"]=(ramSysUsage.compressed)/(1024*1024);
        
        
        print("CPU DICT: \(String(describing: cpuDict)) ** Memory USED DICT: \(String(describing: memoryUsedDict)) ** Memory Free DICT: \(String(describing: memoryFreeDict)) **  Memory Compressed DICT: \(String(describing: memoryCompressedDict)) ** ");
          var finalJsonResult=[String : Any] ();
        if (useCase != nil) && (useCase != "") {
            finalJsonResult["UsecaseName"]=useCase;
        }
        
        if(srno != nil && srno != ""){
            finalJsonResult["srNumber"]=srno;
        }
        
        if(pagename != nil && pagename != ""){
            finalJsonResult["pagename"]=pagename;
        }
        finalJsonResult["CPU"]=cpuDict;
        finalJsonResult["MemoryUsed"]=memoryUsedDict;
        finalJsonResult["MemoryFree"]=memoryFreeDict;
        finalJsonResult["MemoryCompressed"]=memoryCompressedDict;
        finalJsonResult["averagecpu"] = sumCpu / Double (counter) ;
        finalJsonResult["averagememoryfree"] = sumMemoryFree / Double (counter) ;
        finalJsonResult["averagememorycompressed"] = sumMemoryCompressed / Double (counter);
        finalJsonResult["averagememoryused"] = sumMemoryUsed / Double (counter) ;
        finalJsonResult["maxmemoryfree"] = maxMemoryFree;
        finalJsonResult["maxmemorycompressed"] = maxMemoryCompressed;
        finalJsonResult["maxmemoryused"] = maxMemoryUsed
        finalJsonResult["maxcpu"] = maxCpu;
        finalJsonResult["totalduration"]=endTime.rounded() - startTime.rounded();
        print("finished generating dictinary \(finalJsonResult)");
        var finalJSONResultUpdated:Data?=nil;
        if JSONSerialization.isValidJSONObject(finalJsonResult){
            print("-------final JSon--------")
            do{
                let finalResult = try JSONSerialization.data(withJSONObject: finalJsonResult, options: JSONSerialization.WritingOptions.prettyPrinted);
                //print(finalResult);
                finalJSONResultUpdated=finalResult;
                let finalJSONResult = try JSONSerialization.jsonObject(with: finalResult, options:[])
                print(finalJSONResult);
            }
            catch{
                
            }
        }
        
        let endpoint = "http://192.168.43.223:8089/entry-point/json";
        
        guard let endpointUrl = URL(string: endpoint) else {
            return ();
        }
        
        var request = URLRequest(url: endpointUrl)
        
        request.httpMethod = "POST"
        request.httpBody = finalJSONResultUpdated;
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        
        
        let sessionConfig = URLSessionConfiguration.default
        var proxyDict = [AnyHashable : Any]()
        proxyDict[kCFStreamPropertyProxyLocalBypass as String] = "192.168.43.223"
        sessionConfig.connectionProxyDictionary = proxyDict
        let session = URLSession.init(configuration: sessionConfig, delegate: nil, delegateQueue: OperationQueue.current)
        let task = session.dataTask(with: request);
        task.resume()
        
        
    }
    
    @objc private func backgroundPush() {
        
        
        var finalJsonResult=[String : Any] ();
        
        if (useCase != nil) && (useCase != "") {
            finalJsonResult["UsecaseName"]=useCase;
        }
        if(srno != nil && srno != ""){
            finalJsonResult["srNumber"]=srno;
        }
        let seconds: TimeInterval = NSDate().timeIntervalSince1970
        endTime =  seconds*1000;
        print("stop time : \(endTime.rounded())");
        finalJsonResult["CPU"]=cpuDict!;
        finalJsonResult["MemoryUsed"]=memoryUsedDict;
        finalJsonResult["MemoryFree"]=memoryFreeDict;
        finalJsonResult["MemoryCompressed"]=memoryCompressedDict;
        finalJsonResult["averagecpu"] = sumCpu / Double (cpucounter) ;
        finalJsonResult["averagememoryfree"] = sumMemoryFree / Double (counter) ;
        finalJsonResult["averagememorycompressed"] = sumMemoryCompressed / Double (counter);
        finalJsonResult["averagememoryused"] = sumMemoryUsed / Double (counter) ;
        finalJsonResult["maxmemoryfree"] = maxMemoryFree;
        finalJsonResult["maxmemorycompressed"] = maxMemoryCompressed;
        finalJsonResult["maxmemoryused"] = maxMemoryUsed
        finalJsonResult["maxcpu"] = maxCpu;
        finalJsonResult["totalduration"]=endTime.rounded() - startTime.rounded();
        
        
        
        
        
        var finalJSONResultUpdated:Data?=nil;
        if JSONSerialization.isValidJSONObject(finalJsonResult){
            print("-------final JSon--------")
            do{
                let finalResult = try JSONSerialization.data(withJSONObject: finalJsonResult, options: JSONSerialization.WritingOptions.prettyPrinted);
                //print(finalResult);
                finalJSONResultUpdated=finalResult;
                let finalJSONResult = try JSONSerialization.jsonObject(with: finalResult, options:[])
                print(finalJSONResult);
            }
            catch{
                
            }
        }
        
        let endpoint = "http://192.168.43.223:8089/entry-point/json";
        
        guard let endpointUrl = URL(string: endpoint) else {
            return ();
        }
        
        var request = URLRequest(url: endpointUrl)
        
        request.httpMethod = "POST"
        request.httpBody = finalJSONResultUpdated;
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        
        
        let sessionConfig = URLSessionConfiguration.default
        var proxyDict = [AnyHashable : Any]()
        proxyDict[kCFStreamPropertyProxyLocalBypass as String] = "192.168.43.223"
        sessionConfig.connectionProxyDictionary = proxyDict
        let session = URLSession.init(configuration: sessionConfig, delegate: nil, delegateQueue: OperationQueue.current)
        let task = session.dataTask(with: request);
        task.resume()
    }
    
    func startOverallPerformanceHandler(usecaseName: String, srNumber :String, pagename :String)
    {
        
        let seconds: TimeInterval = NSDate().timeIntervalSince1970
        startTime =  seconds*1000;
        print("start time : \(startTime.rounded())");
        print("UsecaseName************ : \(usecaseName)");
        print("SrNo************ : \(srNumber)");
        print("PageName************ : \(pagename)");
        counter=0;
        sumCpu = 0;
        sumMemoryUsed = 0;
        sumMemoryFree = 0;
        sumMemoryCompressed = 0;
        
        maxCpu = 0;
        maxMemoryUsed = 0;
        maxMemoryFree = 0;
        maxMemoryCompressed = 0;
        cpuDict = [String : Any ] ();
        memoryUsedDict =  [String : Any ] ();
        memoryCompressedDict = [String : Any ] ();
        memoryFreeDict = [String : Any ] ();
        useCase=usecaseName;
        srno=srNumber;
        self.pagename=pagename;
        let metricsCollector = MetricsCollector();
        DispatchQueue.global(qos: .background).async {
            while self.startStop{
                DispatchQueue.main.async {
                    metricsCollector.timerHandler();
                    
                }
                
                //usleep(useconds_t(1e+6) / 30);    // sleep in milliseconds 30 fps
                sleep(1);
            }
            if(self.startStop==false){
                
                metricsCollector.stopOverallPerformanceHandler(usecaseName: usecaseName , srNumber: srNumber, pagename: pagename);
                //metricsCollector.backgroundPush();
            }
        }
        
    }
    
    func stopOverallPerformanceHandler(usecaseName: String, srNumber :String, pagename :String){
        let seconds: TimeInterval = NSDate().timeIntervalSince1970
        endTime =  seconds*1000;
        print("stop time : \(endTime.rounded())");
        print("entered stoping");
        
        
        // backgroundTask.stopBackgroundTask()
        
       print("pagename*****:\(String(describing: pagename))");
        print("UsecaseName*****:\(String(describing: usecaseName))");
        print("SrNo*****:\(String(describing: srNumber))");
        
        var finalJsonResult=[String : Any] ();
        
        if (usecaseName != nil) && (usecaseName != "") {
            finalJsonResult["UsecaseName"]=usecaseName;
        }
        
        if(srNumber != nil && srNumber != ""){
            finalJsonResult["srNumber"]=srNumber;
        }
        
        if(pagename != nil && pagename != ""){
            finalJsonResult["pagename"]=pagename;
        }
        
        print("test cpuhash : \(String(describing: cpuDict)) : \(counter)");
        finalJsonResult["CPU"]=cpuDict;
        finalJsonResult["MemoryUsed"]=memoryUsedDict;
        finalJsonResult["MemoryFree"]=memoryFreeDict;
        finalJsonResult["MemoryCompressed"]=memoryCompressedDict;
        finalJsonResult["averagecpu"] = sumCpu / Double (counter) ;
        finalJsonResult["averagememoryfree"] = sumMemoryFree / Double (counter) ;
        finalJsonResult["averagememorycompressed"] = sumMemoryCompressed / Double (counter);
        finalJsonResult["averagememoryused"] = sumMemoryUsed / Double (counter) ;
        finalJsonResult["maxmemoryfree"] = maxMemoryFree;
        finalJsonResult["maxmemorycompressed"] = maxMemoryCompressed;
        finalJsonResult["maxmemoryused"] = maxMemoryUsed
        finalJsonResult["maxcpu"] = maxCpu;
        finalJsonResult["totalduration"]=endTime.rounded() - startTime.rounded();
        print("finished generating dictinary \(finalJsonResult)");
        var finalJSONResultUpdated:Data?=nil;
        print("valid object : \(JSONSerialization.isValidJSONObject(finalJsonResult))")
        
        if JSONSerialization.isValidJSONObject(finalJsonResult){
            print("-------final JSon--------")
            do{
                let finalResult = try JSONSerialization.data(withJSONObject: finalJsonResult, options: JSONSerialization.WritingOptions.prettyPrinted);
                //print(finalResult);
                finalJSONResultUpdated=finalResult;
                let finalJSONResult = try JSONSerialization.jsonObject(with: finalResult, options:[])
                print(finalJSONResult);
            }
            catch{
                print("error");
            }
        }
        
        let endpoint = "http://192.168.43.223:8089/entry-point/json";
        
        guard let endpointUrl = URL(string: endpoint) else {
            return ();
        }
        
        var request = URLRequest(url: endpointUrl)
        request.httpMethod = "POST"
        request.httpBody = finalJSONResultUpdated;
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        
        let sessionConfig = URLSessionConfiguration.default
        var proxyDict = [AnyHashable : Any]()
        proxyDict[kCFStreamPropertyProxyLocalBypass as String] = "192.168.43.223"
        sessionConfig.connectionProxyDictionary = proxyDict
        let session = URLSession.init(configuration: sessionConfig, delegate: nil, delegateQueue: OperationQueue.current)
        let task = session.dataTask(with: request);
        task.resume()
        counter=0;
        sumCpu = 0;
        sumMemoryUsed = 0;
        sumMemoryFree = 0;
        sumMemoryCompressed = 0;
        
        maxCpu = 0;
        maxMemoryUsed = 0;
        maxMemoryFree = 0;
        maxMemoryCompressed = 0;
    }
    
   
    func startPerformanceHandler(usecaseName: String, srNumber :String , pagename:String){
        //        var millisecondsSince1970:Int = Int((NSTimeIntervalSince1970 * 1000.0).rounded())
        //        print("start smilliseconds \(millisecondsSince1970)");
       // backgroundTask.startBackgroundTask()
        let seconds: TimeInterval = NSDate().timeIntervalSince1970
        startTime =  seconds*1000;
        print("start time : \(startTime.rounded())");
        
        counter=0;
        sumCpu = 0;
        sumMemoryUsed = 0;
        sumMemoryFree = 0;
        sumMemoryCompressed = 0;
        
        maxCpu = 0;
        maxMemoryUsed = 0;
        maxMemoryFree = 0;
        maxMemoryCompressed = 0;
        cpuDict = [String : Any ] ();
        memoryUsedDict =  [String : Any ] ();
        memoryCompressedDict = [String : Any ] ();
        memoryFreeDict = [String : Any ] ();
        useCase=usecaseName;
        srno=srNumber;
         self.pagename=pagename;
        let metricsCollector = MetricsCollector();
        self.backgroundTimer=Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(metricsCollector.timerHandler), userInfo: nil, repeats: true);
        //self.backgroundPusher=Timer.scheduledTimer(timeInterval: 10, target: self, selector: #selector(metricsCollector.backgroundPush), userInfo: nil, repeats: true);
    }
    
    func stopPerformanceHandler()
    {
        if backgroundTimer != nil
        {
            let seconds: TimeInterval = NSDate().timeIntervalSince1970
            endTime =  seconds*1000;
            print("stop time : \(endTime.rounded())");
            print("entered stoping");
            backgroundTimer.invalidate();
            //backgroundPusher.invalidate();
            
           // backgroundTask.stopBackgroundTask()
            
            print("pagename:\(String(describing: pagename))");
            
            var finalJsonResult=[String : Any] ();
            
            if (useCase != nil) && (useCase != "") {
                finalJsonResult["UsecaseName"]=useCase;
            }
            
            if(srno != nil && srno != ""){
                finalJsonResult["srNumber"]=srno;
            }
            if(pagename != nil && pagename != ""){
                finalJsonResult["pagename"]=pagename;
            }
            
            finalJsonResult["CPU"]=cpuDict;
            finalJsonResult["MemoryUsed"]=memoryUsedDict;
            finalJsonResult["MemoryFree"]=memoryFreeDict;
            finalJsonResult["MemoryCompressed"]=memoryCompressedDict;
            finalJsonResult["averagecpu"] = sumCpu / Double (counter) ;
            finalJsonResult["averagememoryfree"] = sumMemoryFree / Double (counter) ;
            finalJsonResult["averagememorycompressed"] = sumMemoryCompressed / Double (counter);
            finalJsonResult["averagememoryused"] = sumMemoryUsed / Double (counter) ;
            finalJsonResult["maxmemoryfree"] = maxMemoryFree;
            finalJsonResult["maxmemorycompressed"] = maxMemoryCompressed;
            finalJsonResult["maxmemoryused"] = maxMemoryUsed
            finalJsonResult["maxcpu"] = maxCpu;
            finalJsonResult["totalduration"]=endTime.rounded() - startTime.rounded();
            print("finished generating dictinary \(finalJsonResult)");
            var finalJSONResultUpdated:Data?=nil;
          //  var finalJsonResulttest=[String : Any] ();
          //  finalJsonResulttest["Testingdata"]="Testingdata";
            print("valid object : \(JSONSerialization.isValidJSONObject(finalJsonResult))")
            
          if JSONSerialization.isValidJSONObject(finalJsonResult){
                print("-------final JSon--------")
                do{
                    let finalResult = try JSONSerialization.data(withJSONObject: finalJsonResult, options: JSONSerialization.WritingOptions.prettyPrinted);
                    //print(finalResult);
                    finalJSONResultUpdated=finalResult;
                    let finalJSONResult = try JSONSerialization.jsonObject(with: finalResult, options:[])
                    print(finalJSONResult);
                }
                catch{
                    print("error");
                }
            }
            //kalpanachanges
          /*  do{
                let finalResulttest = try JSONSerialization.data(withJSONObject: finalJsonResulttest, options: JSONSerialization.WritingOptions.prettyPrinted);
                //print(finalResult);
                finalJSONResultUpdated=finalResulttest;
               
            }
            catch{
                print("error");
            }*/
            //end
            let endpoint = "http://192.168.43.223:8089/entry-point/json";
            
            guard let endpointUrl = URL(string: endpoint) else {
                return ();
            }
            
            var request = URLRequest(url: endpointUrl)
            request.httpMethod = "POST"
            request.httpBody = finalJSONResultUpdated;
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.addValue("application/json", forHTTPHeaderField: "Accept")
            
            let sessionConfig = URLSessionConfiguration.default
            var proxyDict = [AnyHashable : Any]()
            proxyDict[kCFStreamPropertyProxyLocalBypass as String] = "192.168.43.223"
            sessionConfig.connectionProxyDictionary = proxyDict
            let session = URLSession.init(configuration: sessionConfig, delegate: nil, delegateQueue: OperationQueue.current)
            let task = session.dataTask(with: request);
            task.resume()
            counter=0;
            sumCpu = 0;
            sumMemoryUsed = 0;
            sumMemoryFree = 0;
            sumMemoryCompressed = 0;
            
            maxCpu = 0;
            maxMemoryUsed = 0;
            maxMemoryFree = 0;
            maxMemoryCompressed = 0;
        }
        
    }
    
    
    
}
