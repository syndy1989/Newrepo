Extract the folder

Please open index.html through firefox