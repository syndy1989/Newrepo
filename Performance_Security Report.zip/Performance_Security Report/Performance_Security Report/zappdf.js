$.getJSON("zap.json", function(json) {
            var hits=json.securitydetails;
            //alert(JSON.stringify(hits));
           //alert(hits);
var High,Medium,Low,info;
           for(var i=0;i<json.securitydetails.length;i++){

             High =json.securitydetails[i].High;
             Medium=json.securitydetails[i].Medium;
             Low=json.securitydetails[i].Low;
             info=json.securitydetails[i].info;
           }
 
  var data = [
      { y: 'High', a:High},
      { y: 'Medium', b: Medium},
      { y: 'Low',   c: Low},
      { y: 'Info',  d: info}
    ],
    config = {
      data: data,
      xkey: 'y',
      ykeys: ['a','b','c','d'],
      labels: ['High', 'Medium','Low','Info'],
      fillOpacity: 0.6,
      hideHover: true,
      barSize: 90,
      stacked:'true',
      resize: true,
     barColors: ['#ff6600','#04d215','#ff0f00','#67b7dc']
  };


config.element = 'zapchart';
Morris.Bar(config);
 
});
         


$.getJSON("zapraw.json", function(json) {

  var hits=json.instances;

  var instance,method,url,params,solution,alert1,riskdes,descr,otherinfo;
  
for(var i=0; i< hits.length;i++)

{

instance=hits[i].Instances;
method=hits[i].Method;
url=hits[i].URL;
params=hits[i].Parameter;
solution=hits[i].Solution;
alert1=hits[i].alert;
riskdes=hits[i].riskdesc;
descr=hits[i].Description;
otherinfo=hits[i].OtherInformation;




                    if(riskdes.includes("High")){
            riskdes="High";
          }
          else if(riskdes.includes("Medium (Medium)")){
            riskdes="Medium";
          }
          else if(riskdes.includes("Low (Medium)")){
            riskdes="Low";
          }


                    var tablerow0=document.createElement('tr');
                
                    var tablecolum1=document.createElement('th');
                    var tablecolum2=document.createElement('th');

                    tablecolum1.innerHTML=riskdes.bold();
                     tablecolum2.innerHTML=(alert1).bold();

                      tablerow0.appendChild(tablecolum1);
                    tablerow0.appendChild(tablecolum2);



                    var tablerow1=document.createElement('tr');
                
                    var tablecolum3=document.createElement('td');
                    var tablecolum4=document.createElement('td');

                    tablecolum3.innerHTML="Description";
                     tablecolum4.innerHTML=descr;

                      tablerow1.appendChild(tablecolum3);
                    tablerow1.appendChild(tablecolum4);

                  



                    var tablerow2=document.createElement('tr');
                
                    var tablecolum5=document.createElement('td');
                    var tablecolum6=document.createElement('td');

                    tablecolum5.innerHTML="URL";
                    tablecolum6.innerHTML=url;

                      tablerow2.appendChild(tablecolum5);
                    tablerow2.appendChild(tablecolum6);



                    var tablerow3=document.createElement('tr');
                
                    var tablecolum7=document.createElement('td');
                    var tablecolum8=document.createElement('td');

                    tablecolum7.innerHTML="Method";
                     tablecolum8.innerText=method;

                      tablerow3.appendChild(tablecolum7);
                    tablerow3.appendChild(tablecolum8);




                    var tablerow4=document.createElement('tr');
                
                    var tablecolum9=document.createElement('td');
                    var tablecolum10=document.createElement('td');

                    tablecolum9.innerHTML="Parameter";
                     tablecolum10.innerText=params;

                      tablerow4.appendChild(tablecolum9);
                    tablerow4.appendChild(tablecolum10);




                    var tablerow5=document.createElement('tr');
                
                    var tablecolum11=document.createElement('td');
                    var tablecolum12=document.createElement('td');

                    tablecolum11.innerHTML="Instances";
                     tablecolum12.innerText=instance;

                      tablerow5.appendChild(tablecolum11);
                    tablerow5.appendChild(tablecolum12);



                    var tablerow6=document.createElement('tr');
                
                    var tablecolum13=document.createElement('td');
                    var tablecolum14=document.createElement('td');

                    tablecolum13.innerHTML="Solution";
                     tablecolum14.innerHTML=solution;

                      tablerow6.appendChild(tablecolum13);
                    tablerow6.appendChild(tablecolum14);


                    var tablerow7=document.createElement('tr');
                
                    var tablecolum15=document.createElement('td');
                    var tablecolum16=document.createElement('td');

                    tablecolum15.innerHTML="OtherInformation";
                     tablecolum16.innerHTML=otherinfo;

                      tablerow7.appendChild(tablecolum15);
                    tablerow7.appendChild(tablecolum16);

                    var tablerow8=document.createElement('tr');
                
                    var tablecolum15=document.createElement('td');
                    var tablecolum16=document.createElement('td');

                    tablecolum15.innerHTML="</br>";
                     tablecolum16.innerHTML="</br>";

                      tablerow8.appendChild(tablecolum15);
                    tablerow8.appendChild(tablecolum16);




                  



}





 });


$.getJSON("zapraw.json", function(json) {

  //var hits=json.instances;

   var instances=json.instances;

  var instance,method,url,params,solution,alert1,riskdes,descr,otherinfo;
/*var high=document.createElement('h3');
                            high.setAttribute("style","color:#3c9adc");
                            high.innerHTML="High";

 var medium=document.createElement('h3');
                            medium.setAttribute("style","color:#3c9adc");
                            medium.innerHTML="Medium";
                            

                             var low=document.createElement('h3');
                            low.setAttribute("style","color:#3c9adc");
                            low.innerHTML="Low";


                             var info=document.createElement('h3');
                            info.setAttribute("style","color:#3c9adc");

                           


                            



                            

                             var ul4=document.createElement('ul');
                            ul4.setAttribute("style","font-weight:0;line-height:0,letter-spacing: 0;font-family:Arial");
                            /*ul4.innerHTML="Medium";
                            var li14=document.createElement('li'); 
                            li14.setAttribute("style","color:#808080");
                             var li24=document.createElement('li'); 
                            li24.setAttribute("style","color:#808080");*/



                            var tablerow1=document.createElement('tr');
                
                    var tablecolum1=document.createElement('td');
                    var tablecolum2=document.createElement('td');
                    var tablecolum3=document.createElement('td');
                    tablecolum1.setAttribute("style","font-weight: bold;color:#3c9adc");
                    tablecolum1.innerHTML="Vulnerability Severity";
                    tablecolum2.setAttribute("style","font-weight: bold;color:#3c9adc");
                     tablecolum2.innerHTML="Issue";
                      tablecolum3.setAttribute("style","font-weight: bold;color:#3c9adc;");
                      tablecolum3.innerHTML="No of Occurances";

                      tablerow1.appendChild(tablecolum1);
                    tablerow1.appendChild(tablecolum2);
                  /*  tablerow1.appendChild(tablecolum3);*/

                     document.getElementById("zapalert").appendChild(tablerow1);  
                            
    const hits = instances.reduce((acc, curr) =>  (acc.some((i) => i.alert === curr.alert)) ? acc : acc.concat([curr]), [])
                            
                              


for(var i=0; i< hits.length;i++)

{

instance=hits[i].Instances;
method=hits[i].Method;
url=hits[i].URL;
params=hits[i].Parameter;
solution=hits[i].Solution;
alert1=hits[i].alert;
riskdes=hits[i].riskdesc;
descr=hits[i].Description;
otherinfo=hits[i].OtherInformation;


if(riskdes.includes("High")){
            riskdes="High";

            if(riskdes!=null)
            {


 /*var ul=document.createElement('ul');
 
                            ul.setAttribute("style","font-weight:0;line-height:0,letter-spacing: 0;font-family:Arial");
                            
                            var li1=document.createElement('li'); 
                            li1.setAttribute("style","color:#808080");

                  

                            var ulurl=document.createElement('ul');
                             ulurl.setAttribute("style","color:#3c9adc");  
                            ulurl.innerHTML="Url&nbsp; :&nbsp;";

                             var li2=document.createElement('li'); 
                            li2.setAttribute("style","color:#808080;margin-left: 46px;list-style-type: circle;");

              li1.innerHTML=alert1;
              li2.innerHTML=url;

            
              
                   ul.appendChild(li1); 
                  
                  ulurl.appendChild(li2);  
                

                    high.appendChild(ul);
                    high.appendChild(ulurl);*/


                  var high=document.createElement('tr');
                
                    var tablecolum4=document.createElement('td');
                    var tablecolum5=document.createElement('td');
                    var tablecolum6=document.createElement('td');

                    tablecolum4.innerHTML=alert1;
            
                     tablecolum5.innerText=riskdes;
                    tablecolum6.innerHTML="NA";

                      high.appendChild(tablecolum4);
                    high.appendChild(tablecolum5);
                    /*high.appendChild(tablecolum6);*/

                  document.getElementById("zapalert").appendChild(high); 
                 

                  
          }
        }
          else if(riskdes.includes("Medium (Medium)")){
            riskdes="Medium";

            if(riskdes!=null)
            {

             /*ar ulurl=document.createElement('ul');
              ulurl.setAttribute("style","color:#3c9adc");  
                            ulurl.innerHTML="Url &nbsp; :&nbsp;";


                             var ul2=document.createElement('ul');
                            ul2.setAttribute("style","font-weight:0;line-height:0,letter-spacing: 0;font-family:Arial");
                            ul2.innerHTML="Medium";
                            var li12=document.createElement('li'); 
                            li12.setAttribute("style","color:#808080");
                             var li22=document.createElement('li'); 
                            li22.setAttribute("style","color:#808080;margin-left: 46px;list-style-type: circle;");

              li12.innerHTML=alert1;
              li22.innerHTML=url;
              ul2.appendChild(li12);
 ulurl.appendChild(li22);  
              
              medium.appendChild(ul2);
                medium.appendChild(ulurl);
*/
            
var medium=document.createElement('tr');
                    
                
                    var tablecolum7=document.createElement('td');
                    var tablecolum8=document.createElement('td');
                    var tablecolum9=document.createElement('td');

                    tablecolum7.innerHTML=alert1;
            
                     tablecolum8.innerText=riskdes;
                    tablecolum9.innerHTML="NA";

                      medium.appendChild(tablecolum7);
                    medium.appendChild(tablecolum8);
                   /* medium.appendChild(tablecolum9);*/

                 
                 
document.getElementById("zapalert").appendChild(medium); 


 
                    
                   
          }
        }
          else if(riskdes.includes("Low (Medium)")){
            riskdes="Low";

            if(riskdes!=null)
            {
               /*var ulurl=document.createElement('ul');
                             ulurl.setAttribute("style","color:#3c9adc");  
                            ulurl.innerHTML="Url&nbsp; :&nbsp;";

               var ul3=document.createElement('ul');
                            ul3.setAttribute("style","font-weight:0;line-height:0,letter-spacing: 0;font-family:Arial");
                            
                            var li13=document.createElement('li'); 
                            li13.setAttribute("style","color:#808080");
                             var li23=document.createElement('li'); 
                            li23.setAttribute("style","color:#808080;margin-left: 46px;list-style-type: circle;");


           
            li13.innerHTML=alert1;
              li23.innerHTML=url;
              ul3.appendChild(li13);

              ulurl.appendChild(li23);
              low.appendChild(ul3);
              low.appendChild(ulurl);*/
              var low=document.createElement('tr');

             var tablecolum10=document.createElement('td');
                    var tablecolum11=document.createElement('td');
                    var tablecolum12=document.createElement('td');
                
                   

                    tablecolum10.innerHTML=alert1;
            
                     tablecolum11.innerText=riskdes;
                    tablecolum12.innerHTML="NA";

                      low.appendChild(tablecolum10);
                    low.appendChild(tablecolum11);
                    /*low.appendChild(tablecolum12);*/


                    
                             document.getElementById("zapalert").appendChild(low);          


                    
          }

}


}
         

           




 });

