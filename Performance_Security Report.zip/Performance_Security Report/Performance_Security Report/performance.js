$.ajaxSetup({
    async: false
});  


 $.getJSON("log.json", function(json) {



var hits=json;
var image,css,other,xhr,nwbmp,runtype,pagesize,html,js,font,video,cachenwbmp,cachepagesize;

for(var i=0;i<hits.length;i++)
{

runtype=hits[i].runtype;

  if(runtype.includes("withoutcache"))
  {
    image=hits[i].image;
    css=hits[i].css;
    other=hits[i].other;
    xhr=hits[i].xhr;
    nwbmp=hits[i].nwrequest;
    pagesize=hits[i].pagesize;
    video=hits[i].video;
    html=hits[i].html;
    js=hits[i].javascript;
    font=hits[i].font;

  }


  else if(runtype.includes("withcache"))
  {
    
    cachenwbmp=hits[i].nwrequest;
    cachepagesize=hits[i].pagesize;
    
  }

}

s=(pagesize/(1024*1024)).toFixed(2);
 
s1=Math.round((cachepagesize/(1024*1024)).toFixed(6));

/*$("#nw").empty();  

          Morris.Bar({
            element: 'nw',
            data: [
                   { y: 'n/w Request', a: nwbmp, b: cachenwbmp }
                   ],
            xkey: 'y',
            ykeys: ['a', 'b'],
            labels: ['With Cache', 'Without Cache'],
            barColors: ["#FF6600", "#0D52D1"]
          });
*/



  /*$("#nw").empty();  

          Morris.Bar({
            element: 'nw',
            data: [
                   { y: 'Chrome Request', a: nwbmp, b: cachenwbmp}
                   ],
            xkey: 'y',
            ykeys: ['a', 'b'],
            labels: ['Without Cache', 'With Cache'],
            barColors: ["#FF6600", "#0D52D1"]
          });
*/

        if(nwbmp<50)
                {
                document.getElementById('launchpanel2').className+= 'panel panel-green';
                }
                else if((nwbmp>50)&&(nwbmp<=60))
                {
                document.getElementById('launchpanel2').className+= 'panel panel-yellow';
            }
                else if(nwbmp>60)
                {
                document.getElementById('launchpanel2').className+= 'panel panel-red';
                }
                document.getElementById("mwcall").innerHTML=nwbmp;



               if(s<=1.5)
                {
                document.getElementById('launchpanel1').className+= 'panel panel-green';
                }
                else if((s>1.5)&&(s<=2))
                {
                document.getElementById('launchpanel1').className+= 'panel panel-yellow';
                }
                else if(s>2)
                {
                document.getElementById('launchpanel1').className+= 'panel panel-red';
                }
                document.getElementById("pagesize").innerHTML=s+"MB";


var chart = AmCharts.makeChart( "chartdiv", {
  "type": "pie",
  "theme": "dark",
  "dataProvider": [ {
    "PageProfiling": "CSS",
    "Values": css
  }, {
    "PageProfiling": "Font",
    "Values": font
  }, {
    "PageProfiling": "HTML",
    "Values": html
  }, {
    "PageProfiling": "Images",
    "Values": image
  }, {
    "PageProfiling": "JS",
    "Values": js
  }, {
    "PageProfiling": "Video",
    "Values": video
  }, {
    "PageProfiling": "Other",
    "Values": other
  }, {
    "PageProfiling": "XHR",
    "Values": xhr
  } ],
  "valueField": "Values",
  "titleField": "PageProfiling",
   "balloon":{
   "fixedPosition":true
  },
  "export": {
   "enabled": true,
    "menu": []
  }
  
} );

mobilelog(s,s1,nwbmp,cachenwbmp);

         });


 
  $.getJSON("performance.json", function(json) { 
      // alert("welcome")

      var hits=json;
     
     var ttfbyte,totalpage_time,domComplete,downloadTime,initialConnection,domLoadingtoComplete,domLoadingtoLoaded,cache_ttfbyte,cache_totalpage_time,cache_domComplete,cache_downloadTime,cache_initialConnection,cache_domLoadingtoComplete,cache_domLoadingtoLoaded;

        for(i=0;i<hits.length;i++){


          runtype=hits[i].runtype;

  if(runtype.includes("withoutcache"))
  {
        
        ttfbyte=hits[i].TimeToFirstByte;
        totalpage_time=hits[i].TotalLoadTime;
        domComplete=hits[i].DomComplete;
        downloadTime=hits[i].DownloadTime;
        initialConnection=hits[i].InitialConnection;
        domLoadingtoComplete=hits[i].DOMLoadingtoComplete;
        domLoadingtoLoaded=hits[i].DOMLoadingtoLoaded;
  
        
        }

        else if(runtype.includes("withcache")){

        cache_ttfbyte=hits[i].TimeToFirstByte;
        cache_totalpage_time=hits[i].TotalLoadTime;
        cache_domComplete=hits[i].DomComplete;
        cache_downloadTime=hits[i].DownloadTime;
        cache_initialConnection=hits[i].InitialConnection;
        cache_domLoadingtoComplete=hits[i].DOMLoadingtoComplete;
        cache_domLoadingtoLoaded=hits[i].DOMLoadingtoLoaded;

        }
       
      }

if(totalpage_time<3000)
                {
                document.getElementById('launchpanel').className+= 'panel panel-green';
                }
                else if((totalpage_time>3000)&&(totalpage_time<=5000))
                {
                document.getElementById('launchpanel').className+= 'panel panel-yellow';
            }
                else if(totalpage_time>5000)
                {
                document.getElementById('launchpanel').className+= 'panel panel-red';
                }
                document.getElementById("pagetime").innerHTML=totalpage_time+"ms";



 mobileperformance(ttfbyte,totalpage_time,domComplete,downloadTime,initialConnection,domLoadingtoComplete,domLoadingtoLoaded,cache_ttfbyte,cache_totalpage_time,cache_domComplete,cache_downloadTime,cache_initialConnection,cache_domLoadingtoComplete,cache_domLoadingtoLoaded);

});


  

function mobileperformance(ttfbyte,totalpage_time,domComplete,downloadTime,initialConnection,domLoadingtoComplete,domLoadingtoLoaded,cache_ttfbyte,cache_totalpage_time,cache_domComplete,cache_downloadTime,cache_initialConnection,cache_domLoadingtoComplete,cache_domLoadingtoLoaded){
$.getJSON("mobileperformance.json", function(json) { 

    var mobiledata=json;
    
    var mobileruntype,mobilettfbyte,mobiletotalpage_time,mobiledomComplete,mobiledownloadTime,mobileinitialConnection,mobiledomLoadingtoComplete,mobiledomLoadingtoLoaded,mobilecache_ttfbyte,mobilecache_totalpage_time,mobilecache_domComplete,mobilecache_downloadTime,mobilecache_initialConnection,mobilecache_domLoadingtoComplete,mobilecache_domLoadingtoLoaded;


 for(i=0;i<mobiledata.length;i++){


       mobileruntype=mobiledata[i].runtype;

  if(mobileruntype.includes("withoutcache"))
  {
        
        mobilettfbyte=mobiledata[i].TimeToFirstByte;
        mobiletotalpage_time=mobiledata[i].TotalLoadTime;
        mobiledomComplete=mobiledata[i].DomComplete;
        mobiledownloadTime=mobiledata[i].DownloadTime;
        mobileinitialConnection=mobiledata[i].InitialConnection;
        mobiledomLoadingtoComplete=mobiledata[i].DOMLoadingtoComplete;
        mobiledomLoadingtoLoaded=mobiledata[i].DOMLoadingtoLoaded;
       
  
        
        }

        else if(mobileruntype.includes("withcache")){

        mobilecache_ttfbyte=mobiledata[i].TimeToFirstByte;
        mobilecache_totalpage_time=mobiledata[i].TotalLoadTime;
        mobilecache_domComplete=mobiledata[i].DomComplete;
        mobilecache_downloadTime=mobiledata[i].DownloadTime;
        mobilecache_initialConnection=mobiledata[i].InitialConnection;
        mobilecache_domLoadingtoComplete=mobiledata[i].DOMLoadingtoComplete;
        mobilecache_domLoadingtoLoaded=mobiledata[i].DOMLoadingtoLoaded;
       

        }
       
      }

 $("#chart").empty();  

          Morris.Bar({
            element: 'chart',
            data: [
                   { y: 'PageLoadTime', a: totalpage_time+"ms", b: mobiletotalpage_time+"ms" }
                   ],
            xkey: 'y',
            ykeys: ['a', 'b'],
            labels: ['Chrome', 'Mobile'],
            barColors: ["#FF6600", "#0D52D1"]
          });



          $("#chartcache").empty();  

          Morris.Bar({
            element: 'chartcache',
            data: [
                   { y: 'PageLoadTime', a: cache_totalpage_time+"ms", b: mobilecache_totalpage_time+"ms" }
                   ],
            xkey: 'y',
            ykeys: ['a', 'b'],
            labels: ['Chrome', 'Mobile'],
            barColors: ["#FF6600", "#0D52D1"]
          });


        
var chart = AmCharts.makeChart("chartresponse", {
    "type": "serial",
    "theme": "No theme",
    "fillEmptyCategories": true,
    "legend": {
    "align": "center",
    "periodValueText": "total: [[value.sum]]",
    "valueText": "[[value]] ([[percents]]%)",
    /*"valueWidth": 100,*/
        "autoMargins": false,
        "borderAlpha": 0.2,
        "equalWidths": true,
        "horizontalGap": 10,
        "markerSize": 10,
        "useGraphSettings": true,
        "valueAlign": "left",
        "valueWidth": 0
    },
    "dataProvider": [{
        "year": "Chrome w/o Cache",
        "InitialConnection": initialConnection,
        "TimetoFirstByte": ttfbyte,
        "DownloadTime": downloadTime,
        "DomContentLoaded" :domLoadingtoLoaded,
        "DOMLoadingtoComplete":domLoadingtoComplete
    },
    {
        "year": "Mobile w/o Cache",
        "mobileinitialConnection": mobileinitialConnection,
        "mobilettfbyte": mobilettfbyte,
        "mobiledownloadTime": mobiledownloadTime,
        "mobiledomLoadingtoLoaded" :mobiledomLoadingtoLoaded,
        "mobiledomLoadingtoComplete":mobiledomLoadingtoComplete
    }],
    "valueAxes": [{
        "stackType": "100%",
        "axisAlpha": 0,
        "gridAlpha": 0,
        "labelsEnabled": false,
        "position": "left"
    }],
    "graphs": [ {
        "balloonText": "[[title]], [[category]]<br><span style='font-size:14px;'><b>[[value]]</b> ([[percents]]%)</span>",
        "fillAlphas": 0.9,
        "fontSize": 11,
        "fixedColumnWidth": 100,
        "labelText": initialConnection +"ms",
        "lineAlpha": 0.5,
        "title": "InitialConnection",
        "type": "column",
        "valueField": "InitialConnection",
        "index":1
    },{
        "balloonText": "[[title]], [[category]]<br><span style='font-size:14px;'><b>[[value]]</b> ([[percents]]%)</span>",
        "fillAlphas": 0.9,
        "fontSize": 11,
        "labelText": ttfbyte +"ms",
        "lineAlpha": 0.5,
       "fixedColumnWidth": 100,
        "title": "TimetoFirstByte",
        "type": "column",
        "valueField": "TimetoFirstByte",
        "index":2
    }, {
        "balloonText": "[[title]], [[category]]<br><span style='font-size:14px;color:#0B610B;'><b>[[value]]</b> ([[percents]]%)</span>",
        "fillAlphas": 0.9,
        "fontSize": 11,
        "labelText": downloadTime +"ms",
        "lineAlpha": 0.5,
        "fixedColumnWidth": 100,
        "title": "DownloadTime",
        "type": "column",
        "valueField": "DownloadTime",
        "index":3
    }, {
        "balloonText": "[[title]], [[category]]<br><span style='font-size:14px;'><b>[[value]]</b> ([[percents]]%)</span>",
        "fillAlphas": 0.9,
        "fontSize": 11,
        "labelText": domLoadingtoLoaded +"ms",
        "lineAlpha": 0.5,
         "fixedColumnWidth": 100,
        "title": "DomContentLoaded",
        "type": "column",
        "valueField": "DomContentLoaded",
        "index":5
    }, {
        "balloonText": "[[title]], [[category]]<br><span style='font-size:14px;'><b>[[value]]</b> ([[percents]]%)</span>",
        "fillAlphas": 0.9,
        "fontSize": 11,
        "labelText": domLoadingtoComplete +"ms",
        "lineAlpha": 0.5,
        "fixedColumnWidth": 100,
        "title": "DOMLoadingtoComplete",
        "type": "column",
        "valueField": "DOMLoadingtoComplete",
        "index":6
    },{
        "balloonText": "[[title]], [[category]]<br><span style='font-size:14px;'><b>[[value]]</b> ([[percents]]%)</span>",
        "fillAlphas": 0.9,
        "fontSize": 11,
        "fixedColumnWidth": 100,
        "labelText": mobileinitialConnection +"ms",
        "lineAlpha": 0.5,
        "title": "Mobile-InitialConnection",
        "type": "column",
        "valueField": "mobileinitialConnection",
        "index":1
    },{
        "balloonText": "[[title]], [[category]]<br><span style='font-size:14px;'><b>[[value]]</b> ([[percents]]%)</span>",
        "fillAlphas": 0.9,
        "fontSize": 11,
        "labelText": mobilettfbyte +"ms",
        "lineAlpha": 0.5,
       "fixedColumnWidth": 100,
        "title": "Mobile-TimetoFirstByte",
        "type": "column",
        "valueField": "mobilettfbyte",
        "index":2
    }, {
        "balloonText": "[[title]], [[category]]<br><span style='font-size:14px;color:#0B610B;'><b>[[value]]</b> ([[percents]]%)</span>",
        "fillAlphas": 0.9,
        "fontSize": 11,
        "labelText": mobiledownloadTime +"ms",
        "lineAlpha": 0.5,
        "fixedColumnWidth": 100,
        "title": "Mobile-DownloadTime",
        "type": "column",
        "valueField": "mobiledownloadTime",
        "index":3
    }, {
        "balloonText": "[[title]], [[category]]<br><span style='font-size:14px;'><b>[[value]]</b> ([[percents]]%)</span>",
        "fillAlphas": 0.9,
        "fontSize": 11,
        "labelText": mobiledomLoadingtoLoaded +"ms",
        "lineAlpha": 0.5,
         "fixedColumnWidth": 100,
        "title": "Mobile-DomContentLoaded",
        "type": "column",
        "valueField": "mobiledomLoadingtoLoaded",
        "index":5
    }, {
        "balloonText": "[[title]], [[category]]<br><span style='font-size:14px;'><b>[[value]]</b> ([[percents]]%)</span>",
        "fillAlphas": 0.9,
        "fillColors": "#B0DE09",
        "fontSize": 11,
        "labelText": mobiledomLoadingtoComplete +"ms",
        "lineAlpha": 0.5,
        "fixedColumnWidth": 100,
        "title": "Mobile-DOMLoadingtoComplete",
        "type": "column",
        "valueField": "mobiledomLoadingtoComplete",
        "index":6
    }],
    "marginTop": 30,
    "marginRight": 0,
    "marginLeft": 0,
    "marginBottom": 40,
    "autoMargins": false,
    "categoryField": "year",
    "categoryAxis": {
        "categoryAxis.dashLength":100,
        "gridPosition": "start",
        "axisAlpha": 0,
        "gridAlpha": 0
    },
    "export": {
        "enabled": false
     }

});

//alert(cache_domLoadingtoComplete)


var chart = AmCharts.makeChart("chartresponsecache", {
    "type": "serial",
    "theme": "No theme",
    "fillEmptyCategories": true,
    "legend": {
    "align": "center",
    "periodValueText": "total: [[value.sum]]",
    "valueText": "[[value]] ([[percents]]%)",
    /*"valueWidth": 100,*/
        "autoMargins": false,
        "borderAlpha": 0.2,
        "equalWidths": true,
        "horizontalGap": 10,
        "markerSize": 10,
        "useGraphSettings": true,
        "valueAlign": "left",
        "valueWidth": 0
    },
    "dataProvider": [{
        "year": "Chrome with Cache",
        "InitialConnection": cache_initialConnection,
        "TimetoFirstByte": cache_ttfbyte,
        "DownloadTime": cache_downloadTime,
        "DomContentLoaded" :cache_domLoadingtoLoaded,
        "DOMLoadingtoComplete":cache_domLoadingtoComplete
    },
    {
        "year": "Mobile with Cache",
        "mobilecache_initialConnection": mobilecache_initialConnection,
        "mobilecache_ttfbyte": mobilecache_ttfbyte,
        "mobilecache_downloadTime": mobilecache_downloadTime,
        "mobilecache_domLoadingtoLoaded" :mobilecache_domLoadingtoLoaded,
        "mobilecache_domLoadingtoComplete":mobilecache_domLoadingtoComplete
    }],
    "valueAxes": [{
        "stackType": "100%",
        "axisAlpha": 0,
        "gridAlpha": 0,
        "labelsEnabled": false,
        "position": "left"
    }],
    "graphs": [ {
        "balloonText": "[[title]], [[category]]<br><span style='font-size:14px;'><b>[[value]]</b> ([[percents]]%)</span>",
        "fillAlphas": 0.9,
        "fontSize": 11,
        "fixedColumnWidth": 100,
        "labelText": cache_initialConnection +"ms",
        "lineAlpha": 0.5,
        "title": "InitialConnection",
        "type": "column",
        "valueField": "InitialConnection",
        "index":1
    },{
        "balloonText": "[[title]], [[category]]<br><span style='font-size:14px;'><b>[[value]]</b> ([[percents]]%)</span>",
        "fillAlphas": 0.9,
        "fontSize": 11,
        "labelText": cache_ttfbyte +"ms",
        "lineAlpha": 0.5,
       "fixedColumnWidth": 100,
        "title": "TimetoFirstByte",
        "type": "column",
        "valueField": "TimetoFirstByte",
        "index":2
    }, {
        "balloonText": "[[title]], [[category]]<br><span style='font-size:14px;color:#0B610B;'><b>[[value]]</b> ([[percents]]%)</span>",
        "fillAlphas": 0.9,
        "fontSize": 11,
        "labelText": cache_downloadTime +"ms",
        "lineAlpha": 0.5,
        "fixedColumnWidth": 100,
        "title": "DownloadTime",
        "type": "column",
        "valueField": "DownloadTime",
        "index":3
    }, {
        "balloonText": "[[title]], [[category]]<br><span style='font-size:14px;'><b>[[value]]</b> ([[percents]]%)</span>",
        "fillAlphas": 0.9,
        "fontSize": 11,
        "labelText": cache_domLoadingtoLoaded +"ms",
        "lineAlpha": 0.5,
         "fixedColumnWidth": 100,
        "title": "DomContentLoaded",
        "type": "column",
        "valueField": "DomContentLoaded",
        "index":5
    }, {
        "balloonText": "[[title]], [[category]]<br><span style='font-size:14px;'><b>[[value]]</b> ([[percents]]%)</span>",
        "fillAlphas": 0.9,
        "fontSize": 11,
        "labelText": cache_domLoadingtoComplete +"ms",
        "lineAlpha": 0.5,
        "fixedColumnWidth": 100,
        "title": "DOMLoadingtoComplete",
        "type": "column",
        "valueField": "DOMLoadingtoComplete",
        "index":6
    },{
        "balloonText": "[[title]], [[category]]<br><span style='font-size:14px;'><b>[[value]]</b> ([[percents]]%)</span>",
        "fillAlphas": 0.9,
        "fontSize": 11,
        "fixedColumnWidth": 100,
        "labelText": mobilecache_initialConnection +"ms",
        "lineAlpha": 0.5,
        "title": "Mobile-InitialConnection",
        "type": "column",
        "valueField": "mobilecache_initialConnection",
        "index":1
    },{
        "balloonText": "[[title]], [[category]]<br><span style='font-size:14px;'><b>[[value]]</b> ([[percents]]%)</span>",
        "fillAlphas": 0.9,
        "fontSize": 11,
        "labelText": mobilecache_ttfbyte +"ms",
        "lineAlpha": 0.5,
       "fixedColumnWidth": 100,
        "title": "Mobile-TimetoFirstByte",
        "type": "column",
        "valueField": "mobilecache_ttfbyte",
        "index":2
    }, {
        "balloonText": "[[title]], [[category]]<br><span style='font-size:14px;color:#0B610B;'><b>[[value]]</b> ([[percents]]%)</span>",
        "fillAlphas": 0.9,
        "fontSize": 11,
        "labelText": mobilecache_downloadTime +"ms",
        "lineAlpha": 0.5,
        "fixedColumnWidth": 100,
        "title": "Mobile-DownloadTime",
        "type": "column",
        "valueField": "mobilecache_downloadTime",
        "index":3
    }, {
        "balloonText": "[[title]], [[category]]<br><span style='font-size:14px;'><b>[[value]]</b> ([[percents]]%)</span>",
        "fillAlphas": 0.9,
        "fontSize": 11,
        "labelText": mobilecache_domLoadingtoLoaded +"ms",
        "lineAlpha": 0.5,
         "fixedColumnWidth": 100,
        "title": "Mobile-DomContentLoaded",
        "type": "column",
        "valueField": "mobilecache_domLoadingtoLoaded",
        "index":5
    }, {
        "balloonText": "[[title]], [[category]]<br><span style='font-size:14px;'><b>[[value]]</b> ([[percents]]%)</span>",
        "fillAlphas": 0.9,
        "fontSize": 11,
        "fillColors": "#B0DE09",
        "labelText": mobilecache_domLoadingtoComplete +"ms",
        "lineAlpha": 0.5,
        "fixedColumnWidth": 100,
        "title": "Mobile-DOMLoadingtoComplete",
        "type": "column",
        "valueField": "mobilecache_domLoadingtoComplete",
        "index":6
    }],
    "marginTop": 30,
    "marginRight": 0,
    "marginLeft": 0,
    "marginBottom": 40,
    "autoMargins": false,
    "categoryField": "year",
    "categoryAxis": {
        "categoryAxis.dashLength":100,
        "gridPosition": "start",
        "axisAlpha": 0,
        "gridAlpha": 0
    },
    "export": {
        "enabled": false
     }

});


  });

}   

/*$.getJSON("lighthouse.json", function(json) 
{ 
    var hits=json.rules;
    var render,css,cssrules,javascript,text;
    var urllist =[];
    for(var i=0;i<hits.length;i++)
            {  
    var eachobj=hits[i];
  //  alert(JSON.stringify(eachobj));
    var eachobjkeys=Object.keys(eachobj);
    eachobjkeys.forEach(function (key)
                         {
                            var row=document.createElement('h3');
                            row.setAttribute("style","color:#3c9adc");
                            var keys=key.replace(/-/g,"&nbsp;");
                            row.innerHTML=keys;

                            var ul=document.createElement('ul');
                            ul.setAttribute("style","font-weight:0;line-height:0,letter-spacing: 0;");
                            var li1=document.createElement('li'); 
                            li1.setAttribute("style","color:#808080");   
                            var li2=document.createElement('li')
                            li2.setAttribute("style","color:#808080");  
                            var ul1=document.createElement('ul');
                    
                            ul1.setAttribute("style","color:#3c9adc");  
                            ul1.innerHTML="Url List&nbsp; :&nbsp;";
                           
                            var eachusecase=eachobj[eachobjkeys];
                            var eachusecasekeys=  Object.keys(eachusecase);
                            var urlcount=eachusecase["urlcount"];
                              urllist=eachusecase["url"];
                             
                               if(!urllist.includes("No URL found"))
                               {
                           for (var j = 0; j < urllist.length; j++) {
                            
                              
                                   var li3=document.createElement('li')
                            li3.setAttribute("style","color:#808080"); 
                                
                            li3.innerText=urllist[j];
                            ul1.appendChild(li3);
 

                        }
                    }
                    else{
                        var li3=document.createElement('li')
                            li3.setAttribute("style","color:#808080"); 
                                
                            
                        li3.innerHTML="No url found";
                            ul1.appendChild(li3);

                    }
                            
                            if(urlcount!=0)
                            {
                              li2.innerHTML="Needs&nbsp;Improvement";
                            }
                           else
                            {
                            li2.innerHTML="Already&nbsp;Implemented";
                            }
                        li1.innerHTML=eachusecase["description"];

                         ul.appendChild(li1);
                            ul.appendChild(li2);
                          
                            ul.appendChild(ul1);
                        row.appendChild(ul);

                        document.getElementById("light").appendChild(row);
                           });
              }
});*/

$.getJSON("recommendations.json", function(json) {


var hits=json;

var recommendations,pagename;

var rule,message, suggest;


var row=document.createElement('h3');
                            row.setAttribute("style","color:#3c9adc");

                          


for(var i=0;i<hits.length;i++)
{

pagename=hits[i].pagename;





recommendations=hits[i].recommendation;

if(pagename=="withoutcache")
{

for(j=0;j<recommendations.length;j++)

{
  rule=recommendations[j].ruleHeader;
  message=recommendations[j].Message;
  suggest=recommendations[j].Recommendation;

    var ul=document.createElement('ul');
                            ul.setAttribute("style","font-weight:normal;line-height:0,letter-spacing: normal;font-family:Arial;text-align:left;font-size:20px");
                            ul.setAttribute("id",j);
                            ul.setAttribute("class","accordion")
                            ul.innerHTML='<b>'+rule+'</b>';

  var li1=document.createElement('li'); 
                            li1.setAttribute("style","color:#808080"); 
                            var a=document.createElement('a');
                            a.setAttribute("class","fa fa-hand-o-right")

                       
var msgurl=message;
msgurl=msgurl.toString().replace(/[\[\]']+/g,'').replace(/\,/g,'').replace(/\n/g, '\\n');;
li1.innerText=suggest;


a.setAttribute("onclick","getUrl('"+msgurl+"','"+j+"');");
//a.innerHTML="more info";


ul.appendChild(li1);
ul.appendChild(a);
row.appendChild(ul);


}

}

}

document.getElementById("rec").appendChild(row);

});


function getUrl(msgurl,j) {

    //alert("inspired "+j)
       //alert(msgurl)
    var ul = document.getElementById(j);
   // var content=msgurl.replace(/\'/g,'');


if(ul!=undefined)
{
$("#"+"expandlinks").remove();

}


                      var li2=document.createElement('li'); 
                    li2.setAttribute("style","color:#808080;list-style-type: circle;margin-left: 50px"); 
                     li2.setAttribute("id","expandlinks")
                    // var fix=content.replace("\\u2022/g", "/\n/g");
                    
                    li2.innerText=msgurl;
                    ul.appendChild(li2);
                      
                        
                        

}  

function majorpointsexpand(expand)
    {
        if (expand == "Expand")
            {
                $('#data').css("display","inherit");
                $(".majorpointslegend").html("Collapse");
            }
        else
            {
                $('#data').css("display","none");
                $(".majorpointslegend").html("Expand");
            }
    }
function mobilelog(s,s1,nwbmp,cachenwbmp){

$.getJSON("mobilelog.json", function(json) {



var hits=json;
var image,css,other,xhr,mobilenwbmp,runtype,pagesize,html,js,font,video,mobilecachenwbmp,cachepagesize;

for(var i=0;i<hits.length;i++)
{

runtype=hits[i].runtype;

    if(runtype.includes("withoutcache"))
    {
        image=hits[i].image;
        css=hits[i].css;
        other=hits[i].other;
        xhr=hits[i].xhr;
        mobilenwbmp=hits[i].nwrequest;
        pagesize=hits[i].pagesize;
        video=hits[i].video;
        html=hits[i].html;
        js=hits[i].javascript;
        font=hits[i].font;

    }


    else if(runtype.includes("withcache"))
    {
        
        mobilecachenwbmp=hits[i].nwrequest;
        cachepagesize=hits[i].pagesize;
        
    }

}

smobile=(pagesize/(1024*1024)).toFixed(2);
 
s1mobile=(cachepagesize/(1024*1024)).toFixed(2);



          var chart = AmCharts.makeChart( "chartdivmobile", {
  "type": "pie",
  "theme": "dark",
  "dataProvider": [ {
    "PageProfiling": "CSS",
    "Values": css
  }, {
    "PageProfiling": "Font",
    "Values": font
  }, {
    "PageProfiling": "HTML",
    "Values": html
  }, {
    "PageProfiling": "Images",
    "Values": image
  }, {
    "PageProfiling": "JS",
    "Values": js
  }, {
    "PageProfiling": "Video",
    "Values": video
  }, {
    "PageProfiling": "Other",
    "Values": other
  }, {
    "PageProfiling": "XHR",
    "Values": xhr
  } ],
  "valueField": "Values",
  "titleField": "PageProfiling",
   "balloon":{
   "fixedPosition":true
  },
  "export": {
   "enabled": true,
    "menu": []
  }
  
} );


          $("#chartpagesize").empty();  

          Morris.Bar({
            element: 'chartpagesize',
            data: [
                   { y: 'Pagesize', a: s, b: s1, c:smobile ,d:s1mobile}
                   ],
            xkey: 'y',
            ykeys: ['a', 'b','c','d'],
            labels: ['Chrome w/o Cache', 'Chrome With Cache', 'Mobile w/o Cache','Mobile with Cache'],
            barColors: ["#FF6600", "#0D52D1"]
          });


           $("#nw").empty();  

          Morris.Bar({
            element: 'nw',
            data: [
                   { y: 'n/w Request', a: nwbmp, b: cachenwbmp ,c:mobilenwbmp,d:mobilecachenwbmp}
                   ],
            xkey: 'y',
              barSize: 70,
            ykeys: ['a', 'b','c','d'],
            labels: ['Chrome w/o Cache', 'Chrome with Cache','Mobile w/o cache','Mobile with cache'],
            barColors: ["#FF6600", "#0D52D1","#FF6600", "#0D52D1"]
          });



});

}




function relativeToAbsolute(url) {
    $("input.netRow loaded isExpandable").prop('disabled', true);
    
  if (url.indexOf("//") > -1) {
    return url;
  }
  // trick using <a> element to turn relative URLs into absolute.
  var a = document.createElement("a");
  a.href = url;
  return a.href;
}
function div(attr, url, height) {
  var div = document.createElement("div");
  div.className = "har";
  div.setAttribute(attr, url);
  div.setAttribute("height", height);
  return div;
}

var googleAnalyticsProfile = "UA-82884352-1";
if (googleAnalyticsProfile && googleAnalyticsProfile.charAt(0) !== "@") {

    window.ga=window.ga||function(){(ga.q=ga.q||[]).push(arguments)};ga.l=+new Date;
    ga('create', googleAnalyticsProfile, 'auto');
    ga('send', 'pageview');

}




/*===================================================================OldwaterfallChart=============================================================================

 /*$.getJSON("harfile.json", function(json) {
    var hits=json.log.entries;
   
var blocked,dns,connect,send,wait,receive,ssl,pageref, starttime,url,method;
var status,size,type,text;

for(i=0;i<hits.length;i++)

{

pageref=hits[i].pageref;

starttime=hits[i].startedDateTime;

method=hits[i].request.method;

url=hits[i].request.url;

status=hits[i].response.status;

size=hits[i].response.content.size;

type=hits[i].response.content.mimeType;



blocked=hits[i].timings.blocked;
connect=hits[i].timings.connect;

dns=hits[i].timings.dns;

wait=hits[i].timings.wait;

send=hits[i].timings.send;

receive=hits[i].timings.receive;

ssl=hits[i].timings.ssl;




 $('#har').HarView();
            var har = $('#har').data('HarView');
            var t0 = Date.now();
           
                var t = new Date(t0 + i * 20);
               
                har.entry(i, {
                    pageRef: pageref,
                    startedDateTime: starttime
                });
                har.request(i, {
                    method: method,
                    url: url + i,
                    headers: [
                        {name: 'Connection', value: 'keep-alive'}
                    ]
                });
            
                var timings = {
                    "startTime" :starttime,
                    "blocked": blocked,
                    "dns": dns,
                    "connect": connect,
                    "send": send,
                    "wait": wait,
                    "receive": receive

                };
                har.timings(i, timings);
           
                har.response(i, {
                    "status":status,
                    "bodySize": size,
                    "headers": [
                        {
                            "name": "content-type",
                            "value": type
                        },
                        {
                            "name": "date",
                            "value": starttime
                        },
                        {
                            "name": "content-length",
                            "value": size
                        },
                        {
                            "name": "connection",
                            "value": "keep-alive"
                        }
                    ],
                    
                });
          




}


});
*/
/*===================================================================end=============================================================================

/*$("#content").bind("onViewerInit", function(event) {

 var viewer = event.target.repObject; 

 viewer.loadHar("C:\AccessibilityReport\harfile.har");

 viewer.setPreviewColumns("url status size timeline", true);

  });
*/

//$("#content").bind("onViewerInit", function(event) { var viewer = event.target.repObject; var log = "C:\AccessibilityReport\harfile.har"; viewer.appendPreview(log); });

/*$("#content").bind("onPreviewInit", function(event)
    {
        // Get application object
        var viewer = event.target.repObject;
        viewer.loadHar("C:\AccessibilityReport\harfile.har");
    });*/



            /*var max = 10;
            $('#har').HarView();
            var har = $('#har').data('HarView');
            var t0 = Date.now();
            for(var i = 0; i < max; i++) {
                var t = new Date(t0 + i * 20);
                // Note: startedDateTime is part of entry - not request
                har.entry(i, {
                    pageRef: 'Hello World',
                    startedDateTime: t
                });
                har.request(i, {
                    method: 'GET',
                    url: 'http://urldasdash.jhd.ajgas/jdga/dahsgd/hdgash/dgashdg/hdg/hdgh/dhasgdf/ahsdf/aghsd?ghasd' + i,
                    headers: [
                        {name: 'Connection', value: 'keep-alive'}
                    ]
                });
            }
            for(i = 0; i < max; i++) {
                var timings = {
                    "blocked": 100,
                    "dns": 10,
                    "connect": 20,
                    "send": 30,
                    "wait": 40,
                    "receive": 50
                };
                har.timings(i, timings);
            }
            for(i = 0; i < max; i++) {
                har.response(i, {
                    "status": 200,
                    "bodySize": 8730,
                    "headers": [
                        {
                            "name": "content-type",
                            "value": "text/xml; charset=utf-8"
                        },
                        {
                            "name": "date",
                            "value": "Tue, 27 Dec 2011 05:12:54 GMT"
                        },
                        {
                            "name": "content-length",
                            "value": "8730"
                        },
                        {
                            "name": "connection",
                            "value": "keep-alive"
                        }
                    ],
                    "content": {
                        text: "<?xml version=\"1.0\" encoding=\"utf-8\" ?><?pageview_candidate?><SearchResponse xmlns=\"http://schemas.microsoft.com/LiveSearch/2008/04/XML/element\" Version=\"2.2\"><Query><SearchTerms>ql.io</SearchTerms></Query><web:Web xmlns:web=\"http://schemas.microsoft.com/LiveSearch/2008/04/XML/web\"><web:Total>9480000</web:Total><web:Offset>0</web:Offset><web:Results><web:WebResult><web:Title>Announcing ql.io Ñ eBay Tech Blog</web:Title><web:Description>We are happy to announce ql.io Ð a declarative, evented, data-retrieval and aggregation gateway for HTTP APIs. Through ql.io, we want to help application developers ...</web:Description><web:Url>http://www.ebaytechblog.com/2011/11/30/announcing-ql-io/</web:Url><web:CacheUrl>http://cc.bingj.com/cache.aspx?q=%22ql+io%22&amp;d=4838852285236758&amp;w=d366d1bd,6816a241</web:CacheUrl><web:DisplayUrl>www.ebaytechblog.com/2011/11/30/announcing-ql-io</web:DisplayUrl><web:DateTime>2011-12-18T16:49:00Z</web:DateTime></web:WebResult><web:WebResult><web:Title>InfoQ: eBay Announces ql.io</web:Title><web:Description>We are happy to announce Ð a declarative, evented, data-retrieval and aggregation gateway for HTTP APIs. Through ql.io, we want to help application developers ...</web:Description><web:Url>http://www.infoq.com/news/2011/11/ql-io-release</web:Url><web:CacheUrl>http://cc.bingj.com/cache.aspx?q=%22ql+io%22&amp;d=4521484265719037&amp;w=75479e80,e3d1cb78</web:CacheUrl><web:DisplayUrl>www.infoq.com/news/2011/11/ql-io-release</web:DisplayUrl><web:DateTime>2011-12-19T20:56:00Z</web:DateTime></web:WebResult><web:WebResult><web:Title>ql.io</web:Title><web:Description>About ql.io A SQL and JSON inspired DSL. SQL is quite a powerful DSL to retrieve, filter, project, and join data Ñ see efforts like A co-Relational Model of Data ...</web:Description><web:Url>http://ql.io/docs/about</web:Url><web:CacheUrl>http://cc.bingj.com/cache.aspx?q=%22ql+io%22&amp;d=4518031125644867&amp;w=74c43eab,dbf1bb</web:CacheUrl><web:DisplayUrl>ql.io/docs/about</web:DisplayUrl><web:DateTime>2011-12-21T10:29:00Z</web:DateTime></web:WebResult><web:WebResult><web:Title>Loading...</web:Title><web:Url>http://boiteaoutilsqsehse.com/?fp=DlOivWY6Bo5JgGGsWKkoyl6%2BrvNZEwke82VCseZGsYLvwDhb1klI42cDKEG8P6io0JiEZTZDujGpV4lR7mL5GQ%3D%3D&amp;prvtof=CixNAYdjuc66upUC%2B6ZKPNdSKwRl0fqF4hK%2F%2F38SPAQ%3D&amp;poru=ql%2FXWQYdGN72KZoJArBCCUi2lebzAsJhFQDcqdxcCD07gnbQ152YLanKi8KkNepG&amp;</web:Url><web:CacheUrl>http://cc.bingj.com/cache.aspx?q=%22ql+io%22&amp;d=4812498364402319&amp;w=70d5c13a,b15a48db</web:CacheUrl><web:DisplayUrl>boiteaoutilsqsehse.com</web:DisplayUrl><web:DateTime>2011-12-23T21:43:00Z</web:DateTime></web:WebResult><web:WebResult><web:Title>eBay&apos;s ql.io is an &quot;SQL&quot; for web APIs - The H Open Source: News ...</web:Title><web:Description>Inspired by SQL, eBay&apos;s ql.io allows complex mashups of web APIs to be expressed in a language which is automatically optimised for parallel execution</web:Description><web:Url>http://www.h-online.com/open/news/item/eBay-s-ql-io-is-an-SQL-for-web-APIs-1388806.html</web:Url><web:CacheUrl>http://cc.bingj.com/cache.aspx?q=%22ql+io%22&amp;d=4961486479494152&amp;w=2464a1ed,3a7bae99</web:CacheUrl><web:DisplayUrl>www.h-online.com/open/news/item/eBay-s-ql-io-is-an-SQL-for-web...</web:DisplayUrl><web:DateTime>2011-12-17T11:36:00Z</web:DateTime></web:WebResult><web:WebResult><web:Title>Manastirea Prislop Arsenie Boca - YouTube</web:Title><web:Description>Uploaded by portaltfm on Sep 26, 2010 no description available Category: Travel &amp; Events Tags: Manastirea Prislop Arsenie Boca License: Standard YouTube ...</web:Description><web:Url>http://www.youtube.com/watch?v=qL_Io-K9FHg</web:Url><web:CacheUrl>http://cc.bingj.com/cache.aspx?q=%22ql+io%22&amp;d=4612881174367018&amp;w=f8687101,70baa56</web:CacheUrl><web:DisplayUrl>www.youtube.com/watch?v=qL_Io-K9FHg</web:DisplayUrl><web:DateTime>2011-12-22T09:21:00Z</web:DateTime></web:WebResult><web:WebResult><web:Title>The Muffins salahkah ku - YouTube</web:Title><web:Description>Uploaded by lomangpanehh on May 11, 2009 no description available Category: People &amp; Blogs Tags: The Muffins salahkah ku License: Standard YouTube License ...</web:Description><web:Url>http://www.youtube.com/watch?v=Io9qL8G4-0s</web:Url><web:CacheUrl>http://cc.bingj.com/cache.aspx?q=%22ql+io%22&amp;d=4963711277532291&amp;w=b0713f61,eac926c8</web:CacheUrl><web:DisplayUrl>www.youtube.com/watch?v=Io9qL8G4-0s</web:DisplayUrl><web:DateTime>2011-12-22T20:25:00Z</web:DateTime></web:WebResult><web:WebResult><web:Title>Cephei.QL :: C++/CLI wrapper around QuantLib for F#</web:Title><web:Description>Cephei.QL is a library that wraps the QuantLib C++ library with classes that provide CTS interfaces that can be used from F#. Cephei.QL is not a simple wrapper that ...</web:Description><web:Url>http://ql.codeplex.com/</web:Url><web:CacheUrl>http://cc.bingj.com/cache.aspx?q=%22ql+io%22&amp;d=4533772184848168&amp;w=ca0af65d,3b42073b</web:CacheUrl><web:DisplayUrl>ql.codeplex.com</web:DisplayUrl><web:DateTime>2011-12-24T03:59:00Z</web:DateTime><web:SearchTags><web:WebSearchTag><web:Name>search.codeplex.project.name</web:Name><web:Value>&quot;QL&quot;</web:Value></web:WebSearchTag><web:WebSearchTag><web:Name>search.codeplex.project.title</web:Name><web:Value>&quot;Cephei.QL :: C++/CLI wrapper around QuantLib for F#&quot;</web:Value></web:WebSearchTag><web:WebSearchTag><web:Name>search.codeplex.project.description</web:Name><web:Value>&quot;Cephei.QL is a library that wraps the QuantLib C++ library with classes that provide CTS interfaces that can be used from F#. Cephei.QL is not a simple wrapper that stops at plumbing for P/Invoke type C functions that replicate Excel addin function.. Cephei.QL provides a high level interface that looks like a class library developed in a .NET language&quot;</web:Value></web:WebSearchTag><web:WebSearchTag><web:Name>search.codeplex.project.createddate</web:Name><web:Value>&quot;4/26/2011 2:23:21 AM&quot;</web:Value></web:WebSearchTag><web:WebSearchTag><web:Name>search.codeplex.project.projecttags</web:Name><web:Value>&quot;&quot;</web:Value></web:WebSearchTag><web:WebSearchTag><web:Name>search.codeplex.project.licenseshortname</web:Name><web:Value>&quot;Ms-RL&quot;</web:Value></web:WebSearchTag><web:WebSearchTag><web:Name>search.codeplex.project.currentreleasedate</web:Name><web:Value>&quot;5/13/2011 12:00:00 AM&quot;</web:Value></web:WebSearchTag><web:WebSearchTag><web:Name>search.codeplex.project.currentreleasedevelopmentstatus</web:Name><web:Value>&quot;Beta&quot;</web:Value></web:WebSearchTag><web:WebSearchTag><web:Name>search.codeplex.project.currentreleasename</web:Name><web:Value>&quot;2.101b&quot;</web:Value></web:WebSearchTag><web:WebSearchTag><web:Name>search.codeplex.project.currentreleaserating</web:Name><web:Value>&quot;0&quot;</web:Value></web:WebSearchTag><web:WebSearchTag><web:Name>search.codeplex.project.currentreleasenumberofratings</web:Name><web:Value>&quot;0&quot;</web:Value></web:WebSearchTag><web:WebSearchTag><web:Name>search.codeplex.project.currentreleasenumberofreviews</web:Name><web:Value>&quot;0&quot;</web:Value></web:WebSearchTag><web:WebSearchTag><web:Name>search.codeplex.project.downloadfilecount</web:Name><web:Value>&quot;0&quot;</web:Value></web:WebSearchTag><web:WebSearchTag><web:Name>search.codeplex.project.visitscount</web:Name><web:Value>&quot;6&quot;</web:Value></web:WebSearchTag><web:WebSearchTag><web:Name>search.codeplex.project.pageviewcount</web:Name><web:Value>&quot;13&quot;</web:Value></web:WebSearchTag><web:WebSearchTag><web:Name>search.codeplex.project.contributorscount</web:Name><web:Value>&quot;1&quot;</web:Value></web:WebSearchTag></web:SearchTags></web:WebResult><web:WebResult><web:Title>QL - Definition by AcronymFinder - Abbreviations and acronyms ...</web:Title><web:Description>sort results: alphabetical | rank ? Rank Abbr. Meaning ***** QL: Quick Look ***** QL: Queensland (Australia) ***** QL: Quality of Life (USAF funding issues)</web:Description><web:Url>http://www.acronymfinder.com/QL.html</web:Url><web:CacheUrl>http://cc.bingj.com/cache.aspx?q=%22ql+io%22&amp;d=4520011090495820&amp;w=d750a496,47fa3370</web:CacheUrl><web:DisplayUrl>www.acronymfinder.com/QL.html</web:DisplayUrl><web:DateTime>2011-12-23T07:41:00Z</web:DateTime></web:WebResult><web:WebResult><web:Title>QL-SHOP</web:Title><web:Description>QL-SHOP Watch!</web:Description><web:Url>http://ql-shop.com/</web:Url><web:CacheUrl>http://cc.bingj.com/cache.aspx?q=%22ql+io%22&amp;d=4675007874664093&amp;w=e9ef8dcb,594f76ca</web:CacheUrl><web:DisplayUrl>ql-shop.com</web:DisplayUrl><web:DateTime>2011-12-22T21:12:00Z</web:DateTime></web:WebResult></web:Results></web:Web></SearchResponse>"
                    }
                });
            }
        });*/