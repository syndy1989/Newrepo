$.getJSON("violations.json", function(json) {
       
         var issuePages=json;
         for(var i=0;i<issuePages.length;i++)
         {
            var eachPage=issuePages[i];
            var pageName;
            for (var j = 0; j < eachPage.length; j++) {
                
                if(eachPage[j].hasOwnProperty('pagename'))
                {
                    pageName=eachPage[j].pagename;
                }
            }


              var tablerow1=document.createElement('tr');
                
                    var tablecolum1=document.createElement('td');
                    var tablecolum2=document.createElement('td');
                    tablecolum1.setAttribute("style","color:#3c9adc");
                    tablecolum1.innerHTML="PageName".bold();
                    tablecolum2.setAttribute("style","font-weight: bold;color:#3c9adc");
                     tablecolum2.innerHTML="HomePage";

                      tablerow1.appendChild(tablecolum1);
                    tablerow1.appendChild(tablecolum2);

                     document.getElementById("dynamicPerformance").appendChild(tablerow1);  


            for (var j = 0; j < eachPage.length; j++) {
                
                if(eachPage[j].hasOwnProperty('pagename'))
                {
                    continue;
                }
                else
                {

                   //window.alert(JSON.stringify(eachPage[j]));

                  




                    var tablerow2=document.createElement('tr');
                
                    var tablecolum3=document.createElement('td');
                    var tablecolum4=document.createElement('td');

                    tablecolum3.innerHTML=("Violations").bold();;
                     tablecolum4.setAttribute("style", "Font-Weight: bold");
                     tablecolum4.innerText=(eachPage[j].Help);

                      tablerow2.appendChild(tablecolum3);
                    tablerow2.appendChild(tablecolum4);



                    var tablerow3=document.createElement('tr');
                
                    var tablecolum5=document.createElement('td');
                    var tablecolum6=document.createElement('td');

                    tablecolum5.innerHTML="Description";
                     tablecolum6.innerText=eachPage[j].description;

                      tablerow3.appendChild(tablecolum5);
                    tablerow3.appendChild(tablecolum6);




                    /*var tablerow4=document.createElement('tr');
                
                    var tablecolum7=document.createElement('td');
                    var tablecolum8=document.createElement('td');

                    tablecolum7.innerHTML="Recommendations";
                     tablecolum8.innerText=eachPage[j].message;

                      tablerow4.appendChild(tablecolum7);
                    tablerow4.appendChild(tablecolum8);




                    var tablerow5=document.createElement('tr');
                
                    var tablecolum9=document.createElement('td');
                    var tablecolum10=document.createElement('td');

                    tablecolum9.innerHTML="Issues";
                     tablecolum10.innerText=eachPage[j].html;

                      tablerow5.appendChild(tablecolum9);
                    tablerow5.appendChild(tablecolum10);*/



                    var tablerow6=document.createElement('tr');
                
                    var tablecolum11=document.createElement('td');
                    var tablecolum12=document.createElement('td');

                    tablecolum11.innerHTML="Impact";
                     tablecolum12.innerHTML=eachPage[j].impact;

                      tablerow6.appendChild(tablecolum11);
                    tablerow6.appendChild(tablecolum12);


                    var tablerow7=document.createElement('tr');
                
                    var tablecolum13=document.createElement('td');
                    var tablecolum14=document.createElement('td');

                    tablecolum13.innerHTML="Guidelines";
                     tablecolum14.innerHTML=eachPage[j].Guidelines;

                      tablerow7.appendChild(tablecolum13);
                    tablerow7.appendChild(tablecolum14);


                    var tablerow8=document.createElement('tr');
                
                    var tablecolum15=document.createElement('td');
                    var tablecolum16=document.createElement('td');

                    tablecolum15.innerHTML="</br>";
                     tablecolum16.innerHTML="</br>";

                      tablerow8.appendChild(tablecolum15);
                    tablerow8.appendChild(tablecolum16);



                   
                    document.getElementById("dynamicPerformance").appendChild(tablerow2);  
                    document.getElementById("dynamicPerformance").appendChild(tablerow3);  
                   /* document.getElementById("dynamicPerformance").appendChild(tablerow4);  
                    document.getElementById("dynamicPerformance").appendChild(tablerow5);  */
                    document.getElementById("dynamicPerformance").appendChild(tablerow6);  

                     document.getElementById("dynamicPerformance").appendChild(tablerow7);  
                      document.getElementById("dynamicPerformance").appendChild(tablerow8);  


                   /* var tablecolum2=document.createElement('td');*/


                }
            }

         }

/*
         <tr>
                                            <td>Page</td>
                                            
                                            </tr>
                                            <tr>
                                            <td>Violations</td>
                                            </tr>
                                            <tr>
                                                  <td>Description</td>
                                            </tr>.
                                             <tr>
                                                  <td>Recommendations</th>
                                            </tr>
                                             <tr>
                                                  <td>Issues</td>
                                            </tr>
                                             <tr>
                                                     <td>Impact</td>
                                            </tr>
                                             <tr>
                                                <td>Guidelines</td>
                                            </tr>*/

              
        });

/* @author Immanuel Thomas */