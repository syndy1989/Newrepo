$.ajaxSetup({
    async: false
});  



$.getJSON("mobilelog.json", function(json) {

var hits=json;
var image,css,other,xhr,nwbmp,runtype,pagesize,html,js,font,video,cachenwbmp,cachepagesize;

for(var i=0;i<hits.length;i++)
{

runtype=hits[i].runtype;

    if(runtype.includes("withoutcache"))
    {
        image=hits[i].image;
        css=hits[i].css;
        other=hits[i].other;
        xhr=hits[i].xhr;
        nwbmp=hits[i].nwrequest;
        pagesize=hits[i].pagesize;
        video=hits[i].video;
        html=hits[i].html;
        js=hits[i].javaScript;
        font=hits[i].font;

    }


    else if(runtype.includes("withcache"))
    {
        
        cachenwbmp=hits[i].nwrequest;
        cachepagesize=hits[i].pagesize;
        
    }

}

s=(pagesize/(1024*1024)).toFixed(2);
 
/*document.getElementById("msize").innerHTML=s+"MB";
  document.getElementById("requestcount").innerHTML=nwbmp;*/

         });


 $.getJSON("log.json", function(json) {



var hits=json;
var image,css,other,xhr,nwbmp,runtype,pagesize,html,js,font,video,cachenwbmp,cachepagesize;

for(var i=0;i<hits.length;i++)
{

runtype=hits[i].runtype;

  if(runtype.includes("withoutcache"))
  {
    image=hits[i].image;
    css=hits[i].css;
    other=hits[i].other;
    xhr=hits[i].xhr;
    nwbmp=hits[i].nwrequest;
    pagesize=hits[i].pagesize;
    video=hits[i].video;
    html=hits[i].html;
    js=hits[i].javascript;
    font=hits[i].font;

  }


  else if(runtype.includes("withcache"))
  {
    
    cachenwbmp=hits[i].nwrequest;
    cachepagesize=hits[i].pagesize;
    
  }

}



var data = [{
    label: "html",
    data: html,
    color:"#04D215"
}, {
    label: "css",
    data: css,
    color:"#FCD202"
}, {
    label: "js",
    data: js,
    color:"#FF9E01"
},
{
    label: "Image",
    data: image,
    color:"#FF9E01"
},
{
    label: "XHR",
    data: xhr,
    color:"#04D215"
},
{
    label: "other",
    data: other,
    color:"#0D8ECF"
},
{
    label: "media",
    data: video,
    color:"#0D8ECF"
},
{
    label: "font",
    data: font,
    color:"#FF0F00"
}];

    $.plot('#pieflot', data, {
      series: {
          pie: {
              show: true,
                label: {
                    show: true,
                    formatter: function (label, series) {
                      var element = '<div style="font-size:15pt;text-align:center;padding:1px;color:' + series.color + ';">' + label + '<br/>' + series.data[0][1] + '</div>';
                        return element;
                  }
                }
            }
        },
        legend: {
         show: true
      }
  });

s=(pagesize/(1024*1024)).toFixed(2);
 
s1=(cachepagesize/(1024*1024)).toFixed(2);



/*document.getElementById("csize").innerHTML=s+"MB";
*/
/*$("#chartpagesize").empty();  

          Morris.Bar({
            element: 'chartpagesize',
            data: [
                   { y: 'Chrome Pagesize', a: s, b: s1 }
                   ],
            xkey: 'y',
            ykeys: ['a', 'b'],
            labels: ['Without Cache', 'With Cache'],
            barColors: ["#FF6600", "#0D52D1"]
          });


  $("#nw").empty();  

          Morris.Bar({
            element: 'nw',
            data: [
                   { y: 'Chrome Request', a: nwbmp, b: cachenwbmp}
                   ],
            xkey: 'y',
            ykeys: ['a', 'b'],
            labels: ['Without Cache', 'With Cache'],
            barColors: ["#FF6600", "#0D52D1"]
          });*/


        /*if(nwbmp<50)
                {
                document.getElementById('launchpanel2').className+= 'panel panel-green';
                }
                else if((nwbmp>50)&&(nwbmp<=60))
                {
                document.getElementById('launchpanel2').className+= 'panel panel-yellow';
            }
                else if(nwbmp>60)
                {
                document.getElementById('launchpanel2').className+= 'panel panel-red';
                }
                document.getElementById("mwcall").innerHTML=nwbmp;



               if(s<=1.5)
                {
                document.getElementById('launchpanel1').className+= 'panel panel-green';
                }
                else if((s>1.5)&&(s<=2))
                {
                document.getElementById('launchpanel1').className+= 'panel panel-yellow';
                }
                else if(s>2)
                {
                document.getElementById('launchpanel1').className+= 'panel panel-red';
                }
                document.getElementById("pagesize").innerHTML=s+"MB";


var chart = AmCharts.makeChart( "chartdiv", {
  "type": "pie",
  "theme": "dark",
  "dataProvider": [ {
    "PageProfiling": "CSS",
    "Values": css
  }, {
    "PageProfiling": "Font",
    "Values": font
  }, {
    "PageProfiling": "HTML",
    "Values": html
  }, {
    "PageProfiling": "Images",
    "Values": image
  }, {
    "PageProfiling": "JS",
    "Values": js
  }, {
    "PageProfiling": "Video",
    "Values": video
  }, {
    "PageProfiling": "Other",
    "Values": other
  }, {
    "PageProfiling": "XHR",
    "Values": xhr
  } ],
  "valueField": "Values",
  "titleField": "PageProfiling",
   "balloon":{
   "fixedPosition":true
  },
  "export": {
   "enabled": true,
    "menu": []
  }
  
} );*/

mobilelog(s,s1,nwbmp,cachenwbmp);

         });


 
  $.getJSON("performance.json", function(json) { 
      // alert("welcome")

      var hits=json;
     
     var ttfbyte,totalpage_time,domComplete,downloadTime,initialConnection,domLoadingtoComplete,domLoadingtoLoaded,cache_ttfbyte,cache_totalpage_time,cache_domComplete,cache_downloadTime,cache_initialConnection,cache_domLoadingtoComplete,cache_domLoadingtoLoaded;

        for(i=0;i<hits.length;i++){


          runtype=hits[i].runtype;

  if(runtype.includes("withoutcache"))
  {
        
        ttfbyte=hits[i].TimeToFirstByte;
        totalpage_time=hits[i].TotalLoadTime;
        domComplete=hits[i].DomComplete;
        downloadTime=hits[i].DownloadTime;
        initialConnection=hits[i].InitialConnection;
        domLoadingtoComplete=hits[i].DOMLoadingtoComplete;
        domLoadingtoLoaded=hits[i].DOMLoadingtoLoaded;
  
        
        }

        else if(runtype.includes("withcache")){

        cache_ttfbyte=hits[i].TimeToFirstByte;
        cache_totalpage_time=hits[i].TotalLoadTime;
        cache_domComplete=hits[i].DomComplete;
        cache_downloadTime=hits[i].DownloadTime;
        cache_initialConnection=hits[i].InitialConnection;
        cache_domLoadingtoComplete=hits[i].DOMLoadingtoComplete;
        cache_domLoadingtoLoaded=hits[i].DOMLoadingtoLoaded;

        }
       
      }

/*if(totalpage_time<3000)
                {
                document.getElementById('launchpanel').className+= 'panel panel-green';
                }
                else if((totalpage_time>3000)&&(totalpage_time<=5000))
                {
                document.getElementById('launchpanel').className+= 'panel panel-yellow';
            }
                else if(totalpage_time>5000)
                {
                document.getElementById('launchpanel').className+= 'panel panel-red';
                }
                document.getElementById("pagetime").innerHTML=totalpage_time+"ms";
*/


 mobileperformance(ttfbyte,totalpage_time,domComplete,downloadTime,initialConnection,domLoadingtoComplete,domLoadingtoLoaded,cache_ttfbyte,cache_totalpage_time,cache_domComplete,cache_downloadTime,cache_initialConnection,cache_domLoadingtoComplete,cache_domLoadingtoLoaded);

});


  

function mobileperformance(ttfbyte,totalpage_time,domComplete,downloadTime,initialConnection,domLoadingtoComplete,domLoadingtoLoaded,cache_ttfbyte,cache_totalpage_time,cache_domComplete,cache_downloadTime,cache_initialConnection,cache_domLoadingtoComplete,cache_domLoadingtoLoaded){
$.getJSON("mobileperformance.json", function(json) { 

    var mobiledata=json;
    
    var mobileruntype,mobilettfbyte,mobiletotalpage_time,mobiledomComplete,mobiledownloadTime,mobileinitialConnection,mobiledomLoadingtoComplete,mobiledomLoadingtoLoaded,mobilecache_ttfbyte,mobilecache_totalpage_time,mobilecache_domComplete,mobilecache_downloadTime,mobilecache_initialConnection,mobilecache_domLoadingtoComplete,mobilecache_domLoadingtoLoaded;

 for(i=0;i<mobiledata.length;i++){


          mobileruntype=mobiledata[i].runtype;

  if(mobileruntype.includes("withoutcache"))
  {
        
        mobilettfbyte=mobiledata[i].TimeToFirstByte;
        mobiletotalpage_time=mobiledata[i].TotalLoadTime;
        mobiledomComplete=mobiledata[i].DomComplete;
        mobiledownloadTime=mobiledata[i].DownloadTime;
        mobileinitialConnection=mobiledata[i].InitialConnection;
        mobiledomLoadingtoComplete=mobiledata[i].DOMLoadingtoComplete;
        mobiledomLoadingtoLoaded=mobiledata[i].DOMLoadingtoLoaded;
  
        
        }

        else if(mobileruntype.includes("withcache")){

        mobilecache_ttfbyte=mobiledata[i].TimeToFirstByte;
        mobilecache_totalpage_time=mobiledata[i].TotalLoadTime;
        mobilecache_domComplete=mobiledata[i].DomComplete;
        mobilecache_downloadTime=mobiledata[i].DownloadTime;
        mobilecache_initialConnection=mobiledata[i].InitialConnection;
        mobilecache_domLoadingtoComplete=mobiledata[i].DOMLoadingtoComplete;
        mobilecache_domLoadingtoLoaded=mobiledata[i].DOMLoadingtoLoaded;

        }
       
      }


/*var data = [
      { y: 'Chrome', a:cache_totalpage_time},
      { y: 'Mobile', b: mobilecache_totalpage_time}
    ],
    config = {
      data: data,
      xkey: 'y',
      ykeys: ['a','b'],
      labels: ['Chrome','Mobile'],
      fillOpacity: 0.6,
      hideHover: 'false',
      stacked:'true',
      resize: true,
      labelTop: true,
     barColors: ['#ff6600','#67b7dc']
  };


config.element = 'chartcache';
Morris.Bar(config);*///first chart end
//second chart start
 var data = [
      { y: 'Chrome ', a:cache_initialConnection,b:cache_ttfbyte,c:cache_downloadTime,d:cache_domLoadingtoLoaded,e:cache_domLoadingtoComplete},
     /* { y: 'Mobile', a:mobilecache_initialConnection,b:mobilecache_ttfbyte,c:mobilecache_downloadTime,d:mobilecache_domLoadingtoLoaded,e:mobilecache_domLoadingtoComplete}*/
    ],
    config = {
      data: data,
      xkey: 'y',
      ykeys: ['a','b','c','d','e'],
      labels: ['InitialConnection','TimeToFirstByte','downloadTime','domLoadingtoLoaded','domLoadingtoComplete'],
      fillOpacity: 0.6,
     hideHover: false,
       barSize: 70,
      stacked:'true',
      resize: 'true',
      labelTop: 'true',
     barColors: ['#B0DE09','#0D52D1','#FF9E01','#0D8ECF','#FF6600'],
  };


config.element = 'chartresponsecache';
Morris.Bar(config);


 var data = [
     /* { y: 'Chrome ', a:cache_initialConnection,b:cache_ttfbyte,c:cache_downloadTime,d:cache_domLoadingtoLoaded,e:cache_domLoadingtoComplete},*/
      { y: 'Mobile', a:mobilecache_initialConnection,b:mobilecache_ttfbyte,c:mobilecache_downloadTime,d:mobilecache_domLoadingtoLoaded,e:mobilecache_domLoadingtoComplete}
    ],
    config = {
      data: data,
      xkey: 'y',
      ykeys: ['a','b','c','d','e'],
      labels: ['InitialConnection','TimeToFirstByte','downloadTime','domLoadingtoLoaded','domLoadingtoComplete'],
      fillOpacity: 0.6,
     hideHover: false,
       barSize: 70,
      stacked:'true',
      resize: 'true',
      labelTop: 'true',
     barColors: ['#B0DE09','#0D52D1','#FF9E01','#0D8ECF','#FF6600'],
  };


config.element = 'chartresponsecache2';
Morris.Bar(config);



/*var data = [
         { y: 'Chrome', a:totalpage_time},
      { y: 'Mobile', b: mobiletotalpage_time}
    ],
    config = {
      data: data,
      xkey: 'y',
      ykeys: ['a','b'],
       labels: ['Chrome', 'Mobile Browser'],
      fillOpacity: 0.6,
      hideHover: 'false',
      stacked:'true',
      resize: true,
     barColors: ['#ff0f00','#04d215']
  };


config.element = 'chart';
Morris.Bar(config);*/

$("#chart").empty();  

          Morris.Bar({
            element: 'chart',
            data: [
                   { y: 'PageLoadTime', a: totalpage_time+"ms", b: mobiletotalpage_time+"ms" }
                   ],
            xkey: 'y',
            barSize: 70,
            ykeys: ['a', 'b'],
            labels: ['Chrome', 'Mobile'],
            barColors: ["#FF6600", "#0D52D1"]
          });



          $("#chartcache").empty();  

          Morris.Bar({
            element: 'chartcache',
            data: [
                   { y: 'PageLoadTime', a: cache_totalpage_time+"ms", b: mobilecache_totalpage_time+"ms" }
                   ],
            xkey: 'y',
             barSize: 70,
            ykeys: ['a', 'b'],
            labels: ['Chrome', 'Mobile'],
            barColors: ["#FF6600", "#0D52D1"]
          });


//second chart
 var data = [
      { y: 'Chrome ', a:initialConnection,b:ttfbyte,c:downloadTime,d:domLoadingtoLoaded,e:domLoadingtoComplete},
     /* { y: 'Mobile', a:mobileinitialConnection,b:mobilettfbyte,c:mobiledownloadTime,d:mobiledomLoadingtoLoaded,e:mobilecache_domLoadingtoComplete}*/
    ],
    config = {
      data: data,
      xkey: 'y',
      ykeys: ['a','b','c','d','e'],
      labels: ['InitialConnection','TimeToFirstByte','downloadTime','domLoadingtoLoaded','domLoadingtoComplete'],
      fillOpacity: 0.6,
      /*hideHover: false,*/
     /* ymax:50000,*/
      ymin:0,
       barSize: 70,
      stacked:'true',
      resize: true,
     barColors: ['#B0DE09','#0D52D1','#FF9E01','#0D8ECF','#FF6600'],//#ff0f00','#04d215','blue','#ff6600','#67b7dc'
  };


config.element = 'chartresponse';
Morris.Bar(config);

$.ajaxSetup({
    async: false
});  

var data = [
     /* { y: 'Chrome ', a:initialConnection,b:ttfbyte,c:downloadTime,d:domLoadingtoLoaded,e:domLoadingtoComplete},*/
      { y: 'Mobile', a:mobileinitialConnection,b:mobilettfbyte,c:mobiledownloadTime,d:mobiledomLoadingtoLoaded,e:mobilecache_domLoadingtoComplete}
    ],
    config = {
      data: data,
      xkey: 'y',
      ykeys: ['a','b','c','d','e'],
      labels: ['InitialConnection','TimeToFirstByte','downloadTime','domLoadingtoLoaded','domLoadingtoComplete'],
      fillOpacity: 0.6,
      /*hideHover: false,*/
      /*ymax:50000,*/
      ymin:0,
       barSize: 70,
      stacked:'true',
      resize: true,
     barColors: ['#B0DE09','#0D52D1','#FF9E01','#0D8ECF','#FF6600'],//#ff0f00','#04d215','blue','#ff6600','#67b7dc'
  };


config.element = 'chartresponse2';
Morris.Bar(config);

  });





}   


/*$.getJSON("lighthouse.json", function(json) 
{ 
    var hits=json.rules;
    var render,css,cssrules,javascript,text;
    for(var i=0;i<hits.length;i++)
            {  
    var eachobj=hits[i];
  //  alert(JSON.stringify(eachobj));
    var eachobjkeys=Object.keys(eachobj);
    eachobjkeys.forEach(function (key)
                         {
                            var row=document.createElement('h3');
                            row.setAttribute("style","color:#3c9adc");
                            var keys=key.replace(/-/g,"&nbsp;");
                            row.innerHTML=keys;

                            var ul=document.createElement('ul');
                            var li1=document.createElement('li'); 
                            li1.setAttribute("style","color:#808080"); 
                            /*li1.setAttribute("style","letter-spacing: 0");    
                            li1.setAttribute("style","font-family: Arial,sans-serif;"); */      
                            /*var li2=document.createElement('li')
                            li2.setAttribute("style","color:#808080");  
                            var li3=document.createElement('li');
                            li3.setAttribute("style","color:#808080");  
                           
                            var eachusecase=eachobj[eachobjkeys];
                            var eachusecasekeys=  Object.keys(eachusecase);
                            var urlcount=eachusecase["urlcount"];
                            // alert(urlcount)
                            li1.innerHTML="UrlCount&nbsp; :&nbsp;"+urlcount;
                            if(urlcount!=0)
                            {
                              li2.innerHTML="Already&nbsp;Implemented";
                            }
                           else
                            {
                            li2.innerHTML="Needs&nbsp;Improvement";
                            }
                        li3.innerHTML=eachusecase["description"];
                         ul.appendChild(li1);
                            ul.appendChild(li2);
                            ul.appendChild(li3);
                        row.appendChild(ul);

                        document.getElementById("rules").appendChild(row);
                           });
              }
});*/


$.getJSON("lighthouse.json", function(json) 
{ 
    var hits=json.rules;
    var render,css,cssrules,javascript,text;
    var urllist =[];
    for(var i=0;i<hits.length;i++)
            {  
    var eachobj=hits[i];
  //  alert(JSON.stringify(eachobj));
    var eachobjkeys=Object.keys(eachobj);
    eachobjkeys.forEach(function (key)
                         {
                            var row=document.createElement('h3');
                            row.setAttribute("style","color:#3c9adc");
                            var keys=key.replace(/-/g,"&nbsp;");
                            row.innerHTML=keys;

                            var ul=document.createElement('ul');
                            ul.setAttribute("style","font-weight:0;line-height:0,letter-spacing: 0;");
                            var li1=document.createElement('li'); 
                            li1.setAttribute("style","color:#000000"); 
                            /*li1.setAttribute("style","letter-spacing: 0");    
                            li1.setAttribute("style","font-family: Arial,sans-serif;"); */      
                            var li2=document.createElement('li')
                            li2.setAttribute("style","color:#000000");  
                            var ul1=document.createElement('ul');
                            //ul1.setAttribute("style","text-decoration: underline;");
                            ul1.setAttribute("style","color:#3c9adc");  
                            ul1.innerHTML="Url List&nbsp; :&nbsp;";
                           
                            var eachusecase=eachobj[eachobjkeys];
                            var eachusecasekeys=  Object.keys(eachusecase);
                            var urlcount=eachusecase["urlcount"];
                              urllist=eachusecase["url"];
                              //alert(urllist.length)

                               if(!urllist.includes("No URL found"))
                               {
                           for (var j = 0; j < urllist.length; j++) {
                             //alert(urllist[i]);
                            //Do something
                                
                         //   if(urllist.i)
                              
                                   var li3=document.createElement('li')
                            li3.setAttribute("style","color:#000000"); 
                                
                            li3.innerText=urllist[j];
                            ul1.appendChild(li3);
 

                        }
                    }
                    else{
                        var li3=document.createElement('li')
                            li3.setAttribute("style","color:#000000"); 
                                
                            
                        li3.innerHTML="No url found";
                            ul1.appendChild(li3);

                    }
                            
                            if(urlcount!=0)
                            {
                              li2.innerHTML="Needs&nbsp;Improvement";
                            }
                           else
                            {
                            li2.innerHTML="Already&nbsp;Implemented";
                            }
                        li1.innerHTML=eachusecase["description"];

                         ul.appendChild(li1);
                            ul.appendChild(li2);
                             //ul.appendChild(li3);
                            ul.appendChild(ul1);
                        row.appendChild(ul);

                        document.getElementById("rules").appendChild(row);
                           });
              }
});



function mobilelog(s,s1,nwbmp,cachenwbmp){
$.getJSON("mobilelog.json", function(json) {



var hits=json;
var image,css,other,xhr,mobilenwbmp,runtype,pagesize,html,js,font,video,mobilecachenwbmp,cachepagesize;
var s1mobile,smobile;

for(var i=0;i<hits.length;i++)
{

runtype=hits[i].runtype;

  if(runtype.includes("withoutcache"))
  {
    image=hits[i].image;
    css=hits[i].css;
    other=hits[i].other;
    xhr=hits[i].xhr;
    mobilenwbmp=hits[i].nwrequest;
    pagesize=hits[i].pagesize;
    video=hits[i].video;
    html=hits[i].html;
    js=hits[i].javascript;
    font=hits[i].font;

  }


  else if(runtype.includes("withcache"))
  {
    
    mobilecachenwbmp=hits[i].nwrequest;
    cachepagesize=hits[i].pagesize;
    
  }

}

var data = [{
    label: "html",
    data: html,
    color:"#B0DE09"
}, {
    label: "css",
    data: css,
    color:"#04D215"
}, {
    label: "js",
    data: js,
    color:"#FCD202"
},
{
    label: "Image",
    data: image,
    color:"#FF9E01"
},
{
    label: "XHR",
    data: xhr,
    color:"#04D215"
},
{
    label: "other",
    data: other,
    color:"#0D8ECF"
},
{
    label: "media",
    data: video,
    color:"#2A0CD0"
},
{
    label: "font",
    data: font,
    color:"#FF0F00"
}];

    $.plot('#pieflotmobile', data, {
      series: {
          pie: {
              show: true,
                label: {
                    show: true,
                    formatter: function (label, series) {
                      var element = '<div style="font-size:15pt;text-align:center;padding:1px;color:' + series.color + ';">' + label + '<br/>' + series.data[0][1] + '</div>';
                        return element;
                  }
                }
            }
        },
        legend: {
         show: true
      }
  });

smobile=(pagesize/(1024*1024)).toFixed(2);
 
s1mobile=(cachepagesize/(1024*1024)).toFixed(2);



 $("#chartsize").empty();  

          Morris.Bar({
            element: 'chartsize',
            data: [
                   { y: 'Pagesize', a: s, b: s1, c:smobile ,d:s1mobile}
                   ],
            xkey: 'y',
           /* ymax: 50,
            ymin: 0,*/
             barSize: 70,
            ykeys: ['a', 'b','c','d'],
            labels: ['Chrome w/o Cache', 'Chrome With Cache', 'Mobile w/o Cache','Mobile with Cache'],
            barColors: ["#FF6600", "#0D52D1"]
          });



          $("#nw").empty();  

          Morris.Bar({
            element: 'nw',
            data: [
                   { y: 'n/w Request', a: nwbmp, b: cachenwbmp ,c:mobilenwbmp,d:mobilecachenwbmp}
                   ],
            xkey: 'y',
              barSize: 70,
            ykeys: ['a', 'b','c','d'],
            labels: ['Chrome With Cache', 'Chrome w/o Cache','Mobile with cache','Mobile w/o cache'],
            barColors: ["#FF6600", "#0D52D1","#FF6600", "#0D52D1"]
          });




         });
}