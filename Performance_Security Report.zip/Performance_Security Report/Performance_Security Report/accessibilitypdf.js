$.getJSON("donut.json", function(json) {
            var hits=json.rundetails;
            //alert(JSON.stringify(hits));
           //alert(hits);
var critical,serious,minor,moderate;
var physical,hearing,cognitive,visua;
           for(var i=0;i<json.rundetails.length;i++){

             critical=json.rundetails[i].critical;
             serious=json.rundetails[i].serious;
             minor=json.rundetails[i].minor;
             moderate=json.rundetails[i].moderate;
             physical=json.rundetails[i].physical;
             cognitive=json.rundetails[i].cognitive;
             hearing=json.rundetails[i].hearing;
             visual=json.rundetails[i].visual;
           }
             
             var data = [
      { y: 'Critical', a:critical},
      { y: 'Serious', b: serious},
      { y: 'Moderate',   c: moderate},
      { y: 'Minor',  d: minor}
    ],
    config = {
      data: data,
      xkey: 'y',
      ykeys: ['a','b','c','d'],
      labels: ['Critical', 'Serious','Moderate','Minor'],
      fillOpacity: 0.6,
       barSize: 70,
      ymin:0,
      hideHover: 'false',
      stacked:'true',
      resize: true,
       barWidth: '1200px',
     barColors: ['#ff6600','#04d215','#ff0f00','#67b7dc']
  };


config.element = 'chartpagesize';
Morris.Bar(config);


var data = [
      { y: 'Visually Impaired', a:visual},
      { y: 'Physical Disability', b: physical},
      { y: 'Hearing Impaired',   c: hearing},
      { y: 'Cognitive Limitations',  d: cognitive}
    ],
    config = {
      data: data,
      xkey: 'y',
      ykeys: ['a','b','c','d'],
       barSize: 70,
      ymin:0,
      labels: ['Visually Impaired', 'Physical Disability','Hearing Impaired','Cognitive Limitations'],
      fillOpacity: 0.6,
      hideHover: true,
      stacked:'true',
      resize: true,
       barWidth: '1200px',
     barColors: ['#ff6600','#04d215','#ff0f00','#67b7dc']
  };


config.element = 'defect';
Morris.Bar(config);
 
     
});

$.getJSON("violations.json", function(json) {
       
         var issuePages=json;
         for(var i=0;i<issuePages.length;i++)
         {
            var eachPage=issuePages[i];
            var pageName;
            for (var j = 0; j < eachPage.length; j++) {
                
                if(eachPage[j].hasOwnProperty('pagename'))
                {
                    pageName=eachPage[j].pagename;
                }
            }


              var tablerow1=document.createElement('tr');
                
                    var tablecolum1=document.createElement('td');
                    var tablecolum2=document.createElement('td');
                    var tablecolum3=document.createElement('td');
                     var tablecolum4=document.createElement('td');
                    tablecolum1.setAttribute("style","font-weight: bold;color:#3c9adc");
                    tablecolum1.innerHTML="Guidelines Violated";
                    tablecolum2.setAttribute("style","font-weight: bold;color:#3c9adc");
                     tablecolum2.innerHTML="Violation Scenario";
                      tablecolum3.setAttribute("style","font-weight: bold;color:#3c9adc;width:10%");
                      tablecolum3.innerHTML="Impact";
                       tablecolum4.setAttribute("style","font-weight: bold;color:#3c9adc;width:20%");
                      tablecolum4.innerHTML="Impacted Users";

                      tablerow1.appendChild(tablecolum1);
                    tablerow1.appendChild(tablecolum2);
                    tablerow1.appendChild(tablecolum3);
                    tablerow1.appendChild(tablecolum4);

                     document.getElementById("violations").appendChild(tablerow1);  


            for (var j = 0; j < eachPage.length; j++) {
                
                if(eachPage[j].hasOwnProperty('pagename'))
                {
                    continue;
                }
                else
                {

                   //window.alert(JSON.stringify(eachPage[j]));

                  




                    var tablerow2=document.createElement('tr');
                
                    var tablecolum4=document.createElement('td');
                    var tablecolum5=document.createElement('td');
                    var tablecolum6=document.createElement('td');
                    var tablecolum7=document.createElement('td');

                    tablecolum4.innerHTML=eachPage[j].Guidelines;
            
                     tablecolum5.innerText=eachPage[j].Help;
                    tablecolum6.innerText=eachPage[j].impact;

                    tablecolum7.innerText=eachPage[j].DisabilityType;
                

                      tablerow2.appendChild(tablecolum4);
                    tablerow2.appendChild(tablecolum5);
                    tablerow2.appendChild(tablecolum6);
                     tablerow2.appendChild(tablecolum7);


                    


                   


                   
                    document.getElementById("violations").appendChild(tablerow2);  
                    

                   /* var tablecolum2=document.createElement('td');*/


                }
            }

         }

/*
         <tr>
                                            <td>Page</td>
                                            
                                            </tr>
                                            <tr>
                                            <td>Violations</td>
                                            </tr>
                                            <tr>
                                                  <td>Description</td>
                                            </tr>.
                                             <tr>
                                                  <td>Recommendations</th>
                                            </tr>
                                             <tr>
                                                  <td>Issues</td>
                                            </tr>
                                             <tr>
                                                     <td>Impact</td>
                                            </tr>
                                             <tr>
                                                <td>Guidelines</td>
                                            </tr>*/

              
        });


/*$.getJSON("violations.json", function(json) { 

var hits=json;
//alert(hits.length)
var render,css,cssrules,javascript,text;

var row=document.createElement('h3');
row.setAttribute("style","color:#3c9adc");
row.innerHTML="Impact - Critical";

var row1=document.createElement('h3');
row1.setAttribute("style","color:#3c9adc");
row1.innerHTML="Impact - Serious";

var row2=document.createElement('h3');
row2.setAttribute("style","color:#3c9adc");
row2.innerHTML="Impact - Moderate";

var row3=document.createElement('h3');
row3.setAttribute("style","color:#3c9adc");
row3.innerHTML="Impact - Minor";

for(var i=0;i<hits.length;i++)
            {  
    var eachobj=hits[i];

    var eachobjkeys=Object.keys(eachobj);

 for(var j=0;j<eachobjkeys.length;j++)
 {
  var uniqueobj=eachobj[j];
  var uniquekeys=Object.keys(uniqueobj);

 var impact=uniqueobj["impact"];

 if(impact=="critical")
 {
                        var ul=document.createElement('ul');
                        var li1=document.createElement('li'); 
                        li1.setAttribute("style","color:#808080");       
                        var li2=document.createElement('li')
                        li2.setAttribute("style","color:#808080");  
                        var li3=document.createElement('li');
                        li3.setAttribute("style","color:#808080");  

                      

                  
                        li1.innerText="Violation :"+uniqueobj["Help"];

                        li2.innerText="Description :"+uniqueobj["description"];

                         li3.innerText="Guidelines :"+uniqueobj["Guidelines"];
                    
                       ul.appendChild(li1);
                       ul.appendChild(li2);
                       ul.appendChild(li3);
                       
                       row.appendChild(ul);
                     }

                     if(impact=="serious")
              {
                        var ul=document.createElement('ul');
                        var li1=document.createElement('li'); 
                        li1.setAttribute("style","color:#808080");       
                        var li2=document.createElement('li')
                        li2.setAttribute("style","color:#808080");  
                        var li3=document.createElement('li');
                        li3.setAttribute("style","color:#808080");  
                                       
                        li1.innerText="Violation :"+uniqueobj["Help"];

                        li2.innerText="Description :"+uniqueobj["description"];

                        li3.innerText="Guidelines :"+uniqueobj["Guidelines"];

                       ul.appendChild(li1);
                       ul.appendChild(li2);
                       ul.appendChild(li3);
                       
                       row1.appendChild(ul);

                     }

                     if(impact=="moderate")
      {
                        var ul=document.createElement('ul');
                        var li1=document.createElement('li'); 
                        li1.setAttribute("style","color:#808080");       
                        var li2=document.createElement('li')
                        li2.setAttribute("style","color:#808080");  
                        var li3=document.createElement('li');
                        li3.setAttribute("style","color:#808080"); 

                        li1.innerText="Violation :"+uniqueobj["Help"];

                        li2.innerText="Description :"+uniqueobj["description"];

                        li3.innerText="Guidelines :"+uniqueobj["Guidelines"];

                        ul.appendChild(li1);
                        ul.appendChild(li2);
                        ul.appendChild(li3);
                        row2.appendChild(ul);

                     }

                     if(impact=="minor")
    {
                        var ul=document.createElement('ul');
                        var li1=document.createElement('li'); 
                        li1.setAttribute("style","color:#808080");       
                        var li2=document.createElement('li')
                        li2.setAttribute("style","color:#808080");  
                        var li3=document.createElement('li');                       
                        li3.setAttribute("style","color:#808080");  
                        li1.innerText="Violation :"+uniqueobj["Help"];

                        li2.innerText="Description :"+uniqueobj["description"];

                        li3.innerText="Guidelines :"+uniqueobj["Guidelines"];

                       ul.appendChild(li1);
                       ul.appendChild(li2);
                       ul.appendChild(li3);
                       

                       row3.appendChild(ul);

                     }

                      


}

}

document.getElementById("violations").appendChild(row);
document.getElementById("violations").appendChild(row1);
document.getElementById("violations").appendChild(row2);
document.getElementById("violations").appendChild(row3);

});*/


       
