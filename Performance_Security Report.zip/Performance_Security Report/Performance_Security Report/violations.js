$.getJSON("violations.json", function(json) {
       
         var issuePages=json;
         for(var i=0;i<issuePages.length;i++)
         {
            var eachPage=issuePages[i];
            var pageName;
            for (var j = 0; j < eachPage.length; j++) {
                
                if(eachPage[j].hasOwnProperty('pagename'))
                {
                    pageName=eachPage[j].pagename;
                }
            }


              var tablerow1=document.createElement('tr');
                
                    var tablecolum1=document.createElement('td');
                    var tablecolum2=document.createElement('td');
                    var tablecolum3=document.createElement('td');
                     var tablecolum4=document.createElement('td');
                    tablecolum1.setAttribute("style","font-weight: bold;color:#3c9adc;width:60%");
                    tablecolum1.innerHTML="Guidelines Violated";
                    tablecolum2.setAttribute("style","font-weight: bold;color:#3c9adc;");
                     tablecolum2.innerHTML="Violation Scenario";
                      tablecolum3.setAttribute("style","font-weight: bold;color:#3c9adc;width:10%");
                      tablecolum3.innerHTML="Impact";
                       tablecolum4.setAttribute("style","font-weight: bold;color:#3c9adc;width:20%");
                      tablecolum4.innerHTML="Impacted Users";

                      tablerow1.appendChild(tablecolum1);
                    tablerow1.appendChild(tablecolum2);
                    tablerow1.appendChild(tablecolum3);
                    tablerow1.appendChild(tablecolum4);

                     document.getElementById("dynamicPerformance").appendChild(tablerow1);  


            for (var j = 0; j < eachPage.length; j++) {
                
                if(eachPage[j].hasOwnProperty('pagename'))
                {
                    continue;
                }
                else
                {

                   //window.alert(JSON.stringify(eachPage[j]));

                  




                    var tablerow2=document.createElement('tr');
                
                    var tablecolum4=document.createElement('td');
                    var tablecolum5=document.createElement('td');
                    var tablecolum6=document.createElement('td');
                    var tablecolum7=document.createElement('td');

                    tablecolum4.innerHTML=eachPage[j].Guidelines;
            
                     tablecolum5.innerText=eachPage[j].Help;
                    tablecolum6.innerText=eachPage[j].impact;

                    tablecolum7.innerText=eachPage[j].DisabilityType;
                

                      tablerow2.appendChild(tablecolum4);
                    tablerow2.appendChild(tablecolum5);
                    tablerow2.appendChild(tablecolum6);
                     tablerow2.appendChild(tablecolum7);


                    


                   


                   
                    document.getElementById("dynamicPerformance").appendChild(tablerow2);  
                    

                   /* var tablecolum2=document.createElement('td');*/


                }
            }

         }

/*
         <tr>
                                            <td>Page</td>
                                            
                                            </tr>
                                            <tr>
                                            <td>Violations</td>
                                            </tr>
                                            <tr>
                                                  <td>Description</td>
                                            </tr>.
                                             <tr>
                                                  <td>Recommendations</th>
                                            </tr>
                                             <tr>
                                                  <td>Issues</td>
                                            </tr>
                                             <tr>
                                                     <td>Impact</td>
                                            </tr>
                                             <tr>
                                                <td>Guidelines</td>
                                            </tr>*/

              
        });
