 $.getJSON("url.json", function(json) {

var hits=json;
//alert(JSON.stringify(hits));
document.getElementById("url").innerHTML =json.URL;
    });

$.getJSON("reporttime.json", function(json) {

var hits=json;
//alert(JSON.stringify(hits));
document.getElementById("report").innerHTML =json.datetime;
    });