To view the Accessibility Dashboard HTML Report:
************************************************

Open the file accessibility.html through firefox