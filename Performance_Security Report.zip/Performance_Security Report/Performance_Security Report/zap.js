  $.getJSON("zap.json", function(json) {
            var hits=json.securitydetails;
            //alert(JSON.stringify(hits));
           //alert(hits);

           for(var i=0;i<json.securitydetails.length;i++){

            var High =json.securitydetails[i].High;
            var Medium=json.securitydetails[i].Medium;
            var Low=json.securitydetails[i].Low;
            var info=json.securitydetails[i].info;
           }
 
        
$("#chartzap").empty();  

          Morris.Bar({
            element: 'chart',
            data: [
                   { y: 'Severity Counts', a: High, b: Medium, c: Low,d: info }
                   ],
            xkey: 'y',
            ykeys: ['a', 'b', 'c', 'd'],
            labels: ['High', 'Medium' , 'Low', 'info' ],
            barColors: ["#800000", "#FF0000","#40FF00","#21610B"]
          });

 
});
         
$.getJSON("url.json", function(json) {

var hits=json;
//alert(JSON.stringify(hits));
document.getElementById("myHeader").innerHTML ="<a href=>"+json.URL+"</a>" ;
    });

$.getJSON("zapraw.json", function(json) {

  var hits=json.instances;

  var instance,method,url,params,solution,alert1,riskdes,descr,otherinfo;
  
for(var i=0; i< hits.length;i++)

{

instance=hits[i].Instances;
method=hits[i].Method;
url=hits[i].URL;
params=hits[i].Parameter;
solution=hits[i].Solution;
alert1=hits[i].alert;
riskdes=hits[i].riskdesc;
descr=hits[i].Description;
otherinfo=hits[i].OtherInformation;


 /*document.getElementById("riskdes").innerHTML=riskdes;
  document.getElementById("alert").innerHTML=alert1;
  document.getElementById("Description").innerHTML=descr;
  document.getElementById("URL").innerHTML=url;
  document.getElementById("Method").innerHTML=method;
  document.getElementById("Parameter").innerHTML=params;
  document.getElementById("Instances").innerHTML=instance;
  document.getElementById("Solution").innerHTML=solution;*/

                    if(riskdes.includes("High")){
            riskdes="High";
          }
          else if(riskdes.includes("Medium (Medium)")){
            riskdes="Medium";
          }
          else if(riskdes.includes("Low (Medium)")){
            riskdes="Low";
          }


                    var tablerow0=document.createElement('tr');
                
                    var tablecolum1=document.createElement('th');
                    var tablecolum2=document.createElement('th');

                    tablecolum1.innerHTML=riskdes.bold();
                     tablecolum2.innerHTML=(alert1).bold();

                      tablerow0.appendChild(tablecolum1);
                    tablerow0.appendChild(tablecolum2);



                    var tablerow1=document.createElement('tr');
                
                    var tablecolum3=document.createElement('td');
                    var tablecolum4=document.createElement('td');

                    tablecolum3.innerHTML="Description";
                     tablecolum4.innerHTML=descr;

                      tablerow1.appendChild(tablecolum3);
                    tablerow1.appendChild(tablecolum4);

                  



                    var tablerow2=document.createElement('tr');
                
                    var tablecolum5=document.createElement('td');
                    var tablecolum6=document.createElement('td');

                    tablecolum5.innerHTML="URL";
                    tablecolum6.innerHTML=url;

                      tablerow2.appendChild(tablecolum5);
                    tablerow2.appendChild(tablecolum6);



                    var tablerow3=document.createElement('tr');
                
                    var tablecolum7=document.createElement('td');
                    var tablecolum8=document.createElement('td');

                    tablecolum7.innerHTML="Method";
                     tablecolum8.innerText=method;

                      tablerow3.appendChild(tablecolum7);
                    tablerow3.appendChild(tablecolum8);




                    var tablerow4=document.createElement('tr');
                
                    var tablecolum9=document.createElement('td');
                    var tablecolum10=document.createElement('td');

                    tablecolum9.innerHTML="Parameter";
                     tablecolum10.innerText=params;

                      tablerow4.appendChild(tablecolum9);
                    tablerow4.appendChild(tablecolum10);




                    var tablerow5=document.createElement('tr');
                
                    var tablecolum11=document.createElement('td');
                    var tablecolum12=document.createElement('td');

                    tablecolum11.innerHTML="Instances";
                     tablecolum12.innerText=instance;

                      tablerow5.appendChild(tablecolum11);
                    tablerow5.appendChild(tablecolum12);



                    var tablerow6=document.createElement('tr');
                
                    var tablecolum13=document.createElement('td');
                    var tablecolum14=document.createElement('td');

                    tablecolum13.innerHTML="Solution";
                     tablecolum14.innerHTML=solution;

                      tablerow6.appendChild(tablecolum13);
                    tablerow6.appendChild(tablecolum14);


                    var tablerow7=document.createElement('tr');
                
                    var tablecolum15=document.createElement('td');
                    var tablecolum16=document.createElement('td');

                    tablecolum15.innerHTML="OtherInformation";
                     tablecolum16.innerHTML=otherinfo;

                      tablerow7.appendChild(tablecolum15);
                    tablerow7.appendChild(tablecolum16);

                    var tablerow8=document.createElement('tr');
                
                    var tablecolum15=document.createElement('td');
                    var tablecolum16=document.createElement('td');

                    tablecolum15.innerHTML="</br>";
                     tablecolum16.innerHTML="</br>";

                      tablerow8.appendChild(tablecolum15);
                    tablerow8.appendChild(tablecolum16);




                  

                    document.getElementById("zapcompare").appendChild(tablerow0); 
                    document.getElementById("zapcompare").appendChild(tablerow1);  
                    document.getElementById("zapcompare").appendChild(tablerow2);  
                    document.getElementById("zapcompare").appendChild(tablerow3);  
                    document.getElementById("zapcompare").appendChild(tablerow4);  
                    document.getElementById("zapcompare").appendChild(tablerow5);  
                    document.getElementById("zapcompare").appendChild(tablerow6);  
                    document.getElementById("zapcompare").appendChild(tablerow7); 
                    document.getElementById("zapcompare").appendChild(tablerow8); 


}




                     /*document.getElementById("dynamicPerformance").appendChild(tablerow7);  
                    document.getElementById("dynamicPerformance").appendChild(tablerow8);  
*/



 });