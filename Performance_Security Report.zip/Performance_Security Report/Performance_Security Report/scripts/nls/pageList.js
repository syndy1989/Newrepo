/* See license.txt for terms of usage */

define(
{
    "root": {
        "column.label.index": "Index",
        "column.label.url": "URL",
        "column.label.status": "Status",
        "column.label.type": "Type",
        "column.label.domain": "Domain",
        "column.label.serverIPAddress": "Server IP Address",
        "column.label.connection": "Connection",
        "column.label.size": "Size",
        "column.label.timeline": "Timeline",
        "action.label.Reset": "Reset"
    }
});
