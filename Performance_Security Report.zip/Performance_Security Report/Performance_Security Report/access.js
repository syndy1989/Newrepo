
$.ajaxSetup({
    async: false
});  


$.getJSON("donut.json", function(json) {
            var hits=json.rundetails;
            //alert(JSON.stringify(hits));
           //alert(json.rundetails.length);

           for(var i=0;i<json.rundetails.length;i++){

           	var critical=json.rundetails[i].critical;
           	var serious=json.rundetails[i].serious;
           	var minor=json.rundetails[i].minor;
           	var moderate=json.rundetails[i].moderate;
           	var pagename=json.rundetails[i].pagename;

           	var tablerow=document.createElement('tr');
                
                    var tablecolum1=document.createElement('td');
                    var tablecolum2=document.createElement('td');
                    var tablecolum3=document.createElement('td');
                    var tablecolum4=document.createElement('td');
                     var tablecolum5=document.createElement('td');

                    tablecolum1.innerHTML=pagename;
                    tablecolum2.innerHTML=critical;
                     tablecolum3.innerHTML=serious;
                     tablecolum4.innerHTML=moderate;

                    tablecolum5.innerHTML=minor;

                      tablerow.appendChild(tablecolum1);
                    tablerow.appendChild(tablecolum2);
                    tablerow.appendChild(tablecolum3);
                    tablerow.appendChild(tablecolum4);
                     tablerow.appendChild(tablecolum5);

                    /* document.getElementById("accessibilitycompare").appendChild(tablerow); */ 
           }
 
        
$("#chart").empty();  

          Morris.Bar({
            element: 'chart',
            data: [
                   { y: 'Severity Counts', a: critical, b: serious, c: minor,d: moderate }
                   ],
            xkey: 'y',
            ykeys: ['a', 'b', 'c', 'd'],
            labels: ['critical', 'serious' , 'minor', 'moderate' ],
            barColors: ["#800000", "#FF0000","#40FF00","#21610B"]
          });

});